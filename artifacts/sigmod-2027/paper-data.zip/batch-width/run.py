"""Run the complete 17c width control in private copies of the archived runtime."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile

here = Path(__file__).resolve().parent
study = here.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("out", type=Path, help="new output directory")
parser.add_argument("--check-byte-limit", action="store_true",
                    help="repeat the 1024-row arm with 4 MiB and 8 MiB binding-byte allowances")
args = parser.parse_args()
out = args.out.resolve()
out.mkdir()
widths = [1, 16, 64, 256, 1024]
manifest = json.loads((study / "production-manifest.json").read_text())
with tempfile.TemporaryDirectory(prefix="dtlv-17c-widths-") as tmp:
    root = Path(tmp)
    with tarfile.open(study / "production-runtime.tar.gz") as tar:
        tar.extractall(root, filter="data")
    for name, digest in manifest.items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
    pg = root / "federation/postgres/src/datalevin/federation/postgres"
    plan, relational = pg / "plan.clj", pg / "relational.clj"
    bound = ":max-binding-rows 256 :max-binding-bytes 2097152 :max-request-binding-rows 256"
    guard = "(<= 1 (count bindings) 256)"
    orig_plan, orig_rel = plan.read_text(), relational.read_text()
    assert orig_plan.count(bound) == orig_rel.count(guard) == 1
    alias = '{:aliases {:widths {:extra-paths [' + json.dumps(str(study/"harness")) + '] :main-opts []}}}'
    if args.check_byte_limit:
        relational.write_text(orig_rel.replace(guard, guard.replace("256", "1024")))
        for mib in [4, 8]:
            limit = str(mib * 1024 * 1024)
            plan.write_text(orig_plan.replace(bound, bound.replace("256", "1024").replace("2097152", limit)))
            subprocess.run(["clojure", "-Sdeps", alias, "-M:job-baselines:widths", str(here/"run.clj"),
                            "0", "1024", str(out/f"bytes-{mib}mib.jsonl"), limit],
                           cwd=root/"federation", check=True)
        raise SystemExit
    for block, order in enumerate((widths, widths[::-1])):
        for width in order:
            plan.write_text(orig_plan.replace(bound, bound.replace("256", str(width))))
            relational.write_text(orig_rel.replace(guard, guard.replace("256", str(max(256, width)))))
            subprocess.run(["clojure", "-Sdeps", alias, "-M:job-baselines:widths", str(here/"run.clj"),
                            str(block), str(width), str(out/f"block-{block}.jsonl")],
                           cwd=root/"federation", check=True)
