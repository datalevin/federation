(require '[clojure.java.io :as io]
         '[datalevin.core :as d]
         '[datalevin.federation.postgres :as pg]
         '[datalevin.federation.postgres.plan :as plan]
         '[datalevin.federation.postgres-job-sql :as sql]
         '[datalevin.federation.postgres-job-suite :as suite]
         '[datalevin.research.placement-controls :as control]
         '[jsonista.core :as json])

(let [[block width-arg output byte-limit] *command-line-args*
      width (parse-long width-arg)
      entry (first (suite/corpus! (assoc control/opts :queries [:17c])))
      parsed (sql/parse (:sql entry))
      catalogs (into {} (for [table (distinct (map second (:from parsed)))]
                          [table (pg/discover control/profile ["public" table])]))
      spec (sql/compile-query parsed catalogs)
      providers (sql/sources! control/profile catalogs spec)
      oracle (suite/native! control/profile (sql/sql-query parsed "public" true))
      opts (cond-> {:limits (cond-> (assoc (:limits control/opts) :external-requests 65536 :binding-rows 1024)
                              byte-limit (assoc :binding-bytes (parse-long byte-limit)))
                    :native-extrema (:native-extrema spec)}
             (seq (:ignore-nil-extrema spec)) (assoc :ignore-nil-extrema (:ignore-nil-extrema spec)))
      requests #(reduce + (map (comp :external-requests pg/statistics) providers))
      source-hashes (into {} (for [p ["datalevin/query/source/binding.clj"
                                      "datalevin/federation/postgres/plan.clj"
                                      "datalevin/federation/postgres/relational.clj"
                                      "datalevin/research/placement_controls.clj"]]
                               [p (control/sha p)]))]
  (assert (= width (:max-binding-rows plan/constraints) (:max-request-binding-rows plan/constraints)))
  (when byte-limit (assert (= (parse-long byte-limit) (:max-binding-bytes plan/constraints))))
  (with-open [w (io/writer output :append true)]
    (let [query (assoc (:query spec) :timeout 180000 :query-source opts)
          calls (mapv (fn [sample]
                        (let [before (requests) start (System/nanoTime)
                              answer (set (apply d/q query providers))
                              ns (- (System/nanoTime) start)]
                          (assert (= oracle answer))
                          {:sample sample :ns ns :answer answer :requests (- (requests) before)}))
                      [-1 0 1])
          before (requests)
          plan (apply d/explain {:run? true :intermediate-counts? true} query providers)
          cursors (group-by :alternative-id (:cursors plan))
          groups (mapv (fn [[id cs]]
                         {:id id :opens (count cs)
                          :input-widths (frequencies (keep :input-rows cs))
                          :read-rows (reduce + (map #(get-in % [:metrics :read-rows]) cs))})
                       (sort-by key cursors))]
      (assert (= (count oracle) (:result-rows plan)))
      (assert (every? #(zero? (:live-sessions (pg/statistics %))) providers))
      (.write w (str (json/write-value-as-string
                       {:block block :requested width :sql-sha (:sha256 entry)
                        :source-hashes source-hashes :oracle oracle :calls calls :cursors groups
                        :diagnostic-requests (- (requests) before)}) "\n"))
      (.flush w)
      (println block width groups)
      (flush))))
(shutdown-agents)
