"""Paired inference from complete calls. The unit of replication is a fresh JVM."""
from collections import Counter, defaultdict
from functools import lru_cache
from hashlib import sha256
from itertools import permutations, product
import json
from math import ceil, floor, sqrt
from random import Random
from statistics import mean, median, stdev


def quantile(ordered, p):
    pos = (len(ordered) - 1) * p
    i = floor(pos)
    return ordered[i] + (pos - i) * (ordered[min(i + 1, len(ordered) - 1)] - ordered[i])


def interval(values):
    # 97.5th percentile of Student t with n-1 degrees of freedom.
    n = len(values)
    critical = {6: 2.570581835636315, 7: 2.446911851144969, 8: 2.364624251592785}
    half = critical[n] * stdev(values) / sqrt(n)
    return mean(values) - half, mean(values) + half


def paired_p(differences):
    observed = abs(sum(differences))
    extreme = sum(abs(sum(s * d for s, d in zip(signs, differences))) >= observed
                  for signs in product((-1, 1), repeat=len(differences)))
    return extreme / 2**len(differences)


def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def full_corpus(study, save, macros, tex_rows):
    blocks = [json.loads((study / ('job' if b < 4 else 'stat-job') / f'block-{b}.json').read_text())
              for b in range(6)]
    ids = [q['id'] for q in blocks[0]['phases']['warm']]
    assert len(set(ids)) == len(ids) == 113
    pairs, orders, extra = [], defaultdict(Counter), []
    gold = {r['id']: r for r in blocks[0]['phases']['warm']}
    for b, block in enumerate(blocks):
        assert block['status'] == 'complete' and block['block'] == b
        assert block['source-before'] == block['source-after'] == blocks[0]['source-before']
        if b:
            assert blocks[b-1]['finished-at'] < block['started-at']
        totals = []
        for phase in ('cold', 'warm'):
            phase_rows = block['phases'][phase]
            assert [q['id'] for q in phase_rows] == (ids[::-1] if b % 2 else ids)
            for r in phase_rows:
                q = r['id']
                assert r['status'] == r['aggregate-checks'][0]['result']['status'] == 'ok'
                assert r['sha256'] == gold[q]['sha256'] and r['expected'] == gold[q]['expected']
                assert all(s['live-sessions'] == 0 for s in r['source-statistics'])
                orders[q,phase][r['samples'][0]['order'][0]] += 1
            totals.extend(sum(r['samples'][0][arm]['elapsed-ns'] for r in phase_rows)/1e9 for arm in ('native','adapter'))
        if b >= 4:
            extra.append([b+1, *(f'{v:.2f}' for v in totals)])
        rows = block['phases']['warm']
        assert [q['id'] for q in rows] == (ids[::-1] if b % 2 else ids)
        by_id = {}
        for row in rows:
            sample, = row['samples']
            assert row['status'] == row['aggregate-checks'][0]['result']['status'] == 'ok'
            by_id[row['id']] = tuple(sample[arm]['elapsed-ns'] for arm in ('native', 'adapter'))
        pairs.append([by_id[q] for q in ids])
    assert all(v == {'native':3, 'adapter':3} for v in orders.values())
    tex_rows('ExtraBlockRows', extra)
    per_query, details = [], []
    for j, q in enumerate(ids):
        natives, adapters = zip(*(block[j] for block in pairs))
        diffs = [(a - n) / 1e9 for n, a in zip(natives, adapters)]
        lo, hi = interval(diffs)
        per_query.append(mean(adapters) / mean(natives))
        details.append(dict(query=q, original_s=mean(natives)/1e9, adapter_s=mean(adapters)/1e9,
                            ratio=per_query[-1], adapter_minus_original_s=mean(diffs), low_s=lo, high_s=hi))
    save('job-paired-queries.csv', details)
    block_saving = [sum(n - a for n, a in block) for block in pairs]
    macros['BatchPairedP'] = f'{paired_p(block_saving):.5f}'.rstrip('0')
    families = defaultdict(list)
    for j, q in enumerate(ids):
        families[q[:-1]].append(j)
    assert len(families) == 33
    groups = list(families.values())
    rng = Random(271828)

    @lru_cache(maxsize=None)
    def column_sums(index):
        original = [sum(pairs[b][j][0] for b in index) for j in range(len(ids))]
        adapter = [sum(pairs[b][j][1] for b in index) for j in range(len(ids))]
        return original, adapter, [a/n for n, a in zip(original, adapter)]

    estimates = []
    for _ in range(20_000):
        index = tuple(sorted(rng.choices(range(len(pairs)), k=len(pairs))))
        original, adapter, ratios = column_sums(index)
        draw = [j for family in rng.choices(groups, k=len(groups)) for j in family]
        ordered = sorted(ratios[j] for j in draw)
        saving = 100 * (1 - sum(adapter[j] for j in draw) / sum(original[j] for j in draw))
        estimates.append([saving, *(quantile(ordered, p) for p in (.5, .9, .99))])
    reduction = 100 * sum(block_saving) / sum(n for block in pairs for n, _ in block)
    saving_s = [n/1e9 for n in block_saving]
    low, high = interval(saving_s)
    macros.update(PooledSaving=f'{mean(saving_s):.2f}', PooledLow=f'{low:.2f}', PooledHigh=f'{high:.2f}',
                  PooledReduction=f'{reduction:.1f}', PooledSlower=str(sum(r > 1 for r in per_query)),
                  PooledSql=f'{sum(n for block in pairs for n,_ in block)/6e9:.2f}',
                  PooledAdapter=f'{sum(a for block in pairs for _,a in block)/6e9:.2f}',
                  PooledRatio=f'{median(per_query):.2f}')
    points = [reduction, *(quantile(sorted(per_query), p) for p in (.5, .9, .99))]
    measures = ['reduction_pct', 'p50_ratio', 'p90_ratio', 'p99_ratio']
    stats = []
    for name, value, samples in zip(measures, points, zip(*estimates)):
        ordered = sorted(samples)
        stats.append(dict(measure=name, estimate=value, low=quantile(ordered, .025), high=quantile(ordered, .975)))
    save('job-family-jvm-bootstrap.csv', stats)
    macros.update(MixSavingLow=f"{stats[0]['low']:.1f}", MixSavingHigh=f"{stats[0]['high']:.1f}")
    macros['RatioSummary'] = ', '.join(f"{s['estimate']:.2f} [{s['low']:.2f}, {s['high']:.2f}]"
                                        for s in stats[1:])


def prefixes(study, save, macros, tex_rows):
    gold = {q['id']: q['expected'] for q in json.loads((study/'job/block-0.json').read_text())['phases']['warm']}
    split = [r['id'] for r in json.loads((study/'routes/routes.json').read_text())['plans'] if r['route'] != 'whole']
    cases = split + ['dense-floor']
    means = defaultdict(dict)
    routing = defaultdict(dict)
    for b in range(8):
        if b < 2:
            records = lines(study/'public'/f'block-{b}.jsonl')
            records += [r for r in lines(study/'mixed'/f'block-{b}.jsonl') if r['id'] == 'dense-floor']
            route_records = lines(study/'router'/f'block-{b}.jsonl')
        else:
            all_records = lines(study/'stat-prefix'/f'block-{b}.jsonl')
            route_records = [r for r in all_records if r.get('comparison') == 'router']
            records = [r for r in all_records if r.get('comparison') != 'router']
        assert sorted(r['id'] for r in route_records) == sorted(split)
        for r in route_records:
            q = r['id']
            assert r['block'] == b and r['oracle'] == gold[q]
            assert not r['plans']['auto']['whole'] and r['plans']['sql']['whole']
            assert all(c['answer'] == gold[q] for c in r['calls'])
            assert sorted((c['mode'], c['sample']) for c in r['calls']) == sorted(product(('auto', 'sql'), (-1, 0, 1)))
            routing[q][b] = tuple(mean(c['elapsed-ns'] for c in r['calls'] if c['sample'] >= 0 and c['mode'] == m)/1e9
                                  for m in ('auto', 'sql'))
        routing['seven JOB'][b] = tuple(map(sum, zip(*(routing[q][b] for q in split))))
        calls = defaultdict(dict)
        for r in records:
            q = r['id']
            assert r['block'] == b and q in cases
            if q == 'dense-floor':
                assert r['rows'] == 2174
                observations = [r]
            else:
                assert r['oracle'] == gold[q]
                observations = r['calls']
                assert all(c['answer'] == gold[q] for c in observations)
            for c in observations:
                key = (c['mode'], c['sample'])
                assert key not in calls[q]
                calls[q][key] = c['elapsed-ns']
        for q in cases:
            assert set(calls[q]) == set(product(('auto', 'prefix'), (-1, 0, 1)))
            means[q][b] = tuple(mean(calls[q][mode, i] for i in (0, 1))/1e9 for mode in ('auto', 'prefix'))
        means['seven JOB'][b] = tuple(map(sum, zip(*(means[q][b] for q in split))))
    stats = []
    for q in [*split, 'seven JOB', 'dense-floor']:
        auto, prefix = zip(*(means[q][b] for b in range(8)))
        diffs = [(p - a)*1000 for p, a in zip(prefix, auto)]
        lo, hi = interval(diffs)
        stats.append(dict(query=q, blocks=8, default_s=mean(auto), prefix_s=mean(prefix),
                          prefix_minus_default_ms=mean(diffs), low_ms=lo, high_ms=hi))
    save('prefix-paired.csv', stats)
    table, routes = [], []
    for s in stats:
        q = s['query']
        first_route = ['--', '--']
        route_effect = '--'
        if q in routing:
            first_route = [f'{mean(values):.3f}' for values in zip(routing[q][0], routing[q][1])]
            diffs = [whole-auto for auto,whole in routing[q].values()]
            lo, hi = interval(diffs)
            route_effect = f'{mean(diffs):+.2f} [{lo:+.2f}, {hi:+.2f}]'
            routes.append(dict(query=q, blocks=8, whole_minus_auto_s=mean(diffs), low_s=lo, high_s=hi))
        first_prefix = [f'{mean(values):.3f}' for values in zip(means[q][0], means[q][1])]
        prefix_effect = f"{s['prefix_minus_default_ms']:+.1f} [{s['low_ms']:+.1f}, {s['high_ms']:+.1f}]"
        label = {'seven JOB': 'JOB sum', 'dense-floor': 'Dense + floor'}.get(q, q)
        table.append([label, *first_route, *first_prefix, route_effect, prefix_effect])
    save('routing-paired.csv', routes)
    tex_rows('ReplicatedControlRows', table)
    repeats = [dict(block=b, routing_default_s=routing['seven JOB'][b][0],
                    prefix_default_s=means['seven JOB'][b][0]) for b in range(2, 8)]
    drift = [1000*(r['prefix_default_s'] - r['routing_default_s']) for r in repeats]
    save('repeated-default.csv', repeats)
    lo, hi = interval(drift)
    macros.update(DefaultDrift=f'{mean(drift):+.1f}', DefaultDriftCI=f'[{lo:+.1f}, {hi:+.1f}]')
    chosen = {q for q in split if routing[q][0][1] < routing[q][0][0]}
    assert chosen == {'6b', '17b'}
    validation = []
    for b in range(1, 8):
        baseline = sum(routing[q][b][0] for q in split)
        selected = sum(routing[q][b][int(q in chosen)] for q in split)
        validation.append(dict(block=b, baseline_s=baseline, selected_s=selected, saving_s=baseline-selected))
    save('recurring-validation.csv', validation)
    savings = [b['saving_s'] for b in validation]
    lo, hi = interval(savings)
    cost = sum(c['elapsed-ns']/1e9 for r in lines(study/'router/block-0.jsonl') for c in r['calls'])
    macros.update(ValidationSaving=f'{mean(savings):.2f}', ValidationCI=f'[{lo:.2f}, {hi:.2f}]',
                  ValidationPayback=str(ceil(cost/mean(savings))) if mean(savings)>0 else 'unbounded')
    for q, stem in [('seven JOB','SevenPrefix'), ('dense-floor','DensePrefix'), ('17b','WidePrefix'), ('20b','KeywordPrefix')]:
        s = next(v for v in stats if v['query'] == q)
        macros[stem + 'Delta'] = f"{s['prefix_minus_default_ms']:+.1f}"
        macros[stem + 'CI'] = f"[{s['low_ms']:+.1f}, {s['high_ms']:+.1f}]"
    dense_plans = [r for b in range(2, 8) for r in lines(study/'stat-prefix'/f'block-{b}.jsonl')
                   if r['id'] == 'dense-floor' and r['sample'] >= 0]
    dense_plans += [r for b in (0, 1) for r in lines(study/'mixed'/f'block-{b}.jsonl')
                    if r['id'] == 'dense-floor' and r['sample'] >= 0]
    prefix_calls = [r for r in dense_plans if r['mode'] == 'prefix']
    macros['DenseApplied'] = str(sum(any(k.startswith('join-prefix-') for k in r['plan']['ids']) for r in prefix_calls))
    macros['DenseTrials'] = str(len(prefix_calls))


def network_mix(study, ids, details, save):
    """Restore the stratum frequencies used to draw the RTT panel."""
    routes = json.loads((study/'routes/routes.json').read_text())['plans']
    census = [r['id'] for r in routes if r['route'] != 'whole' or r['id'][:-1] == '17']
    original = defaultdict(list)
    for b in range(4):
        for r in json.loads((study/'job'/f'block-{b}.json').read_text())['phases']['warm']:
            original[r['id']].append(r['samples'][0]['native']['elapsed-ns'])
    others = sorted(set(original) - set(census), key=lambda q: mean(original[q]))
    sizes, groups = [], []
    sample = [dict(query=q, stratum='split or family 17', population=len(census), sampled=len(census),
                   selected=True, weight=1) for q in census]
    for i in range(3):
        population = others[i*len(others)//3:(i+1)*len(others)//3]
        chosen = sorted(population, key=lambda q: sha256(('placement-rtt-v1/' + q).encode()).digest())[:3]
        sizes.append(len(population))
        groups.append(chosen)
        sample.extend(dict(query=q, stratum=f'other whole, SQL runtime third {i+1}', population=len(population),
                           sampled=len(chosen), selected=q in chosen, weight=len(population)/len(chosen)) for q in population)
    assert set(ids) == {r['query'] for r in sample if r['selected']} and sizes == [34, 34, 35]
    save('rtt-panel-sampling.csv', sample)
    obs = {(r['block'], r['added_ms'], r['query']): (r['original_s'], r['adapter_s']) for r in details}

    @lru_cache(maxsize=None)
    def totals(blocks, level):
        by_id = {q: tuple(map(sum, zip(*(obs[b,level,q] for b in blocks)))) for q in ids}
        base = tuple(map(sum, zip(*(by_id[q] for q in census))))
        return base, by_id

    def ratio(blocks, sampled, level):
        (original_s, adapter_s), by_id = totals(blocks, level)
        for size, draw in zip(sizes, sampled):
            n, a = map(sum, zip(*(by_id[q] for q in draw)))
            original_s += n * size/len(draw)
            adapter_s += a * size/len(draw)
        return adapter_s / original_s

    rng = Random(314159)
    samples = defaultdict(list)
    for _ in range(20_000):
        blocks = tuple(sorted(rng.choices(range(6), k=6)))
        draw = [rng.choices(g, k=len(g)) for g in groups]
        for level in (0, 5, 20):
            samples[level].append(ratio(blocks, draw, level))
    stats = {}
    for level, values in samples.items():
        values.sort()
        stats[level] = dict(added_ms=level, ratio=ratio(tuple(range(6)), groups, level),
                            low=quantile(values, .025), high=quantile(values, .975))
    save('rtt-panel-weighted.csv', list(stats.values()))
    return stats


def network(study, save, macros, tex_rows):
    path = study/'stat-rtt'
    ids = json.loads((path/'inputs.json').read_text())['ids']
    gold = {q['id']: q for q in json.loads((study/'job/block-0.json').read_text())['phases']['warm']}
    assert len(set(ids)) == len(ids) == 19
    stats, details, calibrations = [], [], defaultdict(list)
    first = defaultdict(Counter)
    for b in range(6):
        rows = lines(path/f'block-{b}.jsonl')
        assert rows[0]['stage'] == 'inventory-before' and rows[-1]['stage'] == 'inventory-after'
        assert rows[0]['source'] == rows[-1]['source']
        if b == 0:
            inventory = rows[0]['source']
        assert rows[0]['source'] == inventory
        ordered_levels = list(permutations([0, 5, 20]))[b]
        measured_levels = [r['level'] for r in rows if 'calibration-before' in r and r['stage'] == 'measure']
        assert tuple(measured_levels) == ordered_levels
        wire = lines(path/f'wire-{b}.jsonl')
        assert wire and all(not session['errors'] for session in wire)
        for r in rows:
            if 'id' not in r:
                continue
            q = r['id']
            assert r['block'] == b and r['expected'] == gold[q]['expected'] and r['sha256'] == gold[q]['sha256']
            assert r['aggregate-checks'][0]['result']['status'] == 'ok'
            assert all(s['live-sessions'] == 0 for s in r['source-statistics'])
        assert sorted(r['id'] for r in rows if r['stage'] == 'warmup' and 'id' in r) == sorted(ids)
        for level in ordered_levels:
            cell = [r for r in rows if r['stage'] == 'measure' and r['level'] == level]
            times = [r for r in cell if 'id' in r]
            assert sorted(r['id'] for r in times) == sorted(ids)
            for end in ('before', 'after'):
                values, = [r['calibration-'+end] for r in cell if 'calibration-'+end in r]
                assert len(values) == 12
                calibrations[level].extend(v/1e6 for v in values)
            for r in times:
                sample, = r['samples']
                assert all(sample[a]['status'] == 'ok' for a in ('native', 'adapter'))
                first[r['id'],level][sample['order'][0]] += 1
                # Both fresh timed connections must appear on this relay.
                tag = f"paired-{b}-measure-{level}-{r['id']}"
                sessions = [s for s in wire if s['label'] == tag and s['added_rtt_ms'] == level]
                assert len(sessions) == 2, (b, level, r['id'], len(sessions))
                details.append(dict(block=b, added_ms=level, query=r['id'], first=sample['order'][0],
                                    original_s=sample['native']['elapsed-ns']/1e9, adapter_s=sample['adapter']['elapsed-ns']/1e9))
    assert all(c == {'native':3,'adapter':3} for c in first.values())
    save('rtt-panel-pairs.csv', details)
    query_stats = []
    for level in (0, 5, 20):
        for q in ids:
            cell = [r for r in details if r['added_ms'] == level and r['query'] == q]
            diffs = [r['adapter_s'] - r['original_s'] for r in cell]
            lo, hi = interval(diffs)
            query_stats.append(dict(added_ms=level, query=q, original_s=mean(r['original_s'] for r in cell),
                                    adapter_s=mean(r['adapter_s'] for r in cell), delta_s=mean(diffs), low_s=lo, high_s=hi))
    save('rtt-panel-queries.csv', query_stats)
    example = next(r for r in query_stats if r['query'] == '17c' and r['added_ms'] == 20)
    macros.update(RttExampleSQL=f"{example['original_s']:.2f}", RttExampleAdapter=f"{example['adapter_s']:.2f}")
    for level in (0, 5, 20):
        originals, adapters = [], []
        for b in range(6):
            pairs = [r for r in details if r['block'] == b and r['added_ms'] == level]
            originals.append(sum(r['original_s'] for r in pairs))
            adapters.append(sum(r['adapter_s'] for r in pairs))
        diffs = [a-n for a, n in zip(adapters, originals)]
        lo, hi = interval(diffs)
        stats.append(dict(added_ms=level, calibration_ms=median(calibrations[level]), original_s=mean(originals),
                          adapter_s=mean(adapters), ratio=mean(adapters)/mean(originals),
                          adapter_minus_original_s=mean(diffs), low_s=lo, high_s=hi))
    save('rtt-panel-summary.csv', stats)
    weighted = network_mix(study, ids, details, save)
    prior = defaultdict(lambda: defaultdict(list))
    for b in (0, 1):
        for run in lines(study/'rtt'/f'block-{b}.jsonl'):
            for call in run['calls']:
                if call['sample'] >= 0:
                    prior[run['added-rtt-ms']][call['mode']].append(call['elapsed-ns']/1e9)
    table = []
    for s in stats:
        w = weighted[s['added_ms']]
        single = [f'{median(prior[s["added_ms"]][arm]):.3f}' for arm in ('auto', 'sql')]
        table.append([s['added_ms'], *single, f"{s['original_s']:.2f}", f"{s['adapter_s']:.2f}",
                      f"{s['adapter_minus_original_s']:+.2f} [{s['low_s']:+.2f}, {s['high_s']:+.2f}]",
                      f"{w['ratio']:.2f} [{w['low']:.2f}, {w['high']:.2f}]"])
    tex_rows('RttPanelRows', table)
    macros.update(LinkLocalRatio=f"{stats[0]['ratio']:.2f}", LinkHighRatio=f"{stats[-1]['ratio']:.2f}",
                  MixLocalRatio=f"{weighted[0]['ratio']:.2f}", MixHighRatio=f"{weighted[20]['ratio']:.2f}")


def summarize(study, save, macros, tex_rows):
    manifest = sha256((study/'production-manifest.json').read_bytes()).hexdigest()
    runs = []
    for panel, blocks in [('job', range(4, 6)), ('prefix', range(2, 8)), ('rtt', range(6))]:
        path = study/('stat-' + panel)
        receipt = json.loads((path/'inputs.json').read_text())
        assert receipt['panel'] == panel and receipt['production_manifest'] == manifest
        for name, h in receipt['files'].items():
            assert sha256((study/name).read_bytes()).hexdigest() == h, name
        runs.extend(json.loads((path/f'launch-{b}.json').read_text()) for b in blocks)
    assert all(r['start_ns'] < r['end_ns'] for r in runs)
    assert all(r['end_ns'] < s['start_ns'] for r, s in zip(runs, runs[1:]))
    full_corpus(study, save, macros, tex_rows)
    prefixes(study, save, macros, tex_rows)
    network(study, save, macros, tex_rows)
