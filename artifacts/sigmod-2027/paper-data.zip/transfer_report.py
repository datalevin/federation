"""Concentration, threshold sensitivity and applicability of the frozen PostgreSQL policy."""
from collections import defaultdict
import csv
import gzip
import hashlib
import json
import re
import tarfile
from statistics import mean


def summarize_transfer(study, save_csv, macros, tex_rows):
    transfer = study/'router-transfer'
    def read(name):
        return json.loads((transfer/name).read_bytes())
    def lines(name):
        return [json.loads(s) for s in (transfer/name).read_text().splitlines()]
    def order(q):
        return int(q[:-1]), q[-1]

    historical = gzip.decompress((transfer/'nov10-plan.clj.gz').read_bytes())
    receipt = gzip.decompress((transfer/'nov10-source-record.edn.gz').read_bytes())
    match = re.search(rb'"datalevin/federation/postgres/plan.clj"\s*\{[^}]*:raw-sha256\s*"([a-f0-9]{64})"', receipt)
    assert match and match[1].decode() == hashlib.sha256(historical).hexdigest()
    with tarfile.open(study/'production-runtime.tar.gz', 'r:gz') as archive:
        current = archive.extractfile('federation/postgres/src/datalevin/federation/postgres/plan.clj').read()
    def preference(source):
        start = source.index(b'(defn dependent-preference')
        return source[start:source.index(b'\n(defn ', start)]
    assert preference(historical) == preference(current)

    with (study/'job-queries.csv').open() as f:
        warm = {r['query']:r for r in csv.DictReader(f) if r['phase']=='warm'}
    fams = defaultdict(dict)
    for q,r in warm.items():
        n, suffix = order(q)
        fams[n][suffix] = float(r['saving_s'])
    assert set(fams) == set(range(1,34)) and sum(map(len,fams.values())) == 113
    total = sum(sum(v.values()) for v in fams.values())
    sql_total = sum(float(r['original_s']) for r in warm.values())
    family_rows = []
    printed = []
    for family, deltas in sorted(fams.items()):
        saved = sum(deltas.values())
        remaining = sql_total-sum(float(warm[f'{family}{s}']['original_s']) for s in deltas)
        family_rows.append(dict(family=family,queries=len(deltas),saving_s=saved,
                                remaining_saving_s=total-saved,remaining_saving_pct=100*(total-saved)/remaining))
        cells = []
        for suffix in 'abcdef':
            if suffix in deltas:
                ms = round(1000*deltas[suffix])
                value = f'${ms}$'
                if warm[f'{family}{suffix}']['route']!='whole':
                    value = r'$\mathbf{'+str(ms)+'}$'
                cells.append(value)
            else:
                cells.append('')
        printed.append([family,*cells, f'${round(saved*1000)}$'])
    save_csv('job-families.csv', family_rows)
    tex_rows('QueryFamilyRows', [printed[i]+(printed[i+17] if i+17<len(printed) else ['']*8)
                                 for i in range(17)])
    leave = sorted(family_rows, key=lambda r:r['remaining_saving_pct'])
    macros['OmitRange']=(f"{leave[0]['remaining_saving_pct']:.1f}\\% (omit family~{leave[0]['family']}) "
                         f"to {leave[-1]['remaining_saving_pct']:.1f}\\% (omit family~{leave[-1]['family']})")
    with (study/'placement-times.csv').open() as f:
        deltas = {r['query']:float(r['whole'])-float(r['automatic']) for r in csv.DictReader(f)}
    family17 = sum(x for q,x in deltas.items() if order(q)[0]==17)
    assert family17 < 0
    macros['SameCompilerFamilyLoss'] = f'{-family17:.2f}'
    macros['SameCompilerOutsideGain'] = f'{sum(deltas.values())-family17:.2f}'

    original = {r['id']:r for r in json.loads((study/'routes/routes.json').read_bytes())['plans']}
    plans = lines('plans.jsonl')
    ids = sorted(original,key=order)
    assert [r['id'] for r in plans]==ids and all(r['sha256']==original[r['id']]['sha256'] for r in plans)
    default = (3,8,12,4)
    by_setting = defaultdict(dict)
    for r in plans:
        assert len(r['plans'])==17
        for p in r['plans']:
            by_setting[tuple(p['setting'])][r['id']] = p['route']
    assert by_setting[default]=={q:original[q]['route'] for q in ids}
    reference = set(deltas)
    assert {q for q,route in by_setting[default].items() if route!='whole'}==reference
    reasons = {r['id']:p['reasons'] for r in plans for p in r['plans'] if tuple(p['setting'])==default}
    assert {q for q,why in reasons.items() if why} == reference
    for tag, ids_for_branch in [('existence-probes', {'10c','17b','17c','17d'}),
                                ('text-membership-driver', {'6b','6d','20b'})]:
        assert {q for q,why in reasons.items() if why==[tag]} == ids_for_branch
        value = sum(deltas[q] for q in ids_for_branch)
        macro = 'ExistenceSaving' if tag=='existence-probes' else 'MembershipSaving'
        macros[macro] = f'{value:.2f}'
    names = ['Minimum groups','Small-graph cap','Two-driver cap','Literal characters']
    grid = [[1,2,3,4,7],[6,7,8,9,10],[10,11,12,13,14],[1,3,4,5,8]]
    rows, sensitivity, new = [], [], set()
    for column,values in enumerate(grid):
        counts = []
        for value in values:
            setting = list(default)
            setting[column] = value
            panel = by_setting[tuple(setting)]
            assert set(panel)==set(ids)
            selected = {q for q,route in panel.items() if route!='whole'}
            new.update(selected-reference)
            counts.append(str(len(selected)))
            rows.append(dict(parameter=names[column],value=value,split=len(selected),
                             newly_split=' '.join(sorted(selected-reference,key=order)),
                             newly_whole=' '.join(sorted(reference-selected,key=order))))
        sensitivity.append([names[column],', '.join(r'\textbf{'+str(v)+'}' if v==default[column] else str(v)
                                                    for v in values),', '.join(counts)])
    assert len(by_setting)==17
    save_csv('job-cutoffs.csv',rows)
    tex_rows('ThresholdRows',sensitivity)

    switches = defaultdict(dict)
    for b in range(2):
        trials = lines(f'switch-{b}.jsonl')
        assert len(trials)==2*len(new) and {r['id'] for r in trials}==new
        for r in trials:
            q,setting = r['id'],tuple(r['setting'])
            assert r['block']==b and r['sha256']==original[q]['sha256']
            route = by_setting[setting][q]
            assert r['plan']['whole']==(route=='whole')==(setting==default)
            assert r['status']=='ok' and r['answer']==r['oracle'] or r.get('error',{}).get('error')=='query/timeout'
            assert (b,route) not in switches[q]
            switches[q][b,route] = r
    timing_rows = []
    for q,calls in sorted(switches.items(),key=lambda item:order(item[0])):
        assert len(calls)==4
        row = {'query':q}
        for b in range(2):
            for route in ('whole','coordinator'):
                r = calls[b,route]
                row[f'{route}_status_{b}'] = r['status']
                row[f'{route}_wall_s_{b}'] = r['elapsed-ns']/1e9
        timing_rows.append(row)
    save_csv('job-cutoff-times.csv',timing_rows)
    timed = [calls for q,calls in switches.items() if q.startswith('15')]
    loss = sum(mean((c[b,'coordinator']['elapsed-ns']-c[b,'whole']['elapsed-ns'])/1e9 for b in range(2)) for c in timed)
    assert len(timed)==4 and all(c[b,'coordinator']['elapsed-ns']>c[b,'whole']['elapsed-ns'] for c in timed for b in range(2))
    macros['LooserCapLoss'] = f'{loss:.2f}'
    assert all(switches['17f'][b,'coordinator']['status']=='failed' and switches['17f'][b,'whole']['status']=='ok' for b in range(2))
    macros['BroadWholeTimes']=' and '.join(f"{switches['17f'][b,'whole']['elapsed-ns']/1e9:.2f}" for b in range(2))

    rdf = lines('rdf-plans.jsonl')
    shapes, checks, accepted = read('rdf-shapes.json'),read('rdf-checks.json'),read('rdf-reference.json')
    inputs=json.loads(gzip.decompress((transfer/'rdf-inputs.json.gz').read_bytes()))
    assert set(shapes)==set(inputs['sparql'])=={f'{p}{i}' for p,n in [('S',14),('B',8),('C',10),('CH',8)] for i in range(1,n+1)}
    assert all(s['projected']>0 and s['aggregates']==[] and s['sha256']==hashlib.sha256(inputs['sparql'][q].encode()).hexdigest() for q,s in shapes.items())
    assert len(rdf)==18 and {r['id'] for r in rdf}==set(accepted)=={s['id'] for s in inputs['specs']}
    assert len(checks)==36
    archive = json.loads(gzip.decompress((transfer/'rdf-rows.json.gz').read_bytes()))
    assert set(archive['calls'])==set(checks) and set(archive['calls'].values())==set(archive['rows'])
    rdf_rows=[]
    for r in rdf:
        q=r['id']
        assert all(r['auto'][k]==r['sql'][k] for k in ['whole','fragment','regions'])
        for mode in ('auto','sql'):
            c=checks[q+'-'+mode]
            assert c['matches'] and {k:c[k] for k in ['n','bag','order']} in accepted[q]
            raw = archive['rows'][archive['calls'][q+'-'+mode]]
            digest = hashlib.sha256(json.dumps(raw, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
            assert c['core_rows_sha256']==digest and c['n']<=len(raw)==r[mode]['core-rows']
        rdf_rows.append(dict(query=q,whole=r['auto']['whole'],same_accesses=True,returned_rows=checks[q+'-auto']['n'],
                             automatic_core_s=r['auto']['core-ns']/1e9,sql_preference_core_s=r['sql']['core-ns']/1e9))
    assert not any(r['whole'] for r in rdf_rows)
    save_csv('rdf-transfer.csv',rdf_rows)


if __name__ == '__main__':
    from report import STUDY, MACROS, save_csv, tex_rows

    summarize_transfer(STUDY, save_csv, MACROS, tex_rows)
    for name, value in MACROS.items():
        print(r'\newcommand{\%s}{%s}' % (name, value))
