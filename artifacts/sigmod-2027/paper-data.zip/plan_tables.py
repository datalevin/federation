"""Summarize PostgreSQL plan counters and match captures to public access IDs."""
from collections import Counter, defaultdict
import gzip
import json
import statistics as st
from pathlib import Path


def stats(trace):
    with gzip.open(trace,'rt') as src:
        data=json.load(src)
    portals=lambda texts: sorted(s.split(None,2)[1] for s in texts if s.startswith('DECLARE '))
    assert portals(p['Query Text'] for p in data['plans'])==portals(q['sql'] for q in data['queries'])
    result=Counter()
    result['commands']=sum(data['commands'].values())
    result['data_statements']=len(data['queries'])
    result['output_rows']=sum(p['Plan']['Actual Rows']*p['Plan']['Actual Loops'] for p in data['plans'])
    result['materialized_sql']=sum('dtlv_restricted AS MATERIALIZED' in q['sql'] for q in data['queries'])
    for p in data['plans']:
        def visit(node):
            loops=node['Actual Loops']
            if node['Node Type'] in ('Index Scan', 'Index Only Scan', 'Bitmap Index Scan'):
                result['index_searches'] += node['Index Searches']
            if node['Node Type'] == 'Index Only Scan':
                result['index_only_nodes'] += 1
                result['heap_fetches'] += node['Heap Fetches']
            result['join_rejections']+=loops*node.get('Rows Removed by Join Filter',0)
            if node.get('Schema')=='public' or node.get('Schema','').startswith('dtlv_pfx_'):
                if node.get('Relation Name') and node['Node Type'].endswith('Scan'):
                    result['base_tuples']+=loops*(node['Actual Rows']+node.get('Rows Removed by Filter',0)+node.get('Rows Removed by Index Recheck',0))
            if node.get('CTE Name')=='dtlv_restricted':
                result['cte_scans']+=loops
                result['max_cte_scans']=max(result['max_cte_scans'],loops)
            for child in node.get('Plans',[]):visit(child)
        visit(p['Plan'])
    return dict(result)


def number(n):return f'{n:,.0f}'


def family_trace(study, tex_rows):
    """Report first-access cardinalities and actual index probes per complete call."""
    def nodes(root):
        yield root
        for child in root.get('Plans', []):
            yield from nodes(child)

    columns = []
    for query in ('17b', '17c'):
        captures = {}
        for arm in ('auto', 'prefix', 'whole'):
            with gzip.open(study/'capture'/f'{query}-{arm}.json.gz', 'rt') as src:
                captures[arm] = [p['Plan'] for p in json.load(src)['plans']]
        def probes(arm, index):
            return [n['Index Searches'] for root in captures[arm] for n in nodes(root)
                    if n.get('Index Name') == index]
        names = captures['auto'][0]
        assert names['Relation Name'] == 'name' and names['Actual Loops'] == 1
        people = names['Actual Rows']
        cast_batches = probes('auto', 'person_id_cast_info')
        keywords = sum(probes('auto', 'keyword_pkey'))
        assert sum(cast_batches) == people == sum(probes('prefix', 'person_id_cast_info'))
        assert keywords == sum(probes('prefix', 'keyword_pkey'))
        whole, = captures['whole']
        columns.append([names['Plan Rows'], people, len(cast_batches), keywords,
                        len(captures['auto']), sum(probes('whole', 'movie_id_cast_info')),
                        whole['Actual Rows'] * whole['Actual Loops']])
    labels = ['Estimated matching names', 'Actual person keys / cast probes',
              'Batches sent to the cast lookup', 'Keyword primary-key probes',
              'Data statements, all stages', 'Cast probes by movie ID', 'Aggregate rows returned']
    rows = [[label, number(b), number(c)] for label, b, c in zip(labels, *columns)]
    tex_rows('FamilySplitRows', rows[:5])
    tex_rows('FamilyWholeRows', rows[5:])


def summarize(study, records, save, macros, tex_rows):
    family_trace(study, tex_rows)
    calls=defaultdict(lambda:defaultdict(list))
    plans={}
    for row in records('public'):
        for arm,plan in row['plans'].items():
            assert plans.setdefault((row['id'],arm),plan)==plan
        for c in row['calls']:
            if c['sample']>=0:calls[row['id'],c['mode']][row['block']].append(c['elapsed-ns']/1e9)
    metrics={}
    table=[]
    for row in records('capture'):
        id=row['id']
        for arm,cap in row['captures'].items():
            tr=study/'capture'/cap['trace']
            met=stats(tr)
            assert cap['result']['answer']==row['oracle']
            if arm in ('prefix','auto'):
                assert row['plans'][arm]==plans[id,arm]
            metrics[id,arm]=met
            table.append(dict(query=id,option=arm,ids=' '.join(s for s in row['plans'][arm]['ids'] if s),**met))
    save('public-plans.csv', table)
    selected=[id for id,arm in plans if arm=='prefix' and
              any(s and s.startswith('join-prefix-') for s in plans[id,arm]['ids'])]
    split = [q['id'] for q in json.loads((study/'routes/routes.json').read_text())['plans']
             if q['route'] != 'whole']
    assert set(selected) == set(split)
    for id in selected: assert metrics[id,'prefix']['materialized_sql']>0
    def advantage(id,b):
        return st.mean(calls[id,'auto'][b])-st.mean(calls[id,'prefix'][b])
    both=[id for id in selected if advantage(id,0)*advantage(id,1)>0]
    by_delta=sorted(both,key=lambda id:advantage(id,0)+advantage(id,1))
    cases=list(dict.fromkeys([by_delta[0],by_delta[-1]])) if by_delta else sorted(selected)[:2]
    appendix = []
    for query in split:
        for arm, label in [('auto', 'Default'), ('prefix', 'Prefix')]:
            met = metrics[query, arm]
            heap = number(met['heap_fetches']) if met.get('index_only_nodes') else '---'
            appendix.append([query, label, number(met['base_tuples']),
                             number(met['index_searches']), heap])
    tex_rows('AllPrefixWorkRows', appendix)
    rows=[]
    for id in cases:
        for arm,label in [('auto','Default'),('prefix','Prefix')]:
            met=metrics[id,arm]
            rows.append([id,label,number(met['commands']),number(met['output_rows']),number(met.get('base_tuples',0)),
                         number(met.get('join_rejections',0)),number(met.get('max_cte_scans',0))])
    tex_rows('PlanRows',rows)
    changes = {id: st.mean(advantage(id, block) for block in (0, 1)) for id in selected}
    largest = max(changes, key=lambda id: abs(changes[id]))
    macros['PrefixInterpretation'] = (
        f"The option selects a protected access on {len(selected)} of the {len(calls)//2} split JOB queries. "
        "Each emits SQL containing the materialized lookup. The largest absolute difference "
        f"in mean time in the right-hand pair of Table~\\ref{{tab:route-control}} is "
        f"{abs(changes[largest]):.2f}\\,s on {largest}.")
    descriptions=[]
    for id in cases:
        ids=[s for s in plans[id,'prefix']['ids'] if s and s.startswith('join-prefix-')]
        x=st.mean(sum(calls[id,'auto'].values(),[]))
        y=st.mean(sum(calls[id,'prefix'].values(),[]))
        sign='saves' if y<x else 'adds'
        escaped=ids[0].replace("_", r"\_")
        descriptions.append(f"On {id}, selecting \\texttt{{{escaped}}}"
                            +(f" and {len(ids)-1} other protected lookups" if len(ids)>1 else "")
                            +f" {sign} {abs(x-y):.3f}\\,s per complete query")
    macros['CaseInterpretation']='. '.join(descriptions)+'.'
    def access(ids):
        if 'relational-fragment' in ids:
            return 'fragment'
        if any(s.startswith('join-prefix-') for s in ids):
            return 'prefix'
        if any(s.startswith('join-') for s in ids):
            return 'bound'
        return 'lookups'

    def key(row):
        return row['id'], row['mode'], tuple(s for s in row['plan']['ids'] if s)

    mixed=defaultdict(list)
    for r in records('mixed'):
        if r['sample']>=0:
            assert 'failure' not in r
            mixed[key(r)].append(r)
    diagnostics={}
    traces=[]
    for panel in ('mixed-plans','mixed-check'):
        runs=records(panel)
        assert len(runs)==8
        for r in runs:
            assert 'failure' not in r['result']
            q,arm,ids=key(r)
            met=stats(study/panel/r['trace'])
            assert (met['materialized_sql']>0)==(access(ids)=='prefix')
            trace=dict(trace=panel+'/'+r['trace'],result_rows=r['result']['rows'],**met)
            traces.append(dict(fixture=q,option=arm,ids=' '.join(ids),**trace))
            diagnostics.setdefault((q,arm,ids),trace)
    save('mixed-plans.csv',traces)
    rows=[]
    for (q,arm,ids),obs in mixed.items():
        counts={r['rows'] for r in obs}
        assert len(counts)==1
        n=counts.pop()
        met=diagnostics.get((q,arm,ids))
        if met:
            assert met['result_rows']==n
        blocks=sorted({r['block']+1 for r in obs})
        rows.append(dict(fixture=q,option=arm,access=access(ids),ids=' '.join(ids),blocks=','.join(map(str,blocks)),
                         calls=len(obs),rows=n,commands=met['commands'] if met else None,
                         median_s=st.median(r['elapsed-ns']/1e9 for r in obs)))
    fixtures=['dense','high-fanout','dense-floor','high-fanout-floor']
    for fixture in fixtures:
        for arm in ['auto','prefix']:
            c=[o for (q,a,_),obs in mixed.items() if (q,a)==(fixture,arm) for o in obs]
            assert sorted((o['block'],o['sample']) for o in c)==[(0,0),(0,1),(1,0),(1,1)]
    rows.sort(key=lambda r:(fixtures.index(r['fixture']),r['blocks'],r['option']))
    save('mixed-outcomes.csv',rows)
    for q in fixtures[:2]:
        assert {r['ids'] for r in rows if r['fixture']==q}=={'relational-fragment'}
