(require '[clojure.string :as str]
         '[clojure.test :as t]
         '[datalevin.federation.postgres-test :as u]
         '[datalevin.federation.postgres-integration-test :as i])

;; Each test runs with its namespace fixtures, as in the complete suite.
(def groups
  [["T1" [#'u/physical-key-and-conversion-proofs-are-required
          #'u/batched-integral-keys-are-not-narrowed-to-the-physical-column-type
          #'i/live-catalog-rejects-duplicate-rows-and-deferrable-keys]]
   ["T2" [#'i/batched-lookups-preserve-binding-ids-and-equality
          #'i/mixed-fragment-aggregation-preserves-native-witnesses-and-find-with
          #'i/mixed-fragments-batch-many-customer-groups-without-transferring-orders
          #'i/fragment-cursors-own-mutable-bindings-and-drop-them-on-close
          #'i/scoped-or-outputs-retain-unprojected-source-join-keys
          #'u/protected-prefix-requires-one-directly-bound-table-and-a-connected-continuation
          #'i/bound-join-modes-preserve-batch-ordinals-and-missing-keys]]
   ["T3" [#'u/summary-eligibility-and-parameter-order
          #'u/binary-association-needs-the-complete-physical-catalog
          #'i/binary-min-summary-rechecks-unmapped-physical-columns-without-statistics]]
   ["T4" [#'u/presence-proofs-preserve-composite-and-boolean-null-semantics
          #'i/native-min-summary-preserves-values-presence-and-invalid-witnesses
          #'i/delegated-aggregates-enforce-output-row-and-input-conversion-limits]]
   ["T5" [#'i/budgets-and-large-rows-fail-without-partial-success
          #'i/cancellation-unblocks-real-jdbc-fetch
          #'i/failed-local-expressions-release-postgres-session-and-workspace
          #'i/snapshot-loss-does-not-reconnect-or-return-a-prefix]]])

(println "group,file,line,test,pass,fail,error")
(doseq [[group tests] groups
        v tests]
  (binding [t/*report-counters* (ref t/*initial-report-counters*)
            t/*test-out* *err*]
    (t/test-vars [v])
    (let [{:keys [test pass fail error]} @t/*report-counters*
          {:keys [file line name]} (meta v)]
      (println (str/join "," [group (str "federation/postgres/test/" file) line name pass fail error]))
      (when-not (and (= test 1) (pos? pass) (zero? (+ fail error)))
        (throw (ex-info "Contract check failed" {:test name}))))))
(shutdown-agents)
