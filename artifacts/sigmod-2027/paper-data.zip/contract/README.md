# Table 2 tests and filter placement regression

The 20 tests cited in Table 2 ran with their normal Clojure fixtures on the benchmark snapshot, manifest `ce5d314a27ff`. All 176 assertions passed. The CSV records every test name, source path, starting line and assertion count on that snapshot. These tests are a subset of the PostgreSQL suite. [Per-test results](tests.csv) · [Test runner](test_groups.clj)

| Group | Tests | Passed assertions | Example of the assertion exercised |
| --- | ---: | ---: | --- |
| T1. Types and identity | 3 | 17 | Mapping acquisition rejects a deferrable key. A lookup for 40,000 against a smallint column binds a widened integer parameter. |
| T2. Binding and batch scope | 7 | 76 | Both bound-join modes preserve the frequency of each binding ID and output tuple across two batches with a repeated key and a missing key. A scoped join retains its unprojected status variable. |
| T3. Summary eligibility | 3 | 39 | Adding an unmapped physical column withdraws the binary MIN summary on the next acquisition, including with statistics disabled. |
| T4. Observable effects | 3 | 27 | An invalid numeric or timestamp on a non-minimal witness raises an error. The integration test checks the result and whether the adapter selected the summary. |
| T5. Failure and cleanup | 4 | 17 | After delivering one batch, terminating the backend makes the next fetch raise a snapshot-loss error. Closing the cursor and session releases the reservations. |

## The five failures

A separate test, `decimal-and-temporal-filters-reduce-transfer-in-ordinary-queries` (integration file, line 317), creates 1,000 rows with keys 1–1,000 and decimal amounts 0.1000–100.0000. It checks returned tuples against eager Datalog, counts rows delivered by source cursors and inspects the chosen plan. The original full-suite run recorded 165 tests, 3,314 assertions, five failures and zero errors. [Original suite log](../postgres/block-0.log)

| Predicate on this fixture | Benchmark build | Corrected adapter and tests |
| --- | --- | --- |
| `id > 990` | No prefilter, 1,000 rows transferred, 10 returned | Predicate selected, 10 transferred, 10 returned |
| `990 < id` | No prefilter, 1,000 rows transferred, 10 returned | Predicate selected, 10 transferred, 10 returned |
| `amount > 99.0` (double literal) | Prefilter selected, 11 transferred, 10 returned. Test expected 1,000 transferred. | Prefilter selected, 11 transferred, 10 returned |
| `amount = 99.0` (new fallback control) | Revised test on the original planner confirms a full transfer | No prefilter, 1,000 transferred, eager answer matched |

**Four failures exposed a planner regression.** The PostgreSQL planner looked up the value variable only in the ordinary attribute map. The accepted mapping stores the identity attribute separately. The fix admits a single integral identity as a scalar column for predicate compilation. Each operand order must select the predicate's clause ID and transfer exactly ten rows. The labeled rerun of the revised test on the original planner fails precisely those four checks. [Planner and test patch](filter.patch) · [Original planner with labeled assertions](original-planner.log)

**One assertion still described the earlier full-scan fallback.** The earlier compiler only pushed exact decimal comparisons. The benchmark compiler also accepts a conservative range for finite double cutoffs. For this strict comparison, its inclusive SQL lower bound is the exact decimal value of the double immediately below 99.0. That admits 99.0000 along with the ten larger amounts. The core residual rejects the boundary row. The revised test requires both the 11-row transfer and selection of that predicate. Mixed decimal/double equality still exercises the full-scan fallback. [Earlier implementation and tests](../../federation-summary-production-2026-11-17/README.md) · [Updated assertions](filter.patch)

The entire corrected suite passed, with 165 tests, 3,320 assertions and zero failures or errors. The installed adapter also passed all 66 assertions in the focused test. The performance tables in the paper use the original build. The two-file patch and post-patch digests identify the validation build. [Full rerun](corrected-suite.log) · [Focused rerun](corrected-case.log) · [Source digests](validation.json)

The existing JOB pilot exercised 2c, 17c and 22d in a first and a warm pass per build. All six aggregate comparisons per build matched PostgreSQL, with identical per-source request counts across builds. Warm adapter times in query order were 560, 561 and 2,392 ms before the patch and 496, 643 and 2,610 ms after. Each cell has one observation. Both pilot JVMs shared the host with the JOB timing-boundary measurements. [Before](before-job.json) · [After](after-job.json)

## Reproduction

From the measurement directory or the root of the extracted PDF attachment, use JDK 21 and a disposable PostgreSQL database. Each integration fixture creates and drops its own schema. The first run uses the unmodified benchmark snapshot, so its source line numbers match Table 2.

```sh
study=$PWD
root=$(mktemp -d)
tar -xzf production-runtime.tar.gz -C "$root"
export POSTGRES_TEST_URL=jdbc:postgresql://127.0.0.1:5432/federation_test
cd "$root/federation"
clojure -Sdeps '{:aliases {:checks {:extra-paths ["test" "postgres/test" "../datalevin/test-src"] :main-opts []}}}' \
  -M:job-baselines:checks "$study/contract/test_groups.clj" > "$root/tests.csv"
diff -u "$study/contract/tests.csv" "$root/tests.csv"
```

The second run applies the patch to that extracted copy and executes both complete PostgreSQL test namespaces.

```sh
patch -d "$root" -p1 -i "$study/contract/filter.patch"
clojure -Sdeps '{:aliases {:conformance {:extra-paths ["../datalevin/test-src"]}}}' \
  -M:job-baselines:postgres:conformance
```
