"""Replay one experiment against a verified frozen production tree."""
import argparse
import hashlib
import json
import os
import subprocess
import threading
from contextlib import ExitStack
from pathlib import Path

HERE = Path(__file__).resolve().parent
CAMPAIGNS = ('job', 'job-access', 'routes', 'router', 'public', 'capture', 'mixed', 'mixed-plans', 'mixed-check',
             'mixed-statistics', 'triage', 'workflow', 'live', 'q5', 'rtt', 'replay', 'postgres')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('campaign', choices=CAMPAIGNS)
    parser.add_argument('checkout', type=Path)
    parser.add_argument('output', type=Path, help='unused results directory')
    parser.add_argument('--routes', type=Path, help='plan inventory used to select the dependent cases')
    args = parser.parse_args()
    run, cwd, out = args.campaign, args.checkout.resolve(), args.output.resolve()
    for name, sha in json.loads((HERE/'production-manifest.json').read_text()).items():
        if hashlib.sha256((cwd.parent/name).read_bytes()).hexdigest() != sha:
            raise ValueError(f'Runtime checksum mismatch: {name}')
    out.mkdir()
    files = [HERE/'run.py', HERE/'relay.py', *sorted((HERE/'harness').rglob('*.clj')), *sorted((HERE/'inputs').glob('*'))]
    receipt = {'campaign': run, 'production_manifest': hashlib.sha256((HERE/'production-manifest.json').read_bytes()).hexdigest(),
               'harness': {str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    (out/'inputs.json').write_text(json.dumps(receipt, indent=2)+'\n')
    routes = (args.routes or out.parent/'routes/routes.json').resolve()
    entries = {'job': 'job-repeatability', 'job-access': 'job-access', 'routes': 'job-routes', 'q5': 'job-q5',
               'mixed': 'mixed-public', 'mixed-plans': 'mixed-public', 'mixed-check':'mixed-public',
               'mixed-statistics': 'mixed-statistics',
               'replay': 'replay', 'triage':'triage-public'}
    paths = [HERE/'harness', cwd.parent/'datalevin/benchmarks/tpch-bench/src']
    alias = ('{:aliases {:measurement {:extra-paths [' + ' '.join(json.dumps(str(p)) for p in paths)
             + '] :main-opts ["-m" "datalevin.research.' + entries.get(run, 'placement-controls') + '"]}}}')
    blocks = {'job': 4, 'job-access': 4, 'routes': 1, 'capture': 1, 'mixed-plans': 1, 'triage': 4,
              'postgres': 1, 'workflow': 1, 'live': 1, 'q5': 1}.get(run, 2)
    for b in ([1] if run=='mixed-check' else range(blocks)):
        with ExitStack() as stack:
            print(run, b, flush=True)
            env = os.environ.copy()
            cmd = ['clojure', '-Sdeps', alias, '-M:job-baselines:measurement']
            args_file = out/f'block-{b}.jsonl'
            if run == 'job':
                cmd += [str(b), str(out/f'block-{b}.json'), 'full']
            elif run == 'job-access':
                cmd += [str(b), str(out)]
            elif run == 'mixed-statistics':
                cmd += [str(b), str(args_file)]
            elif run == 'routes':
                cmd += [str(out/'routes.json')]
            elif run == 'q5':
                cmd += [str(HERE/'inputs'), str(HERE/'inputs/q5.sql'), str(out/'q5.json')]
            elif run in ('mixed', 'mixed-plans','mixed-check'):
                cmd += ['mixed' if run=='mixed' else 'mixed-plans', str(b), str(args_file)]
            elif run in ('workflow', 'live', 'postgres'):
                cmd = ['clojure', '-M:job-baselines:'+('workflow-live' if run == 'live' else run)]
                if run == 'postgres':
                    cmd = ['clojure', '-Sdeps', '{:aliases {:conformance {:extra-paths ["../datalevin/test-src"]}}}',
                           '-M:job-baselines:postgres:conformance']
                if run == 'live':
                    env.pop('GITHUB_TOKEN', None)
                if run == 'postgres' and not env.get('POSTGRES_TEST_URL'):
                    raise ValueError('Supply POSTGRES_TEST_URL for a disposable test database')
            elif run == 'triage':
                large = b in (0, 3)
                opts = ('{:name :%s :native-rows %d :export-rows %d :selected-keys 1 :latency-ms 0 '
                        ':batch-rows 64 :binding-rows 64 :warmups 1 :samples 3 :fork %d :input-rows 1}'
                        % ('large-native' if large else 'large-export', 2048 if large else 16,
                           16 if large else 512, 1+b//2))
                cmd = ['clojure', '-Sdeps', alias, '-M:workflow-measure:measurement', opts, str(args_file)]
            elif run == 'replay':
                cmd += [str(b), str(out.parent/'capture/17c-whole.json.gz'), str(args_file)]
            else:
                cmd += [run, str(b), str(args_file), str(routes)]
                if run == 'rtt':
                    from relay import Relay
                    lock = threading.Lock()
                    ports = []
                    for level in ([0, 5, 20] if b == 0 else [20, 5, 0]):
                        relay = Relay(level, out/f'wire-{b}.jsonl', lock)
                        stack.callback(relay.close)
                        ports.append(f'[{level} {relay.port}]')
                    cmd += ['['+' '.join(ports)+']']
            with (out/f'block-{b}.log').open('x') as log:
                subprocess.run(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, env=env, check=True)


if __name__ == '__main__':
    main()
