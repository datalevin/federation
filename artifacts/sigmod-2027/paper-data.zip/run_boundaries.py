"""Measure the frozen JOB clients under both adapter limits and session-local PostgreSQL settings."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

study = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('checkout', type=Path, help='frozen federation checkout')
parser.add_argument('output', type=Path, help='unused results directory')
args = parser.parse_args()
checkout, output = args.checkout.resolve(), args.output.resolve()
manifest = study/'production-manifest.json'
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
for relative, expected in json.loads(manifest.read_text()).items():
    assert digest(checkout.parent/relative) == expected, relative
output.mkdir()
files = [Path(__file__), study/'harness/datalevin/research/job_boundaries.clj',
         study/'harness/datalevin/research/production_job.clj', study/'job/block-0.json']
(output/'inputs.json').write_text(json.dumps(dict(campaign='boundaries', production_manifest=digest(manifest),
    harness={str(p.relative_to(study)):digest(p) for p in files}),indent=2)+'\n')
alias = '{:aliases {:measurement {:extra-paths ['+json.dumps(str(study/'harness'))+'] :main-opts ["-m" "datalevin.research.job-boundaries"]}}}'
for block in range(2):
    argv = ['clojure','-Sdeps',alias,'-M:job-baselines:measurement',str(block),str(output),str(files[-1])]
    with (output/f'block-{block}.log').open('x') as log:
        start = time.time_ns()//1_000_000
        subprocess.run(argv,cwd=checkout,stdout=log,stderr=subprocess.STDOUT,check=True)
    (output/f'block-{block}-launch.json').write_text(json.dumps(dict(start_ms=start,finish_ms=time.time_ns()//1_000_000))+'\n')
