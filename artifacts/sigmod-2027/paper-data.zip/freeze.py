"""Freeze the production code, classes, benchmarks and test fixtures used here."""
from pathlib import Path
import hashlib
import json
import shutil
import argparse
import tarfile

study = Path(__file__).resolve().parent
repo = study.parents[2]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('frozen', type=Path, help='new directory for the paired checkouts')
parser.add_argument('output', type=Path, help='new directory for the archive and source manifest')
args = parser.parse_args()
root = args.frozen.resolve()
output = args.output.resolve()
if root.exists() or output.exists():
    parser.error('Both destinations must be new directories')
root.mkdir()
output.mkdir()
files = {
    'datalevin': ['deps.edn', 'project.clj', 'src/data_readers.clj', 'src/datalevin',
                  'src/java', 'src/pod', 'resources', 'target/classes', 'test-src',
                  'benchmarks/JOB-bench/queries', 'benchmarks/tpch-bench/src'],
    'federation': ['deps.edn', 'dev/src', 'examples/src', 'test']
                  + [f'{module}/{sub}' for module in ['core', 'postgres', 'file', 'github', 'local']
                     for sub in ['src', 'project.clj', 'test']]
}
hashes = {}
for name, paths in files.items():
    base = repo.parent / name
    for relative in paths:
        path = base / relative
        if not path.exists():
            if relative.endswith('/test'):
                continue
            raise FileNotFoundError(path)
        for file in sorted(path.rglob('*') if path.is_dir() else [path]):
            if not file.is_file() or file.name == '.DS_Store':
                continue
            member = Path(name) / file.relative_to(base)
            dest = root / member
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(file, dest)
            hashes[str(member)] = hashlib.sha256(dest.read_bytes()).hexdigest()
for name, digest in hashes.items():
    assert hashlib.sha256((repo.parent / name).read_bytes()).hexdigest()==digest, name
(output / 'production-manifest.json').write_text(json.dumps(hashes,indent=2,sort_keys=True)+'\n')
with tarfile.open(output / 'production-runtime.tar.gz','x:gz') as tar:
    for name in sorted(hashes):
        tar.add(root / name, arcname=name, recursive=False)
print(len(hashes),root)
