(ns datalevin.research.job-boundaries
  (:require [clojure.java.io :as io]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.query.source.control :as control]
            [datalevin.research.production-job :as production]
            [jsonista.core :as json]))

(def profile {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/postgres"
              :properties {"user" (System/getProperty "user.name")
                           "ApplicationName" "datalevin-job-boundaries"}
              :compute-context-id :benchmark/production-summary
              :statement-timeout-ms 300000 :max-row-bytes 262144})
(def profiles {:inherited profile
               :larger (assoc-in profile [:properties "options"] "-c work_mem=64MB")
               :serial (assoc-in profile [:properties "options"] "-c max_parallel_workers_per_gather=0")})
(def split-ids #{:6b :6d :10c :17b :17c :17d :20b})
(def cells [[:original :inherited] [:benchmark :inherited] [:default :inherited]
            [:original :larger] [:default :larger]])
(def serial-cells [[:original :serial] [:default :serial]])
(def settings-sql
  "SELECT name, setting, coalesce(unit,''), boot_val, source FROM pg_settings WHERE name IN ('work_mem','max_parallel_workers_per_gather')")
(defn timed [f]
  (let [t (System/nanoTime) v (f)]
    [(- (System/nanoTime) t) v]))

(defn query-for [spec limits]
  (assoc (:query spec) :timeout 300000 :query-source
         (cond-> {:native-extrema (:native-extrema spec)}
           limits (assoc :limits limits)
           (seq (:ignore-nil-extrema spec)) (assoc :ignore-nil-extrema (:ignore-nil-extrema spec)))))

(defn prepare [catalogs entry]
  (let [[parse-ns parsed] (timed #(sql/parse (:sql entry)))
        [render-ns original] (timed #(sql/sql-query parsed "public" true))
        [translate-ns spec] (timed #(sql/compile-query parsed catalogs))]
    {:original original :spec spec
     :costs {:parse-ns parse-ns :original-render-ns render-ns :translate-ns translate-ns}}))

(defn measure-cell [prepared catalogs [arm config] opts]
  (let [runtime-profile (profiles config)]
    (if (= :original arm)
      (suite/attempt #(suite/native! runtime-profile (:original prepared)))
      (let [[maps-ns providers] (timed #(sql/sources! runtime-profile catalogs (:spec prepared)))
            [wrap-ns query] (timed #(query-for (:spec prepared) (when (= :benchmark arm) (:limits opts))))
            result (suite/attempt
                     #(try (set (apply d/q query providers))
                           (finally
                             (assert (every? (fn [p] (zero? (:live-sessions (pg/statistics p)))) providers)))))]
        (assoc result :mapping-providers-ns maps-ns :query-options-ns wrap-ns)))))

(defn ordered-cells [n block cells]
  (let [k (mod n (count cells))
        rotated (vec (concat (subvec cells k) (subvec cells 0 k)))]
    (if (odd? block) (rseq rotated) rotated)))

(defn emit! [file row]
  (spit file (str (json/write-value-as-string row) "\n") :append true))

(defn -main [block-str destination oracle-path]
  (let [block (parse-long block-str)
        start-ms (System/currentTimeMillis)
        out #(io/file destination (str "block-" block %))
        opts (suite/options! {:samples 1 :warmups 0 :verify-tuples? false :timeout-ms 300000})
        [read-ns corpus] (timed #(suite/corpus! opts))
        [inventory-ns tables] (timed #(sort (into #{} (mapcat (fn [e] (map second (:from (sql/parse (:sql e))))) corpus))))
        tables (vec tables)
        [discover-ns catalogs] (timed #(into {} (map (fn [t] [t (pg/discover profile ["public" t])]) tables)))
        [before-ns before] (timed #(production/source-state profile tables))
        oracle (into {} (for [q (get-in (json/read-value (slurp oracle-path)) ["phases" "warm"])]
                          [(get q "id") {:sha (get q "sha256") :rows (set (get q "expected"))}]))
        settings (into {} (for [[k p] profiles] [k (sort (suite/native! p settings-sql))]))
        metadata {:block block :main-start-ms start-ms :corpus-read-ns read-ns :inventory-parse-ns inventory-ns
                  :discovery-ns discover-ns :catalog-tables tables :settings settings
                  :engine-defaults control/default-limits :benchmark-limits (:limits opts)
                  :source-before before :source-before-ns before-ns}]
    (assert (= [(:retained-bytes control/default-limits) (:external-requests control/default-limits)] [1073741824 1024]))
    (assert (= [(:retained-bytes (:limits opts)) (:external-requests (:limits opts))] [8589934592 16384]))
    (doseq [[k wm workers] [[:inherited "4096" "2"] [:larger "65536" "2"] [:serial "4096" "0"]]]
      (let [s (into {} (map (juxt first second) (settings k)))]
        (assert (= [wm workers] [(s "work_mem") (s "max_parallel_workers_per_gather")]))))
    (spit (out "-setup.json") (json/write-value-as-string metadata))
    (try
      ;; Prime whole and split paths for both clients. No measured full pass is a JVM cold start.
      (doseq [id [:2c :17c] :let [entry (first (filter #(= id (:id %)) corpus))
                                    prep (prepare catalogs entry)] cell [[:original :inherited] [:default :inherited]]]
        (let [r (measure-cell prep catalogs cell opts)]
          (assert (or (= :ok (:status r)) (= :query-source/limit (get-in r [:failure :error]))))))
      (doseq [[idx entry] (if (even? block) (map-indexed vector corpus) (reverse (map-indexed vector corpus)))]
        (let [id (:id entry) expected (oracle (name id))
              _ (assert (= (:sha expected) (:sha256 entry)))
              prep (prepare catalogs entry)
              variants (cond-> cells (split-ids id) (into serial-cells))
              rows (mapv (fn [[arm config :as cell]]
                           (let [r (measure-cell prep catalogs cell opts)
                                 [check-ns ok] (timed #(when (= :ok (:status r))
                                                        (= (:rows expected)
                                                           (if (and (not= :original arm) (empty? (:result r)))
                                                             #{(vec (repeat (count (:outputs (:spec prep))) nil))}
                                                             (:result r)))))]
                             (when (= :ok (:status r)) (assert ok (str id " " cell)))
                             (assoc r :arm arm :config config :answer-matches ok :check-ns check-ns)))
                         (ordered-cells idx block variants))]
          (emit! (out ".jsonl") {:query id :sha256 (:sha256 entry) :setup (:costs prep) :cells rows})))
      (let [[after-ns after] (timed #(production/source-state profile tables))]
        (assert (= before after))
        (spit (out "-complete.json") (json/write-value-as-string {:source-after after :source-after-ns after-ns})))
      (finally (shutdown-agents)))))
