(ns datalevin.research.job-routes
  (:require [clojure.java.io :as io]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [jsonista.core :as json])
  (:import [java.security MessageDigest]
           [java.util HexFormat]))

(defn planner-sha []
  (with-open [source (io/input-stream (io/resource "datalevin/query/source/planning.clj"))]
    (.formatHex (HexFormat/of)
                (.digest (MessageDigest/getInstance "SHA-256") (.readAllBytes source)))))

(defn describe [profile opts catalogs entry]
  (let [spec (sql/compile-query (sql/parse (:sql entry)) catalogs)
        providers (sql/sources! profile catalogs spec)
        query (assoc (:query spec) :timeout (:timeout-ms opts)
                     :query-source (cond-> {:limits (:limits opts)
                                            :native-extrema (:native-extrema spec)}
                                     (seq (:ignore-nil-extrema spec))
                                     (assoc :ignore-nil-extrema (:ignore-nil-extrema spec))))
        plan (apply d/explain {:run? false} query providers)
        policies (mapv :policy (:regions plan))
        terminal (:operators plan)
        route (cond (:relational? terminal) :whole
                    (:relational-fragment? terminal) :fragment
                    (seq policies) :coordinator
                    :else (throw (ex-info "Plan has no selected route" {:query (:id entry)})))]
    (assert (every? #(zero? (:live-sessions (pg/statistics %))) providers))
    (assert (= (= policies [:relational-v1]) (= route :whole)))
    (assoc (select-keys entry [:id :sha256]) :route route :policies policies
           :steps (mapv (fn [region]
                          (mapv #(select-keys % [:source :source-symbol :alternative-id :requires])
                                (:steps region))) (:regions plan)))))

(defn -main [out]
  (let [opts (suite/options! {:samples 1 :warmups 0 :verify-tuples? false :timeout-ms 300000})
        profile {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/postgres"
                 :properties {"user" (System/getProperty "user.name")
                              "ApplicationName" "datalevin-job-route-check"}
                 :compute-context-id :benchmark/production-summary :statement-timeout-ms 300000
                 :max-row-bytes (:max-row-bytes opts)}
        entries (suite/corpus! opts)
        tables (sort (into #{} (mapcat #(map second (:from (sql/parse (:sql %)))) entries)))
        catalogs (into {} (map (fn [t] [t (pg/discover profile ["public" t])]) tables))]
    (spit out (json/write-value-as-string {:planner (planner-sha)
                                           :plans (mapv #(describe profile opts catalogs %) entries)}))
    (shutdown-agents)))
