(ns datalevin.research.mixed-public
  (:require [clojure.java.io :as io]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres.jdbc :as jdbc]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.research.placement-controls :as controls]
            [datalevin.research.public-plans :as plans]
            [jsonista.core :as json])
  (:import [java.sql Connection DriverManager]
           [java.util Properties UUID]))

(defn connection ^Connection [profile]
  (let [properties (Properties.)]
    (doseq [[k v] (:properties profile)] (.setProperty properties k v))
    (DriverManager/getConnection (:jdbc-url profile) properties)))

(defn execute! [^Connection conn sql]
  (with-open [s (.createStatement conn)] (.setQueryTimeout s 60) (.execute s sql)))

(def fixtures
  [{:id :tiny :owners 8192 :fanout 2 :keys 16 :stride 17 :copies 1}
   {:id :sparse :owners 8192 :fanout 16 :keys 128 :stride 17 :copies 1}
   {:id :dense :owners 8192 :fanout 16 :keys 1024 :stride 1 :copies 1}
   {:id :high-fanout :owners 8192 :fanout 128 :keys 256 :stride 17 :copies 1}
   {:id :skewed :owners 8192 :fanout 8 :keys 128 :stride 1 :copies 1 :hot-fanout 128}
   {:id :witnesses :owners 8192 :fanout 16 :keys 64 :stride 17 :copies 4}])

(defn owner-keys [{:keys [owners keys stride]}]
  (mapv #(inc (mod (* % stride) owners)) (range keys)))

(defn degree [{:keys [fanout hot-fanout]} owner]
  (if (and hot-fanout (<= owner 128)) hot-fanout fanout))

(defn target-floor [owner]
  (mod (* 11 owner) 4096))

(defn expected [{:keys [copies local-floor?] :as fixture}]
  (into #{} (for [owner (owner-keys fixture) witness (range copies)
                  slot (range 1 (inc (degree fixture owner)))
                  :let [target (inc (mod (+ (* (dec owner) 131) (dec slot)) 4096))
                        category (inc (mod (* target 7) 256))]
                  :when (and (zero? (mod category 4)) (or (not local-floor?) (> target (target-floor owner))))]
              [owner witness target (str "category-" category)])))

(defn setup-schema! [conn schema owned? {:keys [owners fanout hot-fanout]}]
  (let [relation #(jdbc/relation [schema %])]
    (execute! conn (str "CREATE SCHEMA " (jdbc/identifier schema)))
    (reset! owned? true)
    (doseq [statement
            [(str "CREATE TABLE " (relation "category") " (id integer PRIMARY KEY, allowed boolean NOT NULL, label text NOT NULL)")
             (str "INSERT INTO " (relation "category") " SELECT i,i%4=0,'category-'||i FROM generate_series(1,256) g(i)")
             (str "CREATE TABLE " (relation "target") " (id integer PRIMARY KEY, category integer NOT NULL)")
             (str "INSERT INTO " (relation "target") " SELECT i,(i*7)%256+1 FROM generate_series(1,4096) g(i)")
             (str "CREATE INDEX target_category ON " (relation "target") "(category)")
             (str "CREATE TABLE " (relation "edge") " (id bigint PRIMARY KEY, owner integer NOT NULL, target integer NOT NULL)")
             (str "INSERT INTO " (relation "edge") " SELECT (p-1)::bigint*1024+s,p,(((p-1)::bigint*131+s-1)%4096+1)::integer "
                  "FROM generate_series(1," owners ") p CROSS JOIN LATERAL generate_series(1,"
                  (if hot-fanout (str "CASE WHEN p<=128 THEN " hot-fanout " ELSE " fanout " END") (str fanout)) ") s")
             (str "CREATE INDEX edge_owner ON " (relation "edge") "(owner)")
             (str "CREATE INDEX edge_target ON " (relation "edge") "(target)")
             (str "ANALYZE " (relation "category"))
             (str "ANALYZE " (relation "target"))
             (str "ANALYZE " (relation "edge"))]]
      (execute! conn statement))))

(defn mixed-prepared! [profile schema fixture]
  (let [source-id (UUID/randomUUID)
        specs [["edge" :edge/entity {:edge/owner "owner" :edge/target "target"}]
               ["target" :target/entity {:target/id "id" :target/category "category"}]
               ["category" :category/entity {:category/id "id" :category/allowed "allowed" :category/label "label"}]]
        providers (mapv (fn [[table identity attributes]]
                          (pg/source (pg/accept-mapping (pg/discover profile [schema table])
                                       {:source-instance-id source-id :relation-id (keyword "work" table)
                                        :identity-attribute identity :attributes attributes}) profile)) specs)
        conn (d/create-conn nil {:seed/key {:db/valueType :db.type/long}
                                :seed/witness {:db/valueType :db.type/long}
                                :seed/min-target {:db/valueType :db.type/long}
                                :seed/selected {:db/valueType :db.type/boolean}}
                           {:kv-opts {:inmemory? true} :background-sampling? false})
        keys (set (owner-keys fixture))]
    (d/transact! conn (vec (for [owner (range 1 (inc (:owners fixture))) witness (range (:copies fixture))]
                            (cond-> {:seed/key owner :seed/witness witness :seed/selected (boolean (keys owner))}
                              (:local-floor? fixture) (assoc :seed/min-target (target-floor owner))))))
    {:conn conn :providers providers
     :prepared {:providers (into [@conn] providers)
                :query {:find '[?owner ?witness ?target ?label] :in '[$native $edge $target $category]
                        :where (cond-> '[[$native ?seed :seed/selected true]
                                 [$native ?seed :seed/key ?owner]
                                 [$native ?seed :seed/witness ?witness]
                                 [$edge ?edge :edge/owner ?owner]
                                 [$edge ?edge :edge/target ?target]
                                 [$target ?t :target/id ?target]
                                 [$target ?t :target/category ?category]
                                 [$category ?c :category/id ?category]
                                 [$category ?c :category/allowed true]
                                 [$category ?c :category/label ?label]]
                                 (:local-floor? fixture)
                                 (conj '[$native ?seed :seed/min-target ?floor] '[(> ?target ?floor)]))
                        :timeout 30000 :query-source {:limits (:limits suite/defaults)}}}}))

(defn run-mode [profile schema fixture expected mode diagnostic out]
  (let [profile (cond-> profile (= mode :prefix) (assoc :bound-join-mode :protected-prefix))
        {:keys [conn providers prepared]} (mixed-prepared! profile schema fixture)
        {:keys [query]} prepared
        selection (let [p (apply d/explain {:run? false} query (:providers prepared))]
                    {:policies (mapv :policy (:regions p))
                     :ids (vec (for [r (:regions p) s (:steps r)] (:alternative-id s)))})
        run (fn [ps]
              (let [before (reduce + (map #(:external-requests (pg/statistics %)) ps))
                    start (System/nanoTime)
                    result (try {:rows (set (apply d/q query @conn ps))}
                                (catch clojure.lang.ExceptionInfo e
                                  (let [details (ex-data e)]
                                    (if (#{:query/timeout :query-source/timeout :query-source/limit} (:error details))
                                      {:failure (select-keys details [:error :phase :category :maximum])}
                                      (throw e)))))
                    elapsed (- (System/nanoTime) start)
                    after (reduce + (map #(:external-requests (pg/statistics %)) ps))]
                (assert (every? #(zero? (:live-sessions (pg/statistics %))) ps))
                (when (contains? result :rows)
                  (assert (= expected (:rows result)) (str (:id fixture) " answer mismatch")))
                (merge {:elapsed-ns elapsed :requests (- after before)}
                       (if (:failure result) result {:rows (count (:rows result))}))))]
    (try
      (assoc (if diagnostic
               (plans/capture out (:id fixture) mode
                 (fn [pool reset-trace!]
                   (let [cfg (assoc (dissoc profile :jdbc-url) :data-source pool)
                         diagnostic (mixed-prepared! cfg schema fixture)]
                     (try
                       (let [ps (:providers diagnostic) plan (apply d/explain {:run? false} query @conn ps)]
                         (assert (= (:ids selection) (vec (for [r (:regions plan) s (:steps r)] (:alternative-id s)))))
                         (reset-trace!)
                         (run ps))
                       (finally (d/close (:conn diagnostic)))))))
               (run providers))
             :mode mode :plan selection)
      (finally (d/close conn)))))

(defn -main [campaign block output]
  (let [idx (parse-long block) diag? (= campaign "mixed-plans")
        base (filter #(#{:dense :high-fanout} (:id %)) fixtures)
        cases (concat base (map #(assoc % :local-floor? true :id (keyword (str (name (:id %)) "-floor"))) base))
        modes [:auto :prefix]]
    (with-open [db (connection controls/profile) w (io/writer output)]
      (doseq [f (if (even? idx) cases (reverse cases))]
        (let [schema (str "dtlv_pfx_" (.replace (str (UUID/randomUUID)) "-" ""))
              owned? (atom false) answer (expected f)]
          (try
            (setup-schema! db schema owned? f)
            (doseq [sample (if diag? [0] [-1 0 1])
                    mode (if (even? (+ idx sample)) modes (reverse modes))]
              (let [r (run-mode controls/profile schema f answer mode diag? (.getParentFile (io/file output)))]
                (.write w (str (json/write-value-as-string (assoc r :id (:id f) :sample sample :block idx)) "\n"))
                (.flush w)))
            (finally (when @owned? (execute! db (str "DROP SCHEMA " (jdbc/identifier schema) " CASCADE"))))))))
    (shutdown-agents)))
