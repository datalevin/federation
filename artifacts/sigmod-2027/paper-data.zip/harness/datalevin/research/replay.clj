(ns datalevin.research.replay
  (:require [clojure.java.io :as io]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres.jdbc :as jdbc]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.research.placement-controls :as c]
            [jsonista.core :as json])
  (:import [java.sql DriverManager] [java.util.zip GZIPInputStream]))

(defn direct [statement params]
  (with-open [conn (DriverManager/getConnection (:jdbc-url c/profile) (System/getProperty "user.name") "")]
    (let [context {:connection conn :profile c/profile :cancelled (atom false)}]
      (try
        (jdbc/begin! context)
        (with-open [s (jdbc/statement context statement params)
                    rs (.executeQuery s)]
          (assert (and (.next rs) (= 4 (.getColumnCount (.getMetaData rs)))
                       (false? (.getObject rs 1)) (false? (.getObject rs 2))))
          (let [row [(.getObject rs 3) (.getObject rs 4)]]
            (assert (not (.next rs)))
            #{row}))
        (finally (.rollback conn))))))

(defn -main [block path out]
  (let [trace (with-open [in (GZIPInputStream. (io/input-stream path))] (json/read-value in))
        hits (filter #(.startsWith ^String (% "sql") "WITH matched AS") (trace "queries"))
        _ (assert (= 1 (count hits))) captured (first hits)
        entry (first (suite/corpus! (assoc c/opts :queries [:17c])))
        parsed (sql/parse (:sql entry))
        catalogs (into {} (for [t (distinct (map second (:from parsed)))] [t (pg/discover c/profile ["public" t])]))
        spec (sql/compile-query parsed catalogs) providers (sql/sources! (assoc c/profile :whole-query-mode :sql) catalogs spec)
        query (assoc (:query spec) :timeout (:timeout-ms c/opts) :query-source
                     (cond-> {:native-extrema (:native-extrema spec) :limits (:limits c/opts)}
                       (seq (:ignore-nil-extrema spec)) (assoc :ignore-nil-extrema (:ignore-nil-extrema spec))))
        oracle (suite/native! c/profile (sql/sql-query parsed "public" true))]
    (assert (:whole (c/inspect query providers)))
    (with-open [w (io/writer out)]
      (doseq [i [-1 0 1] arm (if (even? (+ i (parse-long block))) [:direct :adapter] [:adapter :direct])]
        (let [start (System/nanoTime)
              rows (if (= arm :direct) (direct (captured "sql") (captured "params")) (set (apply d/q query providers)))
              elapsed (- (System/nanoTime) start)]
          (assert (= oracle rows))
          (assert (every? #(zero? (:live-sessions (pg/statistics %))) providers))
          (.write w (str (json/write-value-as-string {:mode arm :sample i :block block :elapsed-ns elapsed :answer rows}) "\n")))))
    (shutdown-agents)))
