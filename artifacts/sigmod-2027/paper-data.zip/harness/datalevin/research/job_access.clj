(ns datalevin.research.job-access
  (:require [clojure.java.io :as io]
            [clojure.string :as str]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.research.job-routes :as routes]
            [datalevin.research.production-job :as production]
            [jsonista.core :as json])
  (:import [java.time Instant]))

(defn source-state [profile tables]
  (assert (every? #(re-matches #"[a-z_]+" %) tables))
  (let [names (str/join "," (map #(str "'" % "'") tables))
        stats (str "SELECT (SELECT md5(string_agg(to_jsonb(s)::text,'|' ORDER BY tablename,attname,inherited))"
                   " FROM pg_stats s WHERE schemaname='public' AND tablename IN (" names ")),"
                   "(SELECT md5(string_agg(concat_ws(':',c.oid,c.relpages,c.reltuples,c.relallvisible),'|' ORDER BY c.relname))"
                   " FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace"
                   " WHERE n.nspname='public' AND c.relname IN (" names "))")]
    {:inventory (production/source-state profile tables)
     :statistics (first (suite/native! profile stats))}))

(defn access-id [step]
  [(or (:source-symbol step) (:source step)) (:alternative-id step)])

(defn execute [profile opts catalogs entry]
  (let [spec (sql/compile-query (sql/parse (:sql entry)) catalogs)
        providers (sql/sources! profile catalogs spec)
        query (assoc (:query spec) :timeout (:timeout-ms opts)
                     :query-source (cond-> {:limits (:limits opts) :native-extrema (:native-extrema spec)}
                                     (seq (:ignore-nil-extrema spec))
                                     (assoc :ignore-nil-extrema (:ignore-nil-extrema spec))))
        plan (apply d/explain {:run? true :intermediate-counts? false} query providers)
        selected (mapv (fn [r] (mapv access-id (filter :alternative-id (:steps r)))) (:regions plan))
        opens (partition-by identity (map access-id (:cursors plan)))
        stats (mapv pg/statistics providers)]
    (assert (and (:executed? plan) (seq opens) (every? #(zero? (:live-sessions %)) stats)))
    (assert (every? (set (mapcat identity selected)) (map first opens)))
    {:id (:id entry) :sql-sha256 (:sha256 entry) :whole (boolean (get-in plan [:operators :relational?]))
     :selected selected :cursor-runs (mapv (fn [run] [(first run) (count run)]) opens)
     :result-rows (:result-rows plan) :provider-requests (mapv :external-requests stats)}))

(defn -main [block out]
  (let [b (parse-long block)
        opts (suite/options! {:samples 1 :warmups 0 :verify-tuples? false :timeout-ms 300000})
        profile {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/postgres"
                 :properties {"user" (System/getProperty "user.name") "ApplicationName" "datalevin-job-access"}
                 :compute-context-id :benchmark/production-summary :statement-timeout-ms 300000
                 :max-row-bytes (:max-row-bytes opts)}
        corpus (suite/corpus! opts)
        entries (if (odd? b) (rseq corpus) corpus)
        tables (sort (set (mapcat #(map second (:from (sql/parse (:sql %)))) entries)))
        catalogs (into {} (for [t tables] [t (pg/discover profile ["public" t])]))
        start (str (Instant/now))
        before (source-state profile tables)]
    (with-open [w (io/writer (io/file out (str "block-" b ".jsonl")))]
      (doseq [phase [:cold :warm] entry entries]
        (let [record (assoc (execute profile opts catalogs entry) :block b :phase phase)]
          (.write w (str (json/write-value-as-string record) "\n"))
          (.flush w))))
    (spit (io/file out (str "state-" b ".json"))
          (json/write-value-as-string
            {:block b :pid (.pid (java.lang.ProcessHandle/current)) :start start :end (str (Instant/now))
             :planner (routes/planner-sha) :before before :after (source-state profile tables)}))
    (shutdown-agents)))
