(ns datalevin.research.job-small-client
  (:require [clojure.java.io :as io]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.research.job-boundaries :as bounds]
            [jsonista.core :as json])
  (:import [java.lang.management ManagementFactory]))

(defn -main [dest oracle-file]
  (try
    (let [max-heap (.maxMemory (Runtime/getRuntime))
          args (.getInputArguments (ManagementFactory/getRuntimeMXBean))
          _ (assert (= max-heap 1073741824))
          opts (suite/options! {})
          corpus (suite/corpus! opts)
          catalogs (into {} (for [t (sort (into #{} (mapcat #(map second (:from (sql/parse (:sql %)))) corpus)))]
                              [t (pg/discover bounds/profile ["public" t])]))
          oracle (into {} (for [q (get-in (json/read-value (slurp oracle-file)) ["phases" "warm"])]
                            [(get q "id") (set (get q "expected"))]))]
      (spit (io/file dest "client.json")
            (json/write-value-as-string {:pid (.pid (java.lang.ProcessHandle/current)) :max-heap max-heap
                                         :heap-and-direct-flags (filterv #(re-find #"^-Xm[sx]|^-XX:MaxDirectMemorySize" %) args)}))
      (doseq [entry corpus]
        (let [prep (bounds/prepare catalogs entry)
              r (bounds/measure-cell prep catalogs [:default :inherited] opts)
              answer (if (empty? (:result r)) #{(vec (repeat (count (:outputs (:spec prep))) nil))} (:result r))
              matches (and (= :ok (:status r)) (= answer (oracle (name (:id entry)))))]
          (bounds/emit! (io/file dest "calls.jsonl")
                        (assoc r :query (:id entry) :sha256 (:sha256 entry) :answer-matches matches))
          (when (= :ok (:status r)) (assert matches (name (:id entry)))))))
    (finally (shutdown-agents))))
