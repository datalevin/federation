(ns datalevin.research.triage-public
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]
            [datalevin.core :as d]
            [datalevin.federation.file :as export]
            [datalevin.federation.github :as github]
            [datalevin.federation.release-triage :as triage]
            [datalevin.federation.workflow-fixture :as fixture]
            [jsonista.core :as json]))

(def threshold 9)
(defn invoke [q f sources]
  (d/q q @(:conn f) (:github sources) (:release sources) 42 threshold [["now" "witness-0"]]))

(defn counters [f]
  (let [api @(get-in f [:api :requests])
        file (export/statistics (get-in f [:sources :release]))]
    {:issue-gets (:issues api 0) :repository-gets (:repository api 0)
     :validated-records (:validated-records file 0)}))

(defn -main [options output]
  (let [opts (edn/read-string options)
        f (fixture/create! opts)
        q (-> triage/lookup-query (update :where conj '[(= ?window "now")])
              (assoc :timeout 120000)
              (assoc-in [:query-source :limits] {:binding-rows 64 :batch-rows 64 :retained-bytes 268435456
                                                 :external-requests 8192 :spill-bytes 67108864}))
        forms {:parameter q :literal (assoc-in q [:where 3] '[(>= ?priority 9)])
               :caller (update q :where #(into (subvec % 0 3) (subvec % 4)))}
        arms (if (= 1 (:fork opts)) [:parameter :literal :caller] [:caller :literal :parameter])]
    (try
      (let [oracle (invoke (dissoc q :query-source) f (fixture/eager f))]
        (assert (= 1 (count oracle)))
        (with-open [w (io/writer output)]
          (doseq [sample [-1 0 1 2]
                  arm (take 3 (drop (mod sample 3) (cycle arms)))]
            (let [before (counters f) start (System/nanoTime)
                  result (invoke (forms arm) f (:sources f))
                  rows (if (= arm :caller) (into #{} (filter #(>= (nth % 1) threshold)) result) result)
                  elapsed (- (System/nanoTime) start)]
              (assert (= oracle rows))
              (assert (and (fixture/clean? f) (zero? (:live-sessions (github/statistics (get-in f [:sources :github]))))
                           (zero? (:live-spools (export/statistics (get-in f [:sources :release]))))))
              (.write w (str (json/write-value-as-string
                              {:fixture (:name opts) :native (:native-rows opts) :export (:export-rows opts)
                               :fork (:fork opts) :sample sample :mode arm :answer rows
                               :elapsed-ns elapsed :unfiltered-rows (count result)
                               :work (merge-with - (counters f) before)}) "\n"))
              (.flush w)))))
      (finally ((:close! f)) (shutdown-agents)))))
