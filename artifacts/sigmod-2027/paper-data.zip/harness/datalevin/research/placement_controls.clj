(ns datalevin.research.placement-controls
  (:require [clojure.edn]
            [clojure.java.io :as io]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [jsonista.core :as json])
  (:import [java.security MessageDigest]
           [java.util HexFormat]))

(def opts (suite/options! {:verify-tuples? false :timeout-ms 180000}))
(def profile {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/postgres"
              :properties {"user" (System/getProperty "user.name")
                           "ApplicationName" "datalevin-placement-controls"}
              :compute-context-id :benchmark/production-summary
              :statement-timeout-ms 180000 :max-row-bytes (:max-row-bytes opts)})

(defn sha [path]
  (with-open [in (io/input-stream (io/resource path))]
    (.formatHex (HexFormat/of) (.digest (MessageDigest/getInstance "SHA-256") (.readAllBytes in)))))

(defn inspect [query providers]
  (let [plan (apply d/explain {:run? false} query providers)]
    {:whole (boolean (get-in plan [:operators :relational?]))
     :ids (vec (for [r (:regions plan) s (:steps r)] (:alternative-id s)))}))

(defn run-case [profile catalogs entry modes index ordinal diagnostic]
  (let [parsed (sql/parse (:sql entry))
        spec (sql/compile-query parsed catalogs)
        query (assoc (:query spec) :timeout (:timeout-ms opts) :query-source
                     (cond-> {:limits (:limits opts) :native-extrema (:native-extrema spec)}
                       (seq (:ignore-nil-extrema spec)) (assoc :ignore-nil-extrema (:ignore-nil-extrema spec))))
        oracle (suite/native! profile (sql/sql-query parsed "public" true))
        arms (into {} (for [[mode options] modes]
                        [mode (sql/sources! (assoc-in (merge profile options) [:properties "ApplicationName"]
                                                     (str "placement-" (name (:id entry)) "-" (name mode))) catalogs spec)]))
        plans (into {} (for [[arm providers] arms] [arm (inspect query providers)]))
        _ (when (contains? arms :sql)
            (assert (and (not (get-in plans [:auto :whole])) (get-in plans [:sql :whole])) (str plans)))
        call (fn [arm providers]
               (let [wall-start (System/currentTimeMillis) start (System/nanoTime) result (set (apply d/q query providers))
                     elapsed (- (System/nanoTime) start) wall-end (System/currentTimeMillis)
                     normalized (if (seq result) result #{(vec (repeat (count (:outputs spec)) nil))})]
                 (assert (= oracle normalized) (str "Answer mismatch " [arm (:id entry)]))
                 (assert (every? #(zero? (:live-sessions (pg/statistics %))) providers))
                 {:mode arm :elapsed-ns elapsed :start-ms wall-start :end-ms wall-end :answer normalized}))]
    (merge {:id (:id entry) :sql-sha (:sha256 entry) :oracle oracle :plans plans}
           (if diagnostic
             {:captures (into {} (for [[mode options] modes]
                                   [mode (diagnostic (:id entry) mode
                                            (fn [pool reset-trace!]
                                              (let [p (assoc (dissoc (merge profile options) :jdbc-url) :data-source pool)
                                                    ps (sql/sources! p catalogs spec)]
                                                (assert (= (plans mode) (inspect query ps)))
                                                (reset-trace!)
                                                (call mode ps))))]))}
             {:calls (vec (for [sample [-1 0 1]
                                [arm _] (if (even? (+ index ordinal sample)) modes (reverse modes))]
                            (assoc (call arm (arms arm)) :sample sample)))}))))

(defn calibrate [profile]
  (with-open [conn (java.sql.DriverManager/getConnection (:jdbc-url profile) (System/getProperty "user.name") "")
              statement (.createStatement conn)]
    (mapv (fn [_]
            (let [start (System/nanoTime)]
              (with-open [rows (.executeQuery statement "SELECT 1")]
                (assert (and (.next rows) (= 1 (.getInt rows 1)))))
              (- (System/nanoTime) start))) (range 12))))

(defn -main [campaign block output routes-file & [relay-ports]]
  (let [index (parse-long block) router? (#{"router" "rtt"} campaign)
        diagnostic (when (= campaign "capture") (partial (requiring-resolve 'datalevin.research.public-plans/capture) (.getParentFile (io/file output))))
        ids (for [plan (get (json/read-value (slurp routes-file)) "plans")
                  :when (not= "whole" (plan "route"))] (keyword (plan "id")))
        entries (suite/corpus! (assoc opts :queries (if relay-ports [:17c] (vec ids))))
        queries (if (even? index) entries (reverse entries))
        catalogs (into {} (for [t (sort (set (mapcat #(map second (:from (sql/parse (:sql %)))) entries)))]
                            [t (pg/discover profile ["public" t])]))
        modes (if router? [[:auto {}] [:sql {:whole-query-mode :sql}]]
                  (cond-> [[:auto {}] [:prefix {:bound-join-mode :protected-prefix}]] diagnostic (conj [:whole {:whole-query-mode :sql}])))
        hashes (into {} (for [p ["datalevin/query/source/planning.clj" "datalevin/federation/postgres.clj"
                                  "datalevin/federation/postgres/joins.clj" "datalevin/federation/postgres/relational.clj"]]
                          [p (sha p)]))]
    (with-open [writer (io/writer output)]
      (doseq [[level port] (if relay-ports (clojure.edn/read-string relay-ports) [[0 5432]])
              [ordinal entry] (map-indexed vector queries)]
        (let [p (if relay-ports (assoc profile :jdbc-url (str "jdbc:postgresql://127.0.0.1:" port "/postgres?sslmode=disable&gssEncMode=disable&assumeMinServerVersion=12")) profile)
              before (when relay-ports (calibrate p))
              result (cond-> (run-case p catalogs entry modes index ordinal diagnostic)
                       relay-ports (assoc :calibration-before before :calibration-after (calibrate p)))]
          (.write writer (str (json/write-value-as-string (assoc result :block index :added-rtt-ms level :sources hashes)) "\n"))
          (.flush writer)
          (println campaign block (:id entry)) (flush))))
    (shutdown-agents)))
