(ns datalevin.research.public-plans
  "Observe SQL on the public JDBC DataSource boundary during separate diagnostic calls."
  (:require [clojure.java.io :as io]
            [clojure.string :as str]
            [jsonista.core :as json])
  (:import [java.lang.reflect InvocationHandler InvocationTargetException Method Proxy]
           [java.sql Connection DriverManager PreparedStatement SQLWarning Statement]
           [java.util.zip GZIPOutputStream]
           [javax.sql DataSource]))

(defn delegate [target ^Method method args]
  (try (.invoke method target args)
       (catch InvocationTargetException e (throw (.getCause e)))))

(defn wrap [interface f]
  (Proxy/newProxyInstance (.getClassLoader ^Class interface) (into-array Class [interface])
    (reify InvocationHandler
      (invoke [_ proxy method args]
        (case (.getName method)
          "hashCode" (Integer/valueOf (System/identityHashCode proxy))
          "equals" (identical? proxy (aget args 0))
          (f method args))))))

(defn record-warnings! [trace resource]
  (loop [^SQLWarning w (if (instance? Connection resource) (.getWarnings ^Connection resource) (.getWarnings ^Statement resource))]
    (when w
      (let [msg (.getMessage w) start (.indexOf msg "{")]
        (when (and (str/includes? msg "plan:") (<= 0 start))
          (let [plan (json/read-value (subs msg start))]
            (when (re-find #"(?i)^(DECLARE |WITH matched AS)" (get plan "Query Text" ""))
              (swap! trace update :plans conj plan)))))
      (recur (.getNextWarning w))))
  (if (instance? Connection resource) (.clearWarnings ^Connection resource) (.clearWarnings ^Statement resource)))

(defn observed-statement [trace ^PreparedStatement stmt sql]
  (let [params (atom (sorted-map))]
    (wrap PreparedStatement
      (fn [^Method method args]
        (let [op (.getName method)]
          (when (= op "setObject") (swap! params assoc (aget args 0) (aget args 1)))
          (when (and (= op "close") (not (.isClosed stmt))) (record-warnings! trace stmt))
          (let [r (delegate stmt method args)]
            (when (#{"execute" "executeQuery" "executeUpdate"} op)
              (let [verb (first (str/split sql #"\s+" 2))]
                (swap! trace update-in [:commands verb] (fnil inc 0))
                (when (re-find #"(?i)^(DECLARE |WITH matched AS)" sql)
                  (swap! trace update :queries conj {:sql sql :params (vec (vals @params))}))))
            r))))))

(defn capture [directory id mode call]
  (let [empty-trace {:commands {} :queries [] :plans []}
        trace (atom empty-trace)
        pool (reify DataSource
               (getConnection [_]
                 (let [conn (DriverManager/getConnection "jdbc:postgresql://127.0.0.1:5432/postgres"
                                                        (System/getProperty "user.name") "")]
                   (try
                     (with-open [s (.createStatement conn)]
                       (doseq [cmd ["LOAD 'auto_explain'" "SET auto_explain.log_analyze=on"
                                    "SET auto_explain.log_timing=off" "SET auto_explain.log_buffers=on"
                                    "SET auto_explain.log_verbose=on" "SET auto_explain.log_format=json" "SET auto_explain.log_level=notice"
                                    "SET auto_explain.log_min_duration=0"]]
                         (.execute s cmd)))
                     (wrap Connection
                       (fn [^Method method args]
                         (when (and (= "close" (.getName method)) (not (.isClosed conn)))
                             (record-warnings! trace conn))
                           (let [r (delegate conn method args)]
                           (if (= "prepareStatement" (.getName method))
                             (observed-statement trace r (aget args 0)) r))))
                     (catch Throwable e (.close conn) (throw e))))))
        result (call pool #(reset! trace empty-trace))
        file (io/file directory (str (name id) "-" (name mode) ".json.gz"))
        {:keys [plans queries commands]} @trace]
    (with-open [writer (io/writer (GZIPOutputStream. (io/output-stream file)))]
      (.write writer (json/write-value-as-string @trace)))
    (assert (or (:failure result) (and (seq plans) (= (count plans) (count queries))))
            (str "Incomplete portal plans for " [id mode (count plans) (count queries)]))
    {:trace (.getName file) :commands commands :plans (count plans) :result (dissoc result :elapsed-ns)}))
