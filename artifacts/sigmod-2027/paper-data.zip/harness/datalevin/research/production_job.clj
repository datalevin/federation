(ns datalevin.research.production-job
  (:require [clojure.java.io :as io]
            [clojure.string :as str]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job :as job]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.federation.postgres.jdbc :as jdbc]
            [jsonista.core :as json]))

(defn source-state [profile tables]
  {:tables (into (sorted-map)
                 (for [t tables]
                   [t {:rows (suite/native! profile (str "SELECT count(*) FROM ONLY " (jdbc/relation ["public" t])))
                       :catalog (job/digest [(pr-str (pg/discover profile ["public" t]))])}]))
   :settings (suite/native! profile (str "SELECT version(),current_database(),current_setting('work_mem'),"
                                         "current_setting('shared_buffers'),current_setting('jit'),"
                                         "current_setting('max_parallel_workers_per_gather'),current_setting('geqo_threshold'),"
                                         "current_setting('join_collapse_limit'),current_setting('from_collapse_limit')"))})

(defn -main [arm index mode output]
  (let [index (parse-long index)
        options (suite/options! {:samples 1 :warmups 0 :verify-tuples? false :timeout-ms 300000
                                 :queries (when (= mode "pilot") [:6f :7c :11d :15d :16a :16b :17f :25c :30c])})
        profile {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/postgres"
                 :properties {"user" (System/getProperty "user.name") "ApplicationName" "datalevin-production-summary"}
                 :compute-context-id :benchmark/production-summary :statement-timeout-ms 300000}
        entries (suite/corpus! options) entries (if (zero? index) entries (vec (reverse entries)))
        tables (sort (into #{} (mapcat #(map second (:from (sql/parse (:sql %)))) entries)))
        catalogs (into {} (for [t tables] [t (pg/discover profile ["public" t])]))
        resources (into (sorted-map) (for [p ["datalevin/federation/postgres.clj" "datalevin/federation/postgres/relational.clj"
                                             "datalevin/federation/postgres/summary.clj" "datalevin/federation/postgres/demand.clj"
                                             "datalevin/federation/postgres/presence.clj" "datalevin/query/source/program.clj"]
                                           :let [r (io/resource p)] :when r] [p {:url (str r) :sha256 (job/digest [(slurp r)])}]))
        report (atom {:status :running :arm arm :index index :mode mode :started-at (str (java.time.Instant/now))
                      :options options :loaded-resources resources :source-before (source-state profile tables) :results []})
        save #(do (suite/write-report! output @report) (spit (str output ".json") (json/write-value-as-string @report)))]
    (save)
    (doseq [[i entry] (map-indexed vector entries)]
      (let [result (suite/run-query! profile options catalogs (+ index i) entry)]
        (swap! report update :results conj result)
        (swap! report assoc :summary (suite/summary (:results @report) (count entries) 1))
        (save)
        (prn {:query (:id entry) :status (:status result)
              :adapter-ms (/ (get-in result [:samples 0 :adapter :elapsed-ns] 0) 1e6)
              :native-ms (/ (get-in result [:samples 0 :native :elapsed-ns] 0) 1e6)}) (flush)
        (when-not (= :ok (:status result)) (throw (ex-info "JOB validation failed" {:query (:id entry)})))))
    (let [after (source-state profile tables)]
      (swap! report assoc :status :complete :source-after after :source-stable? (= after (:source-before @report))
             :finished-at (str (java.time.Instant/now)))
      (save)
      (assert (:source-stable? @report)))
    (prn (:summary @report)) (shutdown-agents)))
