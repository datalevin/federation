(ns datalevin.research.job-q5
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.research.job-routes :as routes]
            [datalevin.research.repeated-tpch :as tp]
            [datalevin-tpch.common :as common]
            [datalevin-tpch.verify :as verify]
            [jsonista.core :as json]))

(def one-order-sql
  (str "SELECT n_name,count(*) FROM lineitem JOIN supplier ON s_suppkey=l_suppkey "
       "JOIN nation ON n_nationkey=s_nationkey WHERE l_orderkey=1 GROUP BY n_name ORDER BY n_name"))

(defn -main [diagnosis full-sql out]
  (let [catalogs (into {} (for [t common/table-order] [t (pg/discover tp/profile ["public" t])]))
        sources (tp/prepare-sources catalogs)
        checks (mapv
                (fn [[id statement]]
                  (let [archived (json/read-value (slurp (io/file diagnosis (str id ".json"))))
                        {:keys [query tables]} (tp/adapt (edn/read-string (get archived "query")))
                        oracle (tp/native! statement)
                        actual (tp/attempt #(mapv vec (apply d/q query (mapv sources tables))))
                        rows (:rows actual)]
                    {:id id :oracle oracle :actual actual
                     :matches (and (= :ok (:status actual))
                                   (if (= id "q5-order1") (= rows oracle)
                                       (verify/results-match? 5 oracle rows)))
                     :live-sessions (reduce + (map #(:live-sessions (pg/statistics %)) (vals sources)))}))
                [["q5-order1" one-order-sql] ["q5-scoped" (slurp full-sql)]])]
    (spit out (json/write-value-as-string {:planner (routes/planner-sha) :checks checks}))
    (shutdown-agents)
    (assert (every? #(and (= :ok (get-in % [:actual :status]))
                          (zero? (:live-sessions %))) checks))
    (assert (every? :matches checks))))
