(ns datalevin.research.mixed-statistics
  (:require [clojure.java.io :as io]
            [clojure.string :as str]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres.jdbc :as jdbc]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.research.fixed-mixed :as fixed]
            [datalevin.research.mixed-public :as mixed]
            [datalevin.research.placement-controls :as controls]
            [jsonista.core :as json])
  (:import [java.util UUID]))

(defn inspect [prepared]
  (let [plan (apply d/explain {:run? false} (:query prepared) (:providers prepared))]
    (vec (for [region (:regions plan) step (:steps region) :when (:alternative-id step)]
           (select-keys step [:source :alternative-id :estimate])))))

(defn -main [block output]
  (let [b (parse-long block)
        schema (str "dtlv_pfx_" (str/replace (str (UUID/randomUUID)) "-" ""))
        edge (jdbc/relation [schema "edge"])
        owned? (atom false)]
    (try
      (with-open [db (mixed/connection controls/profile)]
        (try
          (mixed/setup-schema! db schema owned? fixed/fixture)
          (let [{:keys [conn providers prepared]} (mixed/mixed-prepared! controls/profile schema fixed/fixture)]
            (try
              (with-open [w (io/writer output)]
                ;; The two sampled owner fanouts imply 8,197 and 8,188 distinct
                ;; owners on 1,048,576 edges. Replay both sides of that crossing.
                (doseq [distinct-owners (if (zero? b) [8197 8188 8197] [8188 8197 8188])]
                  (mixed/execute! db (str "ALTER TABLE " edge " ALTER COLUMN owner SET (n_distinct = " distinct-owners ")"))
                  (mixed/execute! db (str "ANALYZE " edge " (owner)"))
                  (let [catalog (first (suite/native! controls/profile
                                         (str "SELECT c.reltuples,s.n_distinct,s.null_frac FROM pg_stats s"
                                              " JOIN pg_namespace n ON n.nspname=s.schemaname"
                                              " JOIN pg_class c ON c.relnamespace=n.oid AND c.relname=s.tablename"
                                              " WHERE s.schemaname='" schema "' AND s.tablename='edge' AND s.attname='owner'")))
                        steps (inspect prepared)]
                    (assert (every? #(zero? (:live-sessions (pg/statistics %))) providers))
                    (.write w (str (json/write-value-as-string
                                     {:block b :pid (.pid (java.lang.ProcessHandle/current)) :schema schema
                                      :distinct-override distinct-owners :catalog catalog :steps steps}) "\n"))
                    (.flush w))))
              (finally (d/close conn))))
          (finally
            (when @owned? (mixed/execute! db (str "DROP SCHEMA " (jdbc/identifier schema) " CASCADE"))))))
      (finally (shutdown-agents)))))
