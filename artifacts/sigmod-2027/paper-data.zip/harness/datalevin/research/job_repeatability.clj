(ns datalevin.research.job-repeatability
  (:require [clojure.java.io :as io]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.research.production-job :as production]
            [jsonista.core :as json])
  (:import [java.nio.file Files StandardCopyOption]
           [java.time Instant]))

(defn- checkpoint! [path report]
  (let [scratch (io/file (str path ".tmp"))]
    (spit scratch (json/write-value-as-string report))
    (Files/move (.toPath scratch) (.toPath (io/file path))
                (into-array StandardCopyOption [StandardCopyOption/REPLACE_EXISTING]))))

(defn -main [block output mode]
  (let [index (parse-long block)
        options (suite/options! {:samples 1 :warmups 0 :verify-tuples? false :timeout-ms 300000
                                 :queries (when (= mode "pilot") [:2c :17c :22d])})
        profile {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/postgres"
                 :properties {"user" (System/getProperty "user.name")
                              "ApplicationName" "datalevin-job-repeatability"}
                 :compute-context-id :benchmark/production-summary :statement-timeout-ms 300000}
        entries (suite/corpus! options)
        entries (if (odd? index) (rseq entries) entries)
        tables (sort (into #{} (mapcat #(map second (:from (sql/parse (:sql %)))) entries)))
        catalogs (into {} (map (fn [table] [table (pg/discover profile ["public" table])])) tables)
        before (production/source-state profile tables)
        report (atom {:status :running :block index :mode mode :started-at (str (Instant/now))
                      :source-before before :phases {:cold [] :warm []}})
        save! #(checkpoint! output @report)]
    (try
      (save!)
      (doseq [[phase phase-offset] [[:cold 0] [:warm 1]]]
        (println "Starting phase" phase) (flush)
        (doseq [[ordinal entry] (map-indexed vector entries)]
          (let [offset (+ (* -1 (mod index 2)) (quot index 2) phase-offset)
                result (suite/run-query! profile options catalogs (+ ordinal offset) entry)]
            (swap! report update-in [:phases phase] conj result)
            (save!)
            (prn {:phase phase :query (:id entry) :status (:status result)
                  :adapter-ms (/ (get-in result [:samples 0 :adapter :elapsed-ns] 0) 1e6)
                  :native-ms (/ (get-in result [:samples 0 :native :elapsed-ns] 0) 1e6)})
            (flush)
            (when-not (= :ok (:status result))
              (throw (ex-info "JOB validation failed" {:phase phase :query (:id entry)}))))))
      (let [after (production/source-state profile tables)]
        (swap! report assoc :source-after after)
        (when-not (= before after) (throw (ex-info "Source inventory changed" {:block index}))))
      (swap! report assoc :status :complete :finished-at (str (Instant/now)))
      (finally (save!) (shutdown-agents)))))
