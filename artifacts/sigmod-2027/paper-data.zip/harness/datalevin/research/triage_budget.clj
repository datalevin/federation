(ns datalevin.research.triage-budget
  (:require [clojure.java.io :as io]
            [datalevin.federation.file :as export]
            [datalevin.federation.github :as github]
            [datalevin.federation.release-triage :as triage]
            [datalevin.federation.workflow-fixture :as fixture]
            [datalevin.research.triage-public :as measured]
            [jsonista.core :as json]))

(defn -main [output]
  (let [f (fixture/create! {:name :large-native :native-rows 2048 :export-rows 16
                            :selected-keys 1 :latency-ms 0 :input-rows 1})
        query (-> triage/lookup-query (update :where conj '[(= ?window "now")])
                  (assoc :timeout 120000)
                  (assoc-in [:query-source :limits] {:binding-rows 64 :batch-rows 64
                                                     :retained-bytes 268435456 :spill-bytes 67108864}))
        forms {:parameter query :literal (assoc-in query [:where 3] '[(>= ?priority 9)])
               :caller (update query :where #(into (subvec % 0 3) (subvec % 4)))}]
    (try
      (let [oracle (measured/invoke (dissoc query :query-source) f (fixture/eager f))]
        (with-open [w (io/writer output)]
          (doseq [[form q] forms]
            (let [before (measured/counters f)
                  result (try {:answer (measured/invoke q f (:sources f))}
                              (catch clojure.lang.ExceptionInfo e
                                {:failure (select-keys (ex-data e) [:error :phase :category :maximum :attempted])}))
                  work (merge-with - (measured/counters f) before)
                  clean (and (fixture/clean? f)
                             (zero? (:live-sessions (github/statistics (get-in f [:sources :github]))))
                             (zero? (:live-spools (export/statistics (get-in f [:sources :release])))))]
              (assert clean)
              (if (= :caller form)
                (assert (= [:query-source/limit :external-requests 1024]
                           ((juxt :error :category :maximum) (:failure result))) (pr-str result))
                (assert (= oracle (:answer result))))
              (.write w (str (json/write-value-as-string (assoc result :form form :work work :clean clean)) "\n"))))))
      (finally ((:close! f)) (shutdown-agents)))))
