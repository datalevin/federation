(ns datalevin.research.job-spills
  (:require [clojure.java.io :as io]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.research.job-boundaries :as bounds]
            [datalevin.research.public-plans :as plans]
            [jsonista.core :as json])
  (:import [javax.sql DataSource] [java.util.zip GZIPOutputStream]))

(defn instrumented-source [^DataSource pool mb connections]
  (reify DataSource
    (getConnection [_]
      (let [conn (.getConnection pool)]
        (try
          (with-open [stmt (.createStatement conn)]
            (.execute stmt (case mb 4 "SET work_mem='4MB'" 64 "SET work_mem='64MB'"))
            (with-open [rs (.executeQuery stmt "SELECT pg_backend_pid(),current_setting('work_mem'),current_setting('max_parallel_workers_per_gather')")]
              (assert (.next rs))
              (swap! connections conj [(.getInt rs 1) (.getString rs 2) (.getString rs 3)])))
          conn
          (catch Throwable e (.close conn) (throw e)))))))

(defn measure-query! [dest entry answer]
  (let [id (:id entry)
        parsed (sql/parse (:sql entry))
        catalogs (into {} (for [t (distinct (map second (:from parsed)))]
                            [t (pg/discover bounds/profile ["public" t])]))
        spec (sql/compile-query parsed catalogs)]
    (doseq [[mb config] [[4 :inherited] [64 :larger]]]
      (let [profile (bounds/profiles config)
            plan-json (ffirst (suite/native! profile
                                (str "EXPLAIN (ANALYZE, BUFFERS, SETTINGS, TIMING OFF, FORMAT JSON) "
                                     (sql/sql-query parsed "public" true))))
            original (io/file dest (str (name id) "-original-" mb ".json.gz"))
            observed (atom [])
            capture (plans/capture dest id (str "adapter-" mb)
                      (fn [pool reset-trace!]
                        (let [p (assoc (dissoc profile :jdbc-url) :data-source (instrumented-source pool mb observed))
                              ps (sql/sources! p catalogs spec)]
                          (reset-trace!)
                          (let [rows (set (apply d/q (bounds/query-for spec nil) ps))]
                            (assert (= rows answer))
                            (assert (every? #(zero? (:live-sessions (pg/statistics %))) ps))
                            {:answer rows}))))]
        (with-open [w (io/writer (GZIPOutputStream. (io/output-stream original)))]
          (.write w (str plan-json)))
        (assert (= 1 (count @observed)))
        (bounds/emit! (io/file dest "observations.jsonl")
                      {:query id :work-mb mb :original (.getName original)
                       :source-connections @observed :adapter capture})))))

(defn -main [dest oracle-file]
  (try
    (let [opts (suite/options! {:queries [:16b :26c]})
          answers (into {} (for [r (get-in (json/read-value (slurp oracle-file)) ["phases" "warm"])]
                             [(get r "id") (set (get r "expected"))]))]
      (doseq [entry (suite/corpus! opts)]
        (measure-query! dest entry (answers (name (:id entry))))))
    (finally (shutdown-agents))))
