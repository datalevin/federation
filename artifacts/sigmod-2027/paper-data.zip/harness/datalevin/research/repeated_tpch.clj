(ns datalevin.research.repeated-tpch
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]
            [clojure.string :as str]
            [clojure.walk :as walk]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job :as job]
            [datalevin-tpch.common :as common]
            [datalevin-tpch.datalevin :as tpch]
            [datalevin-tpch.queries :as queries]
            [datalevin-tpch.verify :as verify]
            [jsonista.core :as json])
  (:import [java.sql Connection DriverManager ResultSet]
           [java.time LocalDate]
           [java.util Properties UUID]))

(def timeout-ms 120000)
(def profile
  {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/datalevin_tpch_sf1_20261028"
   :properties {"user" (System/getProperty "user.name") "ApplicationName" "datalevin-repeated-tpch"}
   :compute-context-id :benchmark/repeated-tpch :statement-timeout-ms timeout-ms})
(def source-id (UUID/fromString "bd59c27c-86eb-47df-9aac-915b8a055172"))
(defn source-symbol [table] (symbol (str "$" table)))

(defn prepare-sources [catalogs]
  (let [declaration (fn [table attrs]
                      {:source-instance-id source-id :relation-id (keyword "tpch" table)
                       :identity-attribute (keyword table "__identity") :attributes attrs})
        identities (into {} (for [table common/table-order]
                              [table (:identity (pg/accept-mapping (catalogs table) (declaration table {})))]))]
    (into {} (for [table common/table-order
                   :let [attrs (into {} (for [[attr column] (map vector (common/attrs table) (:columns (common/table-specs table)))]
                                         (if-let [[reference target] (tpch/references attr)]
                                           [reference {:column column :reference {:type (:type (identities target))
                                                                                 :domain (get-in (identities target) [:type :parameters :identity-domain-id])}}]
                                           [attr column])))]]
               [table (pg/source (pg/accept-mapping (catalogs table) (declaration table attrs)) profile)]))))

(declare adapt)
(defn convert [node]
  (cond
    (and (seq? node) (= 'q (first node)))
    (let [{:keys [query tables]} (adapt (second node))]
      (assert (= ['$] (vec (drop 2 node))))
      (apply list 'q query (map source-symbol tables)))

    (and (vector? node) (= 3 (count node)) (symbol? (first node))
         (keyword? (second node)) (contains? common/table-specs (namespace (second node))))
    (into [(source-symbol (namespace (second node)))] (mapv convert node))

    (and (seq? node) (= 'subs (first node)))
    (apply list 'subs (list 'str (convert (second node))) (map convert (drop 2 node)))

    (and (string? node) (re-matches #"\d{4}-\d{2}-\d{2}" node)) (LocalDate/parse node)
    (list? node) (apply list (map convert node))
    (vector? node) (mapv convert node)
    :else node))

(defn adapt [query]
  (let [converted (convert query)
        tables (->> (tree-seq coll? seq converted)
                    (filter #(and (symbol? %) (str/starts-with? (str %) "$")))
                    (map #(subs (str %) 1)) set sort vec)]
    {:tables tables :query (into (vec converted)
                                (concat [:in] (map source-symbol tables)
                                        [:timeout timeout-ms :query-source {:limits (:limits job/defaults)}]))}))

(defn normalize [rows]
  (walk/postwalk #(if (or (instance? LocalDate %) (instance? java.sql.Date %)) (str %) %) rows))

(defn native! [statement]
  (let [props (Properties.)]
    (doseq [[k v] (:properties profile)] (.setProperty props k v))
    (with-open [conn (DriverManager/getConnection (:jdbc-url profile) props)]
      (.setReadOnly conn true)
      (.setTransactionIsolation conn Connection/TRANSACTION_REPEATABLE_READ)
      (.setAutoCommit conn false)
      (try
        (with-open [stmt (.prepareStatement conn statement)]
          (.setQueryTimeout stmt 120)
          (.setFetchSize stmt 0)
          (with-open [rs (.executeQuery stmt)]
            (let [n (.getColumnCount (.getMetaData rs))]
              (loop [rows []]
                (if (.next rs)
                  (do (when (>= (count rows) 1000000) (throw (ex-info "Output row limit" {:error :benchmark/output-limit})))
                      (recur (conj rows (mapv #(.getObject ^ResultSet rs (int %)) (range 1 (inc n))))))
                  (normalize rows))))))
        (finally (.rollback conn))))))

(defn attempt [f]
  (let [start (System/nanoTime)]
    (try {:status :ok :rows (f) :elapsed-ns (- (System/nanoTime) start)}
         (catch Throwable e
           {:status :failed :elapsed-ns (- (System/nanoTime) start)
            :failure {:class (.getName (class e)) :message (.getMessage e)
                      :data (pr-str (ex-data e))
                      :stack (mapv str (take 16 (.getStackTrace e)))}}))))

