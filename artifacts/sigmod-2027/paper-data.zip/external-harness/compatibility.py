"""Check the same JOB answers through the stock DuckDB connector and Accio's SQL rewriter."""
import argparse
import getpass
import hashlib
import json
from pathlib import Path
import re
import tempfile
from research_worker import Engine


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('engine', choices=['duckdb', 'accio'])
    parser.add_argument('frozen', type=Path)
    parser.add_argument('installed', type=Path, help='benchmarks/job/.work containing the external engines')
    parser.add_argument('output', type=Path, help='new file in an existing directory')
    parser.add_argument('--standard-inequality', action='store_true',
                        help='retry just the Accio inputs containing the PostgreSQL != operator using SQL <>')
    args = parser.parse_args()
    if args.standard_inequality and args.engine!='accio':
        parser.error('--standard-inequality is an Accio parser control')
    study = Path(__file__).resolve().parents[1]
    hashes = json.loads((study/'production-manifest.json').read_text())
    block = json.loads((study/'job/block-0.json').read_text())
    assert block['status'] == 'complete'
    jar = args.installed/'accio-src/rewriter/target/accio-rewriter-1.0-SNAPSHOT-jar-with-dependencies.jar'
    user = getpass.getuser()
    with tempfile.TemporaryDirectory(prefix='dtlv-external-control-') as scratch:
        root = Path(scratch)
        read_opts = '-c default_transaction_read_only=on -c statement_timeout=180000'
        url = 'jdbc:postgresql://127.0.0.1:5432/postgres?options=-c%20default_transaction_read_only%3Don%20-c%20statement_timeout%3D180000'
        (root/'job.json').write_text(json.dumps(dict(type='POSTGRES', driver='org.postgresql.Driver',
            url=url, username=user, password='', costParams=dict(join=2.0,agg=2.0,sort=2.0,trans=1.0),
            cardEstType='postgres', partitionType='postgres', partition={'max_parallelism':8},
            dialect='postgres', disableOps=[])))
        (root/'local.json').write_text(json.dumps(dict(type='MANUAL',dialect='postgres',schema={})))
        engine = Engine(dict(engine=args.engine, threads=12, extension_directory=str(args.installed/'duckdb-extensions'),
            temp_directory=str(root/'spill'), pg_env=dict(PGUSER=user,PGDATABASE='postgres', PGHOST='127.0.0.1',
            PGPORT='5432',PGOPTIONS=read_opts), schema='public', timeout_ms=180000, source_identity={'host':'127.0.0.1'},
            accio_config=str(root), accio_jar=str(jar),text_min_order='source-libc'))
        with args.output.open('x') as log:
            print(json.dumps({'environment':engine.metadata,'accio_jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest()
                             if args.engine=='accio' else None}),file=log,flush=True)
            for q in block['phases']['warm']:
                path = Path('datalevin/benchmarks/JOB-bench/queries')/(q['id']+'.sql')
                data = (args.frozen/path).read_bytes()
                assert hashlib.sha256(data).hexdigest()==hashes[str(path)]
                statement=data.decode()
                if args.engine=='accio':
                    statement=statement.rstrip().removesuffix(';')
                if args.standard_inequality:
                    tokens=r"""'(?:''|[^'])*'|"(?:""|[^"])*"|--[^\r\n]*|/\*.*?\*/|!="""
                    normalized=re.sub(tokens,lambda m:'<>' if m[0]=='!=' else m[0],statement,flags=re.S)
                    if normalized==statement:
                        continue
                    statement=normalized
                try:
                    result=engine.execute(statement)
                    rows=result['rows']
                    expected=[[None if v is None else str(v) for v in row] for row in q['expected']]
                    observation={'query':q['id'],'status':'match' if rows==expected else 'mismatch',
                                 'result':rows,'expected':expected}
                except Exception as exc:
                    observation={'query':q['id'],'status':'error','error':str(exc)[:500]}
                print(json.dumps(observation),file=log,flush=True)


if __name__=='__main__':
    main()
