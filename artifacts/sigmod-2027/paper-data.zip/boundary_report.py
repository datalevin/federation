"""Audit JOB setup boundaries and session-local configuration comparisons."""
from collections import defaultdict
import csv
import gzip
import json
from statistics import mean


def summarize(study, save, macros, tex_rows):
    def read(name):
        return json.loads((study/name).read_text())

    def lines(name):
        return [json.loads(s) for s in (study/name).read_text().splitlines()]

    main = [read(f'job/block-{i}.json') for i in range(4)]
    queries = main[0]['phases']['warm']
    ids = [q['id'] for q in queries]
    digests = {q['id']: q['sha256'] for q in queries}
    expected = {q['id']: q['expected'] for q in queries}
    split = {q['id'] for q in read('routes/routes.json')['plans'] if q['route'] != 'whole'}
    assert len(ids) == 113 and len(split) == 7
    readings = defaultdict(list)
    samples = []
    for b in range(2):
        setup = read(f'boundaries/block-{b}-setup.json')
        end = read(f'boundaries/block-{b}-complete.json')
        launch = read(f'boundaries/block-{b}-launch.json')
        assert setup['source-before'] == end['source-after'] == main[0]['source-before']
        assert len(setup['catalog-tables']) == 21
        assert setup['benchmark-limits'] == {'retained-bytes': 8*1024**3, 'external-requests': 16384}
        assert tuple(setup['engine-defaults'][k] for k in ('retained-bytes','external-requests')) == (1024**3,1024)
        for config, mem, workers in [('inherited','4096','2'),('larger','65536','2'),('serial','4096','0')]:
            db = {name: (value,boot,source) for name,value,unit,boot,source in setup['settings'][config]}
            assert db['work_mem'] == (mem,'4096','client' if config == 'larger' else 'default')
            assert db['max_parallel_workers_per_gather'] == (workers,'2','client' if config == 'serial' else 'default')
        qs = lines(f'boundaries/block-{b}.jsonl')
        assert [q['query'] for q in qs] == (list(reversed(ids)) if b else ids)
        readings['launch'].append((setup['main-start-ms']-launch['start_ms'])/1000)
        for m in ('corpus-read-ns','inventory-parse-ns','discovery-ns'):
            readings[m].append(setup[m]/1e9)
        readings['inventory-checks'].append((setup['source-before-ns']+end['source-after-ns'])/1e9)
        for m in ('parse-ns','original-render-ns','translate-ns'):
            readings[m].append(sum(q['setup'][m] for q in qs)/1e9)
        main_calls = []
        for q in qs:
            query = q['query']
            assert q['sha256'] == digests[query]
            variants = [('original','inherited'),('benchmark','inherited'),('default','inherited'),
                        ('original','larger'),('default','larger')]
            if query in split:
                variants.extend([('original','serial'),('default','serial')])
            k = ids.index(query) % len(variants)
            order = variants[k:]+variants[:k]
            assert [(c['arm'],c['config']) for c in q['cells']] == (order[::-1] if b else order)
            for c in q['cells']:
                error = c.get('failure',{})
                if c['status']=='ok':
                    actual = c['result']
                    if c['arm'] != 'original' and not actual:
                        actual = [[None]*len(expected[query][0])]
                    assert c['answer-matches'] and actual == expected[query], (query, c)
                else:
                    assert c['arm']!='original' and error.get('error') in ('query-source/limit','query-source/timeout','query/timeout'), (query,c)
                preparation = q['setup']['parse-ns']
                if c['arm']=='original':
                    preparation += q['setup']['original-render-ns']
                else:
                    preparation += q['setup']['translate-ns'] + c['mapping-providers-ns'] + c['query-options-ns']
                samples.append(dict(block=b,query=query,arm=c['arm'],config=c['config'],status=c['status'],
                                    seconds=c['elapsed-ns']/1e9,input_preparation_s=preparation/1e9,
                                    failure=error.get('error',''),category=error.get('category','')))
                if (c['arm'],c['config']) == ('benchmark','inherited'):
                    main_calls.append(c)
        for m in ('mapping-providers-ns','query-options-ns'):
            readings[m].append(sum(c[m] for c in main_calls)/1e9)
    save('boundary-calls.csv',samples)
    for run in main:
        warm = run['phases']['warm']
        readings['original-study-setup'].append(sum(q['setup']['elapsed-ns'] for q in warm)/1e9)
        readings['original-study-checks'].append(sum(q['aggregate-checks'][0]['elapsed-ns'] for q in warm)/1e9)
        assert all(sum(s['external-requests'] > 0 for s in q['source-statistics'])==1 for q in warm)
    save('boundary-setup.csv',[dict(operation=k,block=i,seconds=x) for k,vs in readings.items() for i,x in enumerate(vs)])
    formats = {'Launch':'launch','Read':'corpus-read-ns','Inventory':'inventory-parse-ns','Discovery':'discovery-ns',
               'Parse':'parse-ns','Render':'original-render-ns','Translate':'translate-ns','Mapping':'mapping-providers-ns',
               'Options':'query-options-ns','Checks':'original-study-checks','Bookends':'inventory-checks'}
    for macro, field in formats.items():
        x = mean(readings[field])
        macros['Boundary'+macro] = f'{x:.3f}' if x>=0.001 else r'$<0.001$'
    joint = mean(readings['original-study-setup'])
    adapter = mean(sum(q['samples'][0]['adapter']['elapsed-ns']/1e9 for q in run['phases']['warm']) for run in main)
    macros.update(BoundaryJoint=f'{joint:.2f}',BoundaryCharged=f'{joint+adapter:.2f}')
    totals = []
    cells = [('all','inherited','benchmark'),('all','inherited','default'),('all','larger','default'),
             ('split','inherited','default'),('split','serial','default')]
    for cohort,config,arm in cells:
        included = set(ids) if cohort=='all' else split
        for b in (0,1):
            def select(a):
                return [s for s in samples if s['block']==b and s['arm']==a and s['config']==config and s['query'] in included]
            sql,adapter = select('original'),select(arm)
            assert len(adapter)==len(sql)==len(included) and all(s['status']=='ok' for s in sql)
            failed = [s['query'] for s in adapter if s['status']!='ok']
            ok = included-set(failed)
            # Charge the adapter its full one-time inventory and discovery for a batch starting from SQL text.
            sql_prepared = sum(s['seconds']+s['input_preparation_s'] for s in sql)
            adapter_prepared = sum(s['seconds']+s['input_preparation_s'] for s in adapter)
            catalog_setup = readings['inventory-parse-ns'][b] + readings['discovery-ns'][b]
            totals.append(dict(cohort=cohort, config=config, arm=arm, block=b, queries=len(included), matched=len(ok),
                               sql_s=sum(s['seconds'] for s in sql), adapter_s='' if failed else sum(s['seconds'] for s in adapter),
                               sql_including_setup_s=sql_prepared if cohort=='all' else '',
                               adapter_including_setup_s=(adapter_prepared+catalog_setup) if cohort=='all' and not failed else '',
                               matched_sql_s=sum(s['seconds'] for s in sql if s['query'] in ok),
                               matched_adapter_s=sum(s['seconds'] for s in adapter if s['query'] in ok), failed=' '.join(failed)))
    save('boundary-totals.csv',totals)
    formatted = []
    for i,(cohort,config,arm) in enumerate(cells):
        a,b = totals[2*i:2*i+2]
        def pair(key):
            return ' / '.join('--' if row[key]=='' else f'{row[key]:.2f}' for row in (a,b))
        matched = str(a['matched']) if a['matched']==b['matched'] else f"({a['matched']},{b['matched']})"
        if (cohort,config,arm)==('all','inherited','default'):
            macros['BoundarySQLWithSetup'] = pair('sql_including_setup_s')
            macros['BoundaryAdapterWithSetup'] = pair('adapter_including_setup_s')
        formatted.append([f"{matched}/{a['queries']}",'8/16,384' if arm=='benchmark' else '1/1,024',
                          '64' if config=='larger' else '4','0' if config=='serial' else '2',pair('sql_s'),pair('adapter_s')])
    tex_rows('BoundarySensitivityRows',formatted)

    captures = lines('boundaries-plans/observations.jsonl')
    assert [(r['query'], r['work-mb']) for r in captures]==[('16b',4),('16b',64),('26c',4),('26c',64)]
    with (study/'job-queries.csv').open() as f:
        assert max((r for r in csv.DictReader(f) if r['phase']=='warm'),key=lambda r:float(r['original_s']))['query']=='16b'
    first_sql={(s['query'],s['config']):s['seconds'] for s in samples if s['block']==0 and s['arm']=='original'}
    assert max(ids,key=lambda q:first_sql[q,'larger']-first_sql[q,'inherited'])=='26c'
    for config, label in [('inherited','Low'),('larger','High')]:
        times = [s['seconds'] for s in samples if s['query']=='26c' and s['arm']=='original' and s['config']==config]
        assert len(times)==2
        macros['BoundarySlow'+label] = ' and '.join(f'{t:.2f}' for t in times)
    plans = []
    for r in captures:
        assert r['adapter']['result']['answer']==expected[r['query']]
        assert len(r['source-connections'])==1 and r['source-connections'][0][1:]==[str(r['work-mb'])+'MB','2']
        for arm in ('original','adapter'):
            file = study/'boundaries-plans'/(r['original'] if arm=='original' else r['adapter']['trace'])
            with gzip.open(file,'rt') as f:
                data=json.load(f)
            ps = data if arm=='original' else data['plans']
            assert len(ps)==1
            root=ps[0]['Plan']
            def walk(node):
                yield node
                for child in node.get('Plans',[]): yield from walk(child)
            nodes = list(walk(root))
            keyword_probes = sum(n['Actual Loops'] for n in nodes if n.get('Index Name')=='keyword_pkey')
            plans.append(dict(query=r['query'],arm=arm,work_mem_mb=r['work-mb'],temp_read=root.get('Temp Read Blocks',0),
                              temp_written=root.get('Temp Written Blocks',0),keyword_pk_probes=keyword_probes,
                              workers_launched=sum(n.get('Workers Launched',0) for n in nodes)))
            if arm=='original' and r['query']=='26c':
                macros['BoundaryKeyword'+('Low' if r['work-mb']==4 else 'High')] = f'{keyword_probes:,}'
    save('boundary-spills.csv',plans)
    for arm in ('original','adapter'):
        for row in plans:
            if row['arm']==arm and row['query']=='16b':
                macros['Spill'+arm.title()+('Low' if row['work_mem_mb']==4 else 'High')] = f"{row['temp_written']:,}"

    client, process = read('small-client/client.json'), read('small-client/process.json')
    assert process['exit_code']==0 and client['pid']==process['pid']
    assert client['max-heap']==1024**3
    assert client['heap-and-direct-flags'][-3:]==['-Xms128m','-Xmx1g','-XX:MaxDirectMemorySize=256m']
    calls = lines('small-client/calls.jsonl')
    assert [c['query'] for c in calls]==ids
    for c in calls:
        q = c['query']
        assert c['sha256']==digests[q]
        if c['status']=='ok':
            assert c['answer-matches'] and (c['result'] or [[None]*len(expected[q][0])])==expected[q]
        else:
            assert c['failure']['error'] in ('query-source/limit','query-source/timeout','query/timeout')
    matched = sum(c['status']=='ok' for c in calls)
    save('boundary-small-client.csv',[dict(queries=len(calls),matched=matched,heap_bytes=client['max-heap'],
                                         direct_buffer_limit_bytes=256*1024**2,peak_rss_bytes=process['peak_rss_bytes'])])
    macros.update(SmallClientMatched=matched,SmallClientRSS=f"{process['peak_rss_bytes']/1024**3:.2f}")
