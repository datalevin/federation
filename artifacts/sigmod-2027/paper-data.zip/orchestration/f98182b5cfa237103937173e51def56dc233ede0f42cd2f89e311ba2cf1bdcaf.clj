(ns datalevin.research.fixed-mixed
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]
            [clojure.string :as str]
            [datalevin.core :as d]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres.jdbc :as jdbc]
            [datalevin.research.mixed-public :as mixed]
            [datalevin.research.placement-controls :as controls]
            [datalevin.research.public-plans :as plans]
            [jsonista.core :as json])
  (:import [java.sql Connection PreparedStatement]
           [java.security MessageDigest]
           [java.util HexFormat UUID]
           [javax.sql DataSource]))

(def fixture (assoc (first (filter #(= :high-fanout (:id %)) mixed/fixtures)) :local-floor? true))
(def specs [["edge" :edge/entity {:edge/owner "owner" :edge/target "target"}]
            ["target" :target/entity {:target/id "id" :target/category "category"}]
            ["category" :category/entity {:category/id "id" :category/allowed "allowed" :category/label "label"}]])
(def profiles
  [[:default {} {}]
   [:individual {:relational? false} {}]
   [:cardinality {} {:cost-model :cardinality}]
   [:catalog-only {:filtered-statistics? false} {}]
   [:structural {:statistics? false :filtered-statistics? false} {}]
   [:local-work {} {:local-row-ns 100000 :local-column-ns 25000}]
   [:no-local-charge {} {:local-row-ns 0 :local-column-ns 0}]
   [:no-probes {} {:estimate-max-requests 0}]
   [:probe {} {:estimate-budget-ms 1000 :estimate-max-requests 64}]
   [:catalog-edge {:per-table {"category" {:statistics? false :filtered-statistics? false}
                               "target" {:statistics? false :filtered-statistics? false}}} {}]
   [:catalog-edge-target {:per-table {"category" {:statistics? false :filtered-statistics? false}}} {}]
   [:unfused {:fusion? false} {}]
   [:unfused-category {:per-table {"category" {:fusion? false}}} {}]
   [:prefix {:bound-join-mode :protected-prefix} {}]])
(defn digest [s]
  (.formatHex (HexFormat/of) (.digest (MessageDigest/getInstance "SHA-256") (.getBytes ^String s "UTF-8"))))
(defn write-json! [file data] (spit file (str (json/write-value-as-string data) "\n")))
(defn append! [file row] (spit file (str (json/write-value-as-string row) "\n") :append true))
(defn profile-for [arm] (first (filter #(= arm (first %)) profiles)))
(defn catalog-state [^Connection conn schema]
  (with-open [s (.prepareStatement conn
                 (str "SELECT (SELECT md5(string_agg(to_jsonb(s)::text,'|' ORDER BY tablename,attname)) FROM pg_stats s WHERE schemaname=?),"
                      "(SELECT md5(string_agg(c.oid::text||':'||c.reltuples::text||':'||c.relpages::text,'|' ORDER BY c.relname)) "
                      "FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname=?),"
                      (str/join "," (for [[t] specs] (str "(SELECT count(*) FROM " (jdbc/relation [schema t]) ")")))))]
    (.setString s 1 schema) (.setString s 2 schema)
    (with-open [r (.executeQuery s)]
      (assert (.next r))
      (let [state (mapv #(.getString r (int %)) (range 1 6))]
        (assert (and (every? some? state) (= ["1048576" "4096" "256"] (subvec state 2))))
        state))))
(defn native-digest [conn]
  (digest (pr-str (mapv (juxt :e :a :v) (d/datoms @conn :eav)))))
(defn setup! [conn schema tmp out]
  (let [owned (atom false)]
    (.setAutoCommit ^Connection conn false)
    (try
      (mixed/setup-schema! conn schema owned fixture)
      (doseq [[t] specs]
        (mixed/execute! conn (str "ALTER TABLE " (jdbc/relation [schema t]) " SET (autovacuum_enabled=false)")))
      ;; Publish all three tables together. The benchmark role only reads them after setup.
      (.commit ^Connection conn)
      (let [{:keys [conn prepared]} (mixed/mixed-prepared! controls/profile schema fixture)]
        (try
          (let [local (d/conn-from-datoms (d/datoms @conn :eav) (str tmp "/native") (d/schema conn)
                                          {:background-sampling? false})]
            (try (spit (io/file tmp "query.edn") (pr-str (:query prepared)))
                 (spit (io/file tmp "native-hash") (native-digest local))
                 (finally (d/close local))))
          (finally (d/close conn))))
      (spit (io/file tmp "catalog.edn") (pr-str (catalog-state conn schema)))
      (write-json! (io/file out "fixture.json") {:schema schema :catalog (catalog-state conn schema)
                                                 :native (slurp (io/file tmp "native-hash")) :fixture fixture})
      (catch Throwable e
        (.rollback ^Connection conn)
        (when @owned
          (mixed/execute! conn (str "DROP SCHEMA IF EXISTS " (jdbc/identifier schema) " CASCADE"))
          (.commit ^Connection conn))
        (throw e)))))
(defn mappings [schema]
  (let [instance (UUID/nameUUIDFromBytes (.getBytes ^String schema "UTF-8"))]
    (mapv (fn [[table identity attrs]]
            (pg/accept-mapping (pg/discover controls/profile [schema table])
              {:source-instance-id instance :relation-id (keyword "work" table)
               :identity-attribute identity :attributes attrs})) specs)))
(defn providers [accepted opts pool]
  (let [base (merge controls/profile (dissoc opts :per-table))]
    (mapv (fn [mapping [table]]
            (let [p (merge base (get-in opts [:per-table table]))]
              (pg/source mapping (cond-> p pool (dissoc :jdbc-url) pool (assoc :data-source pool)))))
          accepted specs)))

;; Observe successfully executed cursor declarations in the same d/q call that returns the rows.
;; The observer stores SQL references only. Classify the relations after the query timer stops.
(defn sql-observer [seen]
  (reify DataSource
    (getConnection [_]
      (let [c (mixed/connection controls/profile)]
        (plans/wrap Connection
          (fn [method args]
            (let [r (plans/delegate c method args)]
              (if (and (= "prepareStatement" (.getName method)) (str/starts-with? (aget args 0) "DECLARE "))
                (let [sql (aget args 0)]
                  (plans/wrap PreparedStatement
                    (fn [m a]
                      (let [v (plans/delegate r m a)]
                        (when (#{"execute" "executeUpdate" "executeQuery"} (.getName m)) (swap! seen conj sql))
                        v))))
                r))))))))
(defn signature [sql schema]
  (let [tables (filter #(str/includes? sql (jdbc/relation [schema %])) (map first specs))]
    (assert (seq tables) sql)
    (str/join "+" tables)))
(defn run-fixture! [stage schema tmp out block]
  (let [local (d/get-conn (str tmp "/native"))
        query (edn/read-string (slurp (io/file tmp "query.edn")))
        accepted (mappings schema)
        gold (mixed/expected fixture)
        arm-query (fn [policy] (cond-> query (seq policy) (assoc-in [:query-source :planning] policy)))
        candidates (io/file out "screen.json")
        ids (fn [p] (vec (for [r (:regions p) s (:steps r) :when (:alternative-id s)] (:alternative-id s))))
        arms-file (io/file tmp "arms.edn")]
    (try
      (assert (= (native-digest local) (slurp (io/file tmp "native-hash"))))
      (case stage
        "screen"
        (with-open [db (mixed/connection controls/profile)]
          ;; Screen on selected access alone, before timing. A new ANALYZE draws
          ;; a catalog sample of identical data. Stop changing statistics as
          ;; soon as both shapes are available, and record every attempted draw.
          (loop [draw 0]
            (let [screen (mapv (fn [[arm opts policy]]
                                 (let [p (apply d/explain {:run? false} (arm-query policy) @local (providers accepted opts nil))]
                                   {:arm arm :profile opts :planning policy :ids (ids p)})) profiles)
                  joined? (fn [r] (some #(str/starts-with? % "join-") (:ids r)))
                  joined (first (filter joined? screen))
                  separate (first (filter #(and (= 3 (count (:ids %))) (not (joined? %))) screen))
                  arms (mapv :arm (remove nil? [separate joined]))
                  state (catalog-state db schema)]
              (append! (io/file out "draws.jsonl") {:draw draw :catalog state :profiles screen})
              (if (or (= 2 (count arms)) (= draw 11))
                (do (assert (= 2 (count arms)) "No contrasting routes in screened catalog samples")
                    (write-json! candidates {:draw draw :catalog state :profiles screen :arms arms})
                    (spit (io/file tmp "catalog.edn") (pr-str state))
                    (spit arms-file (pr-str arms)))
                (do (doseq [[t] specs] (mixed/execute! db (str "ANALYZE " (jdbc/relation [schema t]))))
                    (recur (inc draw)))))))
        "time"
        (let [arms (edn/read-string (slurp arms-file))
              seen (atom []) pool (sql-observer seen)
              ps (into {} (for [arm arms] [arm (providers accepted (second (profile-for arm)) pool)]))]
          (doseq [sample [-1 0 1] arm (if (even? (+ sample block)) arms (reverse arms))]
            (reset! seen [])
            (let [q (arm-query (last (profile-for arm)))
                  start (System/nanoTime)
                  rows (set (apply d/q q @local (ps arm)))
                  ns (- (System/nanoTime) start)
                  shapes (frequencies (map #(signature % schema) @seen))]
              (assert (= gold rows))
              (assert (and (seq shapes) (every? #(zero? (:live-sessions (pg/statistics %))) (ps arm))))
              (append! (io/file out (str "block-" block ".jsonl"))
                       {:arm arm :block block :sample sample :elapsed-ns ns :rows (count rows)
                        :answer-sha (digest (pr-str (sort rows))) :executed shapes}))))
        "capture"
        (doseq [arm (edn/read-string (slurp arms-file))]
          (let [[_ opts policy] (profile-for arm)
                record (plans/capture out "floor" arm
                         (fn [pool reset!]
                           (let [ps (providers accepted opts pool)]
                             (reset!)
                             (let [p (apply d/explain {:run? true} (arm-query policy) @local ps)]
                               (assert (= (count gold) (:result-rows p)))
                               (assert (every? #(zero? (:live-sessions (pg/statistics %))) ps))
                               {:rows (:result-rows p) :cursors (mapv #(select-keys % [:alternative-id :metrics]) (:cursors p))
                                :ids (ids p)}))))]
            (append! (io/file out "actual.jsonl") (assoc record :arm arm)))))
      (finally (d/close local)))))
(defn -main [stage schema tmp out & [block]]
  (assert (re-matches #"dtlv_pfx_[a-f0-9]{32}" schema))
  (try
    (with-open [db (mixed/connection controls/profile)]
      (case stage
        "setup" (setup! db schema tmp out)
        "cleanup" (do (assert (= schema (get (json/read-value (slurp (io/file out "fixture.json"))) "schema")))
                      (mixed/execute! db (str "DROP SCHEMA " (jdbc/identifier schema) " CASCADE")))
        (let [initial (edn/read-string (slurp (io/file tmp "catalog.edn")))]
          (assert (= initial (catalog-state db schema)))
          (run-fixture! stage schema tmp out (when block (parse-long block)))
          (let [final (catalog-state db schema)]
            (assert (= (if (= stage "screen") (edn/read-string (slurp (io/file tmp "catalog.edn"))) initial) final))
            (append! (io/file out "invariants.jsonl") {:stage stage :block block :catalog final})))))
    (finally (shutdown-agents))))
