"""Run the fixed-fixture placement comparison or the default-request-budget test."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import uuid

study = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('panel', choices=['fixed-mixed','triage-budget'])
parser.add_argument('federation', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
cwd = args.federation.resolve()
out = args.output.resolve()
manifest = study/'production-manifest.json'
for path, digest in json.loads(manifest.read_text()).items():
    assert hashlib.sha256((cwd.parent/path).read_bytes()).hexdigest() == digest, path
out.mkdir()
sources = [Path(__file__), *sorted((study/'harness').rglob('*.clj'))]
(out/'inputs.json').write_text(json.dumps(dict(campaign=args.panel,production_manifest=hashlib.sha256(manifest.read_bytes()).hexdigest(),
    harness={str(p.relative_to(study)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}),indent=2)+'\n')
alias = '{:aliases {:measurement {:extra-paths ['+json.dumps(str(study/'harness'))+'] :main-opts ["-m" "datalevin.research.'+args.panel+'"]}}}'
def launch(log, *argv):
    base='workflow-measure' if args.panel=='triage-budget' else 'job-baselines'
    with (out/(log+'.log')).open('x') as stream:
        subprocess.run(['clojure','-Sdeps',alias,'-M:'+base+':measurement',*map(str,argv)],cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,check=True)
if args.panel=='triage-budget':
    launch('block-0',out/'block-0.jsonl')
else:
    with tempfile.TemporaryDirectory(prefix='dtlv-fixed-native-') as tmp:
        schema='dtlv_pfx_'+uuid.uuid4().hex
        shared=[schema,tmp,out]
        launch('setup','setup',*shared)
        try:
            launch('screen','screen',*shared)
            for block in range(2):
                launch(f'block-{block}','time',*shared,block)
            launch('capture','capture',*shared)
        finally:
            launch('cleanup','cleanup',*shared)
