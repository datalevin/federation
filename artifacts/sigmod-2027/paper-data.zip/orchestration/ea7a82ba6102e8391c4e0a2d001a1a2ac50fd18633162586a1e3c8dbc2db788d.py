"""Private loopback TCP delay line. Count PostgreSQL frames without retaining payloads."""
from collections import Counter
import json
import queue
import socket
import threading
import time


def wait_until(due):
    # macOS coalesces ordinary sleeps, sometimes by 25%. Recheck the absolute
    # deadline after shorter sleeps so the first wakeup does not decide it.
    while (left := due-time.monotonic_ns()) > 0:
        time.sleep(0.70*left/1e9)


class Frames:
    def __init__(self, frontend):
        self.startup = frontend
        self.header = bytearray()
        self.remaining = 0
        self.start_fields = None
        self.counts = Counter()
        self.tag = None
        self.bytes = 0

    def feed(self, data):
        self.bytes += len(data)
        view = memoryview(data)
        while view:
            if self.remaining:
                n = min(len(view), self.remaining)
                if self.start_fields is not None:
                    self.start_fields.extend(view[:n])
                self.remaining -= n
                view = view[n:]
                if not self.remaining and self.start_fields is not None:
                    fields = bytes(self.start_fields)[4:].split(b'\0')
                    options = dict(zip(fields[::2], fields[1::2]))
                    tag = options.get(b'application_name', b'').decode('ascii')
                    if not tag.startswith('rtt-'):
                        raise ValueError('Missing study startup tag')
                    self.tag, self.start_fields = tag, None
                continue
            width = 4 if self.startup else 5
            n = min(len(view), width-len(self.header))
            self.header.extend(view[:n])
            view = view[n:]
            if len(self.header)==width:
                kind = 'startup' if self.startup else chr(self.header[0])
                self.counts[kind] += 1
                self.remaining = int.from_bytes(self.header[-4:], 'big')-4
                if not 0 <= self.remaining < 128*1024*1024:
                    raise ValueError('Invalid PostgreSQL frame length')
                if self.startup:
                    self.start_fields = bytearray()
                    self.startup = False
                self.header.clear()


class Relay:
    def __init__(self, rtt, logfile, lock):
        self.rtt = rtt
        self.logfile, self.lock = logfile, lock
        self.listener = socket.socket()
        self.listener.bind(('127.0.0.1', 0))
        self.listener.listen(64)
        self.listener.settimeout(.2)
        self.port = self.listener.getsockname()[1]
        self.stopping = threading.Event()
        self.sessions = []
        self.server = threading.Thread(target=self.accept, daemon=True)
        self.server.start()

    def accept(self):
        while not self.stopping.is_set():
            try:
                client, _ = self.listener.accept()
            except socket.timeout:
                continue
            t=threading.Thread(target=self.serve, args=(client,), daemon=True)
            self.sessions.append(t)
            t.start()

    def serve(self, client):
        front, back = Frames(True), Frames(False)
        errors = []
        start = time.time_ns()
        # The kernel handshakes locally; hold transport setup once per new connection.
        if self.rtt:
            wait_until(time.monotonic_ns()+self.rtt*1000000)
        with client, socket.create_connection(('127.0.0.1',5432),timeout=150) as pg:
            pg.settimeout(None)
            for sock in [client,pg]:
                sock.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
            def direction(src,dst,frames):
                waiting=queue.Queue(maxsize=128)
                def read():
                    try:
                        while data:=src.recv(65536):
                            due=time.monotonic_ns()+self.rtt*500000
                            frames.feed(data)
                            waiting.put((due,data))
                    except Exception as e:
                        errors.append(str(e))
                    finally:
                        waiting.put((time.monotonic_ns()+self.rtt*500000,b''))
                reader=threading.Thread(target=read, daemon=True)
                reader.start()
                try:
                    while True:
                        due,data=waiting.get()
                        wait_until(due)
                        if not data:
                            dst.shutdown(socket.SHUT_WR)
                            break
                        dst.sendall(data)
                except OSError as e:
                    errors.append(str(e))
                reader.join(2)
            directions=[threading.Thread(target=direction,args=args,daemon=True) for args in
                        [(client,pg,front),(pg,client,back)]]
            for t in directions:t.start()
            for t in directions:t.join()
        result=dict(label=front.tag,added_rtt_ms=self.rtt,start_ns=start,end_ns=time.time_ns(),
                    client_messages=front.counts,server_messages=back.counts,
                    client_bytes=front.bytes,server_bytes=back.bytes,errors=errors)
        if any(f.remaining or f.header for f in (front,back)):
            result['errors'].append('incomplete frame')
        with self.lock:
            with self.logfile.open('a') as f: print(json.dumps(result),file=f)

    def close(self):
        self.stopping.set()
        self.server.join()
        self.listener.close()
        for t in self.sessions:t.join(10)
        if any(t.is_alive() for t in self.sessions):
            raise RuntimeError('Relay session did not close')
