"""Replay the exact measurement harness recorded for a supplemental study panel."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

study = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('panel', choices=['triage-budget', 'fixed-mixed', 'fixed-routes', 'fixed-choice'])
parser.add_argument('federation', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
receipt = json.loads((study / args.panel / 'inputs.json').read_text())
with tempfile.TemporaryDirectory(prefix='dtlv-study-replay-') as directory:
    staged = Path(directory)
    shutil.copyfile(study/'production-manifest.json', staged/'production-manifest.json')
    for relative, digest in receipt['harness'].items():
        source = study / relative
        if sha256(source.read_bytes()).hexdigest() != digest:
            source = study/'orchestration'/(digest + source.suffix)
        assert sha256(source.read_bytes()).hexdigest() == digest
        target = staged/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    subprocess.run([sys.executable, staged/'revision_run.py', receipt['campaign'],
                    args.federation.resolve(), args.output.resolve()], check=True)
