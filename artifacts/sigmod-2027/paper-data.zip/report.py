"""Build tables exclusively from complete checked observations in this directory."""
import argparse
from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
from math import ceil
from pathlib import Path
import re
from statistics import mean, median, stdev
import tarfile

STUDY = Path(__file__).resolve().parent
DATA = STUDY.parents[1]/'conference-submissions/sigmod2027-industry/data'
MACROS = {}


def load(path):
    return json.loads((STUDY/path).read_text())


def records(group):
    return [json.loads(line) for path in sorted((STUDY/group).glob('block-*.jsonl'))
            for line in path.read_text().splitlines()]


def save_csv(name, rows):
    with (STUDY/name).open('w', newline='') as out:
        writer = csv.DictWriter(out, list(dict.fromkeys(k for r in rows for k in r)))
        writer.writeheader()
        writer.writerows(rows)


def tex_rows(name, rows):
    MACROS[name] = '\n'+'\n'.join(' & '.join(map(str,r))+r' \\' for r in rows)+'\n'


def batch_widths():
    widths = [1, 16, 64, 256, 1024]
    folder = STUDY/'batch-width'
    original = next(r for r in load('job/block-0.json')['phases']['warm'] if r['id'] == '17c')
    manifest = load('production-manifest.json')
    harness = 'datalevin/research/placement_controls.clj'
    harness_sha = hashlib.sha256((STUDY/'harness'/harness).read_bytes()).hexdigest()
    cast_id, title_id = 'join-0-1-2-5-6-?row_n', 'join-3-4-8-9-?row_t'
    with tarfile.open(STUDY/'production-runtime.tar.gz') as tar:
        pg = 'federation/postgres/src/datalevin/federation/postgres/'
        plan = tar.extractfile(pg+'plan.clj').read()
        rel = tar.extractfile(pg+'relational.clj').read()
    def check(run, mib):
        width = run['requested']
        caps = b':max-binding-rows 256 :max-binding-bytes 2097152 :max-request-binding-rows 256'
        guard = b'(<= 1 (count bindings) 256)'
        assert plan.count(caps) == rel.count(guard) == 1
        new_caps = caps.replace(b'256', str(width).encode()).replace(b'2097152', str(mib*1048576).encode())
        new_guard = guard.replace(b'256', str(max(256, width)).encode())
        assert run['source-hashes'] == {
            'datalevin/query/source/binding.clj': manifest['datalevin/src/datalevin/query/source/binding.clj'],
            'datalevin/federation/postgres/plan.clj': hashlib.sha256(plan.replace(caps, new_caps)).hexdigest(),
            'datalevin/federation/postgres/relational.clj': hashlib.sha256(rel.replace(guard, new_guard)).hexdigest(),
            harness: harness_sha}
        assert run['sql-sha'] == original['sha256'] and run['oracle'] == original['expected']
        assert [c['sample'] for c in run['calls']] == [-1, 0, 1]
        assert all(c['answer'] == run['oracle'] and c['ns'] > 0 for c in run['calls'])
        cursors = {c['id']: c for c in run['cursors']}
        scan = cursors['attribute-enumeration-7-7']
        assert len(cursors) == 3 and scan['opens'] == 1 and scan['read-rows'] == 2664
        for stage, inputs, rows in [(cast_id, 2664, 226), (title_id, 195, 184)]:
            cursor = cursors[stage]
            hist = {int(k): n for k,n in cursor['input-widths'].items()}
            assert all(0 < k <= width and n > 0 for k,n in hist.items())
            assert sum(k*n for k,n in hist.items()) == inputs and sum(hist.values()) == cursor['opens']
            assert cursor['read-rows'] == rows
        return dict(cap=width, binding_mib=mib, max_cast_keys=max(map(int, cursors[cast_id]['input-widths'])),
                    cast_opens=cursors[cast_id]['opens'], title_opens=cursors[title_id]['opens'],
                    jvm=int(run['block'])+1, warm_median_s=median(c['ns'] for c in run['calls'][1:])/1e9)
    rows = []
    for block, order in enumerate([widths, widths[::-1]]):
        runs = [json.loads(line) for line in (folder/f'block-{block}.jsonl').read_text().splitlines()]
        assert [r['requested'] for r in runs] == order and all(int(r['block']) == block for r in runs)
        rows.extend(check(r, 2) for r in runs)
    table = []
    for width in widths:
        a, b = [row for row in rows if row['cap'] == width]
        work = ('max_cast_keys','cast_opens','title_opens')
        assert all(a[k] == b[k] for k in work)
        table.append((f'{width:,}', *(f"{a[k]:,}" for k in work),
                      f"{a['warm_median_s']:.3f} / {b['warm_median_s']:.3f}"))
    tex_rows('BatchWidthRows', table)
    checks = [check(load(f'batch-width/bytes-{mib}mib.jsonl'), mib) for mib in [4, 8]]
    assert all(r['cap'] == 1024 for r in checks)
    MACROS['BatchByteControl'] = ('At 4 and 8\\,MiB the largest cast batches held '
        + ' and '.join(f"{r['max_cast_keys']:,}" for r in checks) + ' keys and required '
        + ' and '.join(str(r['cast_opens']) for r in checks) + ' cast statements, respectively.')
    save_csv('batch-width.csv', rows + checks)


def check_freeze():
    manifest=load('production-manifest.json')
    digest=hashlib.sha256((STUDY/'production-manifest.json').read_bytes()).hexdigest()
    assert load('protocol.json')['production_manifest_sha256']==digest
    campaigns='job job-access routes router public capture replay mixed mixed-plans mixed-check mixed-statistics q5 triage rtt workflow postgres live'.split()
    for campaign in campaigns + ['triage-budget','fixed-mixed','fixed-routes','fixed-order','fixed-choice',
                                'boundaries','boundaries-plans','small-client']:
        receipt=load(f'{campaign}/inputs.json')
        assert receipt['campaign']==('fixed-mixed' if campaign.startswith('fixed-') else campaign) and receipt['production_manifest']==digest
        for relative,fingerprint in receipt['harness'].items():
            if hashlib.sha256((STUDY/relative).read_bytes()).hexdigest()!=fingerprint:
                copy=STUDY/'orchestration'/(fingerprint+Path(relative).suffix)
                assert hashlib.sha256(copy.read_bytes()).hexdigest()==fingerprint
    with tarfile.open(STUDY/'production-runtime.tar.gz','r:gz') as archive:
        assert set(archive.getnames())==set(manifest)
        for entry in archive:
            assert hashlib.sha256(archive.extractfile(entry).read()).hexdigest()==manifest[entry.name]


def job():
    plans = load('routes/routes.json')
    assert plans['planner'] == load('production-manifest.json')['datalevin/src/datalevin/query/source/planning.clj']
    plans = {r['id']:r for r in plans['plans']}
    blocks, aggregate, first_arms, answers = [], defaultdict(list), defaultdict(Counter), {}
    calls = 0
    for b in range(4):
        run=load(f'job/block-{b}.json')
        assert run['block']==b and run['status']=='complete' and run['source-before']==run['source-after']
        if b: assert inventory==run['source-before'] and previous<run['started-at']
        inventory=run['source-before']
        previous=run['finished-at']
        for phase in ['cold','warm']:
            qs=run['phases'][phase]
            assert [q['id'] for q in qs]==(list(plans)[::-1] if b%2 else list(plans))
            totals=[0,0]
            for q in qs:
                id=q['id']
                assert q['status']=='ok' and q['sha256']==plans[id]['sha256']
                assert q['aggregate-checks'][0]['result']['status']=='ok'
                assert q['expected']==answers.setdefault(id,q['expected'])
                assert all(not s['live-sessions'] for s in q['source-statistics'])
                obs,=q['samples']
                first_arms[phase,id][obs['order'][0]]+=1
                assert all(obs[a]['status']=='ok' for a in ('native','adapter'))
                vals=[obs[a]['elapsed-ns']/1e9 for a in ('native','adapter')]
                totals=[x+y for x,y in zip(totals,vals)]
                aggregate[phase,id].append(vals)
                calls+=1
            blocks.append(dict(block=b,phase=phase,original=totals[0],adapter=totals[1],saving=totals[0]-totals[1]))
    assert calls==904 and all(c=={'native':2,'adapter':2} for c in first_arms.values())
    rows=[]
    for (phase,id),pairs in aggregate.items():
        n,a=map(mean,zip(*pairs))
        rows.append(dict(query=id,phase=phase,route=plans[id]['route'],original_s=n,adapter_s=a,ratio=a/n,saving_s=n-a))
    assert {q for q,rs in answers.items() if len(rs)==1 and all(v is None for v in rs[0])}=={'2c','5a','5b','10b','32a'}
    save_csv('job-blocks.csv',blocks)
    save_csv('job-queries.csv',rows)
    warm=[r for r in rows if r['phase']=='warm']
    sorted_w=sorted(warm,key=lambda r:-r['saving_s'])
    with (DATA/'production-job-deltas.csv').open('w') as out:
        print('rank,delta_s,family17_delta_s',file=out)
        for i,r in enumerate(sorted_w):
            delta=-r['saving_s']
            print(i+1,delta,delta if r['query'][:-1]=='17' else 'nan',sep=',',file=out)
    totals=[v for v in blocks if v['phase']=='warm']
    n,a,g=[mean(r[key] for r in totals) for key in ('original','adapter','saving')]
    half=3.182446305*stdev(r['saving'] for r in totals)/2
    f=sum(r['saving_s'] for r in warm if r['query'][:-1]=='17')
    MACROS.update(WarmSQL=f'{n:.2f}', WarmAdapter=f'{a:.2f}', WarmSaving=f'{g:.2f}',
                  WarmLow=f'{g-half:.2f}',WarmHigh=f'{g+half:.2f}',WarmReduction=f'{100*g/n:.1f}',
                  WarmSlower=sum(r['ratio']>1 for r in warm),WarmRatio=f"{median(r['ratio'] for r in warm):.2f}",
                  FamilyGain=f'{f:.2f}',FamilyShare=f'{100*f/g:.0f}')
    tex_rows('BlockRows',[[b+1]+[f"{r[k]:.2f}" for r in blocks if r['block']==b for k in ('original','adapter')] for b in range(4)])
    other=[v for v in warm if v['query'][:-1]!='17']
    without=sum(v['saving_s'] for v in other)/sum(v['original_s'] for v in other)
    losses=sorted(warm,key=lambda r:r['saving_s'])[:3]
    MACROS['LossDetail']=(f"Removing family~17 leaves a {100*abs(without):.1f}\\% "
        +('saving' if without>=0 else 'slowdown')+" on the remaining batch. "
        +"The largest absolute losses are "+", ".join(f"{v['query']} ({-v['saving_s']:.2f}\\,s)" for v in losses)+".")
    route_info=[]
    for name, keys in [('whole',['whole']),('dependent',['coordinator','fragment'])]:
        cohort=[r for r in warm if r['route'] in keys]
        faster=sum(r['saving_s']>0 for r in cohort)
        route_info.append(f"the {len(cohort)} {name} queries save {sum(r['saving_s'] for r in cohort):.2f}\\,s in total ({faster} faster, {len(cohort)-faster} slower)")
    MACROS['RouteAccounting']=' and '.join(route_info)+'.'
    return {q for q in plans if plans[q]['route']!='whole'}


def timing(group,ids,arms):
    data=defaultdict(list)
    snapshots=load('production-manifest.json')
    gold={q['id']:q['expected'] for q in load('job/block-0.json')['phases']['warm']}
    cells=set()
    for r in records(group):
        for resource,fingerprint in r['sources'].items():
            prefix='federation/postgres/src/' if resource.startswith('datalevin/federation/') else 'datalevin/src/'
            assert fingerprint==snapshots[prefix+resource]
        assert r['oracle']==gold[r['id']]
        cell=r['id'],r['added-rtt-ms'],r['block']
        assert cell not in cells and r['block'] in (0,1)
        cells.add(cell)
        assert set(r['plans'])==set(arms)
        assert r['id'] in ids
        assert sorted((c['mode'],c['sample']) for c in r['calls'])==sorted((arm,i) for arm in arms for i in (-1,0,1))
        assert all(call['answer']==r['oracle'] for call in r['calls'])
        for call in r['calls']:
            if call['sample']>=0:
                data[r['id'],r['added-rtt-ms'],call['mode']].append(call['elapsed-ns']/1e9)
    levels=[0,5,20] if group=='rtt' else [0]
    assert cells=={(q,l,b) for q in ids for l in levels for b in range(2)}
    assert all(len(v)==4 for v in data.values())
    return data


def recurring_routes(ordered_ids):
    """Replay choices made in the first router JVM against calls in the second."""
    by_block = {(r['block'], r['id']): r for r in records('router')}
    rows = []
    for query in ordered_ids:
        trial, repeat = (by_block[b, query]['calls'] for b in (0, 1))
        trial_means, repeat_means = [
            {mode: mean(c['elapsed-ns'] for c in calls if c['mode'] == mode and c['sample'] >= 0) / 1e9
             for mode in ('auto', 'sql')}
            for calls in (trial, repeat)
        ]
        choice = 'sql' if trial_means['sql'] < trial_means['auto'] else 'auto'
        rows.append(dict(query=query, trial_auto_s=trial_means['auto'], trial_sql_s=trial_means['sql'],
                         trial_all_calls_s=sum(c['elapsed-ns'] for c in trial) / 1e9, choice=choice,
                         repeat_auto_s=repeat_means['auto'], repeat_sql_s=repeat_means['sql'],
                         repeat_choice_s=repeat_means[choice]))
    save_csv('recurring-routes.csv', rows)
    cost = sum(r['trial_all_calls_s'] for r in rows)
    baseline = sum(r['repeat_auto_s'] for r in rows)
    chosen = sum(r['repeat_choice_s'] for r in rows)
    MACROS.update(TrialCalls=f'{cost:.2f}', RepeatAuto=f'{baseline:.2f}', RepeatChoice=f'{chosen:.2f}',
                  TrialPayback=str(ceil(cost / (baseline - chosen))) if chosen < baseline else 'never')


def controls(ids):
    r=timing('router',ids,['auto','sql'])
    public=timing('public',ids,['auto','prefix'])
    ordered=sorted(ids,key=lambda s:(int(s[:-1]),s[-1]))
    recurring_routes(ordered)
    rows=[]
    for id in ordered:
        rows.append(dict(query=id,automatic=mean(r[id,0,'auto']),whole=mean(r[id,0,'sql']),
                         default_prefix_control=mean(public[id,0,'auto']),prefix=mean(public[id,0,'prefix'])))
    save_csv('placement-times.csv',rows)
    columns = ('automatic', 'whole', 'default_prefix_control', 'prefix')
    tex_rows('ControlRows', [[v['query']] + [f"{v[k]:.3f}" for k in columns] for v in rows])
    totals = [sum(v[k] for v in rows) for k in columns]
    tex_rows('ControlTotal', [['Sum'] + [f'{total:.3f}' for total in totals]])
    auto, whole = totals[:2]
    MACROS.update(RouterAuto=f'{auto:.2f}',RouterWhole=f'{whole:.2f}',
                  RouterWorstLoss=f"{max(v['automatic']-v['whole'] for v in rows):.2f}")
    wins=sum(v['automatic']<v['whole'] for v in rows)
    MACROS['RouterInterpretation']=(f"On these {len(ids)} queries the sum of the mean times is {auto:.2f}\\,s with automatic routing "
        f"and {whole:.2f}\\,s with forced delegation. The router wins on {wins} and loses on {len(ids)-wins}. "
        "This intervention measures the value of scheduling beyond the compiler's ability to generate a different single statement.")
    most_helped=max(rows,key=lambda v:v['whole']-v['automatic'])
    most_hurt=min(rows,key=lambda v:v['whole']-v['automatic'])
    if most_helped['automatic']<most_helped['whole'] and most_hurt['automatic']>most_hurt['whole']:
        MACROS['RouterInterpretation']+=(f" The largest gain is {most_helped['query']} "
            f"({most_helped['whole']-most_helped['automatic']:.2f}\\,s) and the largest loss is {most_hurt['query']} "
            f"({most_hurt['automatic']-most_hurt['whole']:.2f}\\,s).")
    replay=defaultdict(list)
    oracle=next(q['expected'] for q in load('job/block-0.json')['phases']['warm'] if q['id']=='17c')
    for v in records('replay'):
        assert v['answer']==oracle
        if v['sample']>=0:replay[v['mode']].append(v['elapsed-ns']/1e9)
    assert all(len(replay[a])==4 for a in ['direct','adapter'])
    whole_sql=median(replay['direct'])
    through_adapter=median(replay['adapter'])
    MACROS['ReplayInterpretation']=(f"The generated statement takes {whole_sql:.3f}\\,s directly "
                                    f"and {through_adapter:.3f}\\,s through the adapter (warm medians).")
    rtt=timing('rtt',{'17c'},['auto','sql'])
    exchanges=defaultdict(set)
    calibration=defaultdict(list)
    for r in records('rtt'):
        delay=r['added-rtt-ms']
        wire=[json.loads(line) for line in (STUDY/'rtt'/f"wire-{r['block']}.jsonl").read_text().splitlines()]
        for phase in ('calibration-before','calibration-after'):
            assert len(r[phase])==12
            calibration[delay].extend(n/1e6 for n in r[phase])
        for call in r['calls']:
            label='placement-17c-'+call['mode']
            sessions=[s for s in wire if s['added_rtt_ms']==delay and s['label']==label
                      and call['start-ms']*1_000_000<=s['start_ns']<(call['end-ms']+1)*1_000_000]
            assert len(sessions)==1 and not sessions[0]['errors']
            client=sessions[0]['client_messages']
            simple, sync = client.get('Q',0), client.get('S',0)
            assert client['startup'] == client['X'] == 1
            assert sessions[0]['server_messages']['Z'] == 1 + simple + sync
            exchanges[call['mode']].add((simple, sync))
    levels=[(l,median(rtt['17c',l,'auto']),median(rtt['17c',l,'sql'])) for l in [0,5,20]]
    assert all(len(v)==1 for v in exchanges.values())
    (aq, asyncs), (sq, ssyncs) = [next(iter(exchanges[k])) for k in ('auto','sql')]
    ac, sql = aq + asyncs, sq + ssyncs
    save_csv('rtt-times.csv',[dict(added_ms=l,automatic_s=a,whole_s=s,automatic_exchanges=ac,
                                  whole_exchanges=sql,calibration_ms=median(calibration[l])) for l,a,s in levels])
    tex_rows('RttRows',[(l,f'{a:.3f}',f'{s:.3f}') for l,a,s in levels])
    desc=lambda a,s:'automatic routing' if a<s else 'whole-query delegation'
    MACROS['RttInterpretation']=(f"At 5\\,ms {desc(*levels[1][1:])} leads by {abs(levels[1][1]-levels[1][2]):.2f}\\,s. "
                                  f"At 20\\,ms {desc(*levels[2][1:])} leads by {abs(levels[2][1]-levels[2][2]):.2f}\\,s. "
                                  f"Each automatic call sent {aq} simple Query and {asyncs} extended-protocol Sync messages. "
                                  f"Whole SQL sent {sq} and {ssyncs}, giving {ac} and {sql} client messages of these types. "
                                  f"The server sent {ac+1} and {sql+1} ReadyForQuery "
                                  "messages, respectively, including one at startup on each fresh connection.")
    gaps = []
    for (l0,a0,s0),(l1,a1,s1) in zip(levels, levels[1:]):
        for arm, count, elapsed in [('automatic',ac,a1-a0),('whole',sql,s1-s0)]:
            nominal = count*(l1-l0)/1000
            gaps.append(dict(from_ms=l0,to_ms=l1,route=arm,query_plus_sync=count,
                             observed_delta_s=round(elapsed,6), count_times_delta_s=round(nominal,6),
                             remainder_s=round(elapsed-nominal,6)))
    save_csv('rtt-accounting.csv',gaps)
    lo, hi = gaps[0], gaps[2]
    MACROS['RttAccounting']=(f"For automatic routing the median rose {lo['observed_delta_s']:.3f}\\,s from 0 to 5\\,ms "
        f"and {hi['observed_delta_s']:.3f}\\,s from 5 to 20\\,ms. Multiplying {ac} by each delay increment gives "
        f"{lo['count_times_delta_s']:.3f} and {hi['count_times_delta_s']:.3f}\\,s, leaving "
        f"{lo['remainder_s']:.3f} and {hi['remainder_s']:.3f}\\,s. "
        f"For whole SQL the corresponding increases were {gaps[1]['observed_delta_s']:.3f} and "
        f"{gaps[3]['observed_delta_s']:.3f}\\,s against products of {gaps[1]['count_times_delta_s']:.3f} "
        f"and {gaps[3]['count_times_delta_s']:.3f}\\,s. "
        "Median single-statement calibration times on an open connection were "
        + ', '.join(f'{median(calibration[l]):.2f}' for l,_,_ in levels) + "\\,ms at the three settings.")
    return rows


def triage():
    runs=defaultdict(list)
    for r in records('triage'):
        assert len(r['answer'])==1
        if r['sample']<0:continue
        work=r['work']
        runs[r['native'],r['export'],r['mode']].append(
            (work['issue-gets']+work['repository-gets'], work['validated-records'],r['elapsed-ns']/1e6))
    rows=[]
    for native,export in [(2048,16),(16,512)]:
        for mode,label in [('caller','Caller'),('literal','Literal'),('parameter','Parameter')]:
            values=runs[native,export,mode]
            counts={v[:2] for v in values}
            assert len(values)==6 and len(counts)==1
            rows.append([f'{native:,} / {export}',label,*next(iter(counts)),f'{median(x[2] for x in values):.0f}'])
    tex_rows('TriageRows',rows)
    save_csv('triage.csv',[dict(zip(('native_and_file_rows','threshold','gets','validated','median_ms'),r)) for r in rows])
    assert all(rows[i][2]==rows[i+1][2] for i in (1,4))
    MACROS['TriageInterpretation']=(f"On the 2,048-row fixture the literal and parameter forms each issue {rows[1][2]} GETs. "
        f"Moving the parameter from a caller-side filter into the query takes the median from {rows[0][4]} to {rows[2][4]} ms. "
        f"On the export-heavy fixture the same change saves {rows[3][2]-rows[5][2]} GETs, but the adapter still validates "
        f"all {rows[5][3]} file records. The complete-call saving there is only {int(rows[3][4])-int(rows[5][4])} ms.")


def contract_groups():
    with (STUDY/'contract/tests.csv').open() as f:
        tests = list(csv.DictReader(f))
    groups = defaultdict(list)
    assert len({(row['file'], row['test']) for row in tests}) == len(tests)
    with tarfile.open(STUDY/'production-runtime.tar.gz') as archive:
        for row in tests:
            lines = archive.extractfile(row['file']).read().decode().splitlines()
            assert lines[int(row['line'])-1] == '(deftest ' + row['test']
            assert row['fail'] == row['error'] == '0' and int(row['pass']) > 0
            groups[row['group']].append(int(row['pass']))
    labels = ['types', 'binding and batch scope', 'summary eligibility', 'observable effects', 'failure and cleanup']
    assert set(groups) == {f'T{i}' for i in range(1, 6)}
    MACROS['ContractGroups'] = ', '.join(f'{g} {label} {len(groups[g])}/{sum(groups[g])}'
        for g, label in zip(sorted(groups), labels))
    MACROS['ContractTests'] = len(tests)
    MACROS['ContractAssertions'] = sum(sum(counts) for counts in groups.values())


def smoke():
    q5_run=load('q5/q5.json')
    assert q5_run['planner']==load('routes/routes.json')['planner']
    q5=q5_run['checks']
    assert [c['id'] for c in q5]==['q5-order1','q5-scoped']
    assert all(c['matches'] and c['live-sessions']==0 for c in q5)
    assert [len(c['oracle']) for c in q5]==[6,5] and all(n==1 for _,n in q5[0]['oracle'])
    results={}
    for panel, path in [('workflow','workflow/block-0.log'), ('postgres','postgres/block-0.log'),
                        ('postgres-corrected','contract/corrected-suite.log')]:
        log=(STUDY/path).read_text()
        m=re.search(r'Ran (\d+) tests containing (\d+) assertions\.\s*(\d+) failures, (\d+) errors\.',log)
        assert m,(panel,log[-250:])
        tests,assertions,failures,errors=map(int,m.groups())
        results[panel]=dict(suite=panel,tests=tests,assertions=assertions,failures=failures,errors=errors)
        if panel!='postgres':
            assert failures==errors==0
        else:
            names=re.findall(r'^FAIL in \(([^)]+)\)',log,re.M)
            assert errors==0 and len(names)==failures
            assert set(names)=={'decimal-and-temporal-filters-reduce-transfer-in-ordinary-queries'}
            checks=re.findall(r'^expected: (.*)$',log,re.M)
            assert failures==len(checks)==5
            assert sum('(read-rows explained)' in check for check in checks)==3
            assert sum('(:prefilters ' in check for check in checks)==2
            assert log.count('actual: (not (= 10 1000))')==2 and log.count('actual: (not (= 1000 11))')==1
    save_csv('operational-checks.csv',list(results.values()))
    original, corrected = results['postgres'], results['postgres-corrected']
    assert original['tests'] == corrected['tests']
    contract_groups()
    MACROS['FilterEvidence']=(
        f"Five of {original['assertions']:,} assertions failed on the benchmark build in a 1,000-row fixture (I317). "
        "The adapter overlooked the integral identity attribute when compiling prefilters. "
        "For both operand orders of $id>990$, PostgreSQL sent all 1,000 rows. "
        "Restoring the key to predicate selection fixed four checks. Both plans selected the filter and each transferred ten rows. "
        "The fifth assertion expected a full transfer for a decimal amount compared with the double literal 99.0. "
        "The SQL prefilter already used a conservative bound. It sent 11 rows, including 99.0000, "
        "and the local strict comparison retained ten. We corrected that expectation and added a mixed-equality "
        "control that requires all 1,000 rows and an empty prefilter selection. "
        f"With these changes all {corrected['assertions']:,} assertions in {corrected['tests']} PostgreSQL tests passed.")
    live=(STUDY/'live/block-0.log').read_text()
    assert ':persisted-reopen? true' in live
    MACROS['OperationalEvidence']=("A read-only query to public GitHub joined an issue to the pinned export after reopening "
        "the native database, then released its session and spool. "
        f"All {results['workflow']['tests']} workflow tests passed ({results['workflow']['assertions']} assertions).")


def executed_plans():
    rows=[]
    for panel in ['capture','mixed-plans','mixed-check','fixed-mixed','fixed-routes','fixed-choice']:
        for path in sorted((STUDY/panel).glob('*.json.gz')):
            with gzip.open(path,'rt') as input:
                cap=json.load(input)
            assert cap['plans'] and len(cap['plans'])==len(cap['queries'])
            for i,plan in enumerate(cap['plans']):
                def visit(node,parent):
                    idx=len(rows)
                    rows.append(dict(panel=panel,capture=path.stem,statement=i,node=idx,parent=parent,
                        operator=node['Node Type'],relation=node.get('Relation Name',''),index=node.get('Index Name',''),
                        cte=node.get('CTE Name',''),per_loop_rows=node['Actual Rows'],loops=node['Actual Loops'],
                        rejected_per_loop=node.get('Rows Removed by Join Filter',0),temp_reads=node.get('Temp Read Blocks',0)))
                    for child in node.get('Plans',[]):visit(child,idx)
                visit(plan['Plan'],'')
    save_csv('executed-operators.csv',rows)


def external():
    rows=[]
    gold={r['id']:r['expected'] for r in load('job/block-0.json')['phases']['warm']}
    rejected={}
    for arm in ('duckdb','accio'):
        lines=[json.loads(line) for line in (STUDY/'compatibility'/f'{arm}.jsonl').read_text().splitlines()]
        assert lines[0]['environment']['source_read_only']==[['on']]
        obs=lines[1:]
        assert {q['query'] for q in obs}==set(gold) and len(obs)==113
        for q in obs:
            if q['status']=='error':
                assert q['error']
                if arm=='accio':
                    rejected[q['query']]=q['error']
            else:
                expected=[[None if x is None else str(x) for x in row] for row in gold[q['query']]]
                assert q['expected']==expected
                assert (q['result']==expected)==(q['status']=='match')
        c=Counter(q['status'] for q in obs)
        rows.append(dict(engine=arm,attempted=len(obs),matched=c['match'],mismatched=c['mismatch'],errors=c['error']))
    retries=[json.loads(line) for line in (STUDY/'compatibility/accio-standard.jsonl').read_text().splitlines()]
    assert retries[0]['environment']['source_read_only']==[['on']]
    assert len(retries)-1==len(rejected) and {q['query'] for q in retries[1:]}==set(rejected)
    assert all("Bang equal '!='" in msg for msg in rejected.values())
    for q in retries[1:]:
        if q['status']!='error':
            assert q['expected']==[[None if x is None else str(x) for x in row] for row in gold[q['query']]]
            assert (q['result']==q['expected'])==(q['status']=='match')
    counts=Counter(q['status'] for q in retries[1:])
    rows.append(dict(engine='accio-standard-inequality-retry',attempted=len(rejected),matched=counts['match'],
                     mismatched=counts['mismatch'],errors=counts['error']))
    save_csv('compatibility.csv',rows)
    MACROS['ExternalEvidence']=(f"DuckDB matched {rows[0]['matched']} of the 113 original PostgreSQL answers. "
        f"Accio matched {rows[1]['matched']} and rejected {len(rejected)} queries using PostgreSQL's "
        f"\\texttt{{!=}} spelling. With standard SQL \\texttt{{<>}} in those queries, {counts['match']} matched. "
        "The harness supplies PostgreSQL-compatible text ordering for local minima and sends Accio one statement "
        "per call. Accio's generated remote SQL runs through the DuckDB connector.")


def write():
    check_freeze()
    ids=job()
    controls(ids)
    batch_widths()
    triage()
    smoke()
    external()
    executed_plans()
    from plan_tables import summarize
    summarize(STUDY, records, save_csv, MACROS, tex_rows)
    from revision_report import summarize_revision
    summarize_revision(STUDY, records, save_csv, MACROS, tex_rows)
    from stability_report import summarize_access, summarize_statistics
    summarize_access(STUDY, save_csv)
    summarize_statistics(STUDY, save_csv)
    from transfer_report import summarize_transfer
    summarize_transfer(STUDY, save_csv, MACROS, tex_rows)
    from boundary_report import summarize as summarize_boundaries
    summarize_boundaries(STUDY, save_csv, MACROS, tex_rows)
    (DATA/'production-results.tex').write_text('% Generated by the production placement study.\n'+
            ''.join('\\newcommand{\\'+k+'}{'+str(v)+'}\n' for k,v in MACROS.items()))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--paper-data', type=Path, default=DATA, help='destination for generated manuscript inputs')
    args=parser.parse_args()
    DATA=args.paper_data
    DATA.mkdir(parents=True, exist_ok=True)
    write()
