"""Check the supplemental controls and derive the fixed-fixture table from executed work."""
from collections import Counter
import gzip
import json
from statistics import median

from plan_tables import stats


def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def fixed_panel(path, observations):
    fixture = json.loads((path/'fixture.json').read_text())
    screen = json.loads((path/'screen.json').read_text())
    catalog = screen.get('catalog', fixture['catalog'])
    checks = lines(path/'invariants.jsonl')
    assert [(c['stage'], c['block']) for c in checks] == [('screen', None), ('time', '0'), ('time', '1'), ('capture', None)]
    assert all(c['catalog'] == catalog for c in checks)
    answers = {(v['rows'], v['answer-sha']) for v in observations}
    assert len(answers) == 1 and next(iter(answers))[0] == 4183
    captures = {r['arm']: r for r in lines(path/'actual.jsonl')}
    assert set(captures) == set(screen['arms']) == {r['arm'] for r in observations}
    for arm in screen['arms']:
        calls = [r for r in observations if r['arm'] == arm]
        assert sorted((r['block'], r['sample']) for r in calls) == [(b, i) for b in (0, 1) for i in (-1, 0, 1)]
        capture = captures[arm]
        trace = path/capture['trace']
        with gzip.open(trace, 'rt') as stream:
            statements = json.load(stream)['queries']
        relations = ['+'.join(t for t in ('edge', 'target', 'category')
                              if f'"{fixture["schema"]}"."{t}"' in q['sql']) for q in statements]
        assert all(relations)
        order = tuple(dict.fromkeys(relations))
        assert all(r['executed'] == Counter(relations) for r in calls)
        assert all(tuple(r.get('cursor-order', order)) == order for r in calls)
        metrics = stats(trace)
        result = capture['result']
        assert result['rows'] == 4183
        assert sum(c['metrics']['rows'] for c in result['cursors']) == metrics['output_rows']
        times = [[r['elapsed-ns']/1e9 for r in calls if r['sample'] >= 0 and r['block'] == b] for b in (0, 1)]
        yield dict(panel=path.name, arm=arm, cursor_order=' / '.join(order),
                   ids=' '.join(result['ids']), data_statements=metrics['data_statements'], commands=metrics['commands'],
                   sql_rows=int(metrics['output_rows']), base_tuples=int(metrics['base_tuples']), result_rows=result['rows'],
                   jvm1_s=median(times[0]), jvm2_s=median(times[1]), median_s=median(times[0]+times[1]))


def summarize_revision(study, records, save, macros, tex_rows):
    budget = {x['form']: x for x in records('triage-budget')}
    assert set(budget) == {'caller', 'literal', 'parameter'} and all(r['clean'] for r in budget.values())
    for form in ['literal', 'parameter']:
        assert budget[form]['answer'] == [[1, 10, 'Work item 1', 'now']]
        assert budget[form]['work'] == {'issue-gets': 2, 'repository-gets': 1, 'validated-records': 16}
    assert budget['caller']['failure'] == dict(error='query-source/limit', phase='fetch', category='external-requests', maximum=1024, attempted=1025)
    assert budget['caller']['work'] == {'issue-gets': 1022, 'repository-gets': 1, 'validated-records': 16}

    rows = [row for panel in ('fixed-mixed', 'fixed-routes', 'fixed-choice') for row in fixed_panel(study/panel, records(panel))]
    save('fixed-access.csv', rows)
    fixed = {r['cursor_order']: r for r in rows if r['panel'] == 'fixed-choice'}
    labels = [('category / target / edge', 'Category first', 'Separate'),
              ('edge / target / category', 'Edge first', 'Separate'),
              ('edge / target+category', 'Edge first', 'Joined')]
    assert set(fixed) == {key for key, _, _ in labels}
    tex_rows('FixedRows', [[first, access, f"{row['data_statements']} / {row['commands']}", f"{row['sql_rows']:,}",
                            f"{row['jvm1_s']:.2f}", f"{row['jvm2_s']:.2f}"]
                           for key, first, access in labels for row in [fixed[key]]])
    draws = lines(study/'fixed-choice'/'draws.jsonl')
    screen = json.loads((study/'fixed-choice'/'screen.json').read_text())
    assert draws[-1]['catalog'] == screen['catalog'] and screen['draw'] == len(draws)-1
    def edge_estimate(draw):
        default = next(p for p in draw['profiles'] if p['arm'] == 'default')
        edge = next(s for s in default['steps'] if s['source'] == '$edge' and s['alternative-id'].startswith('value-lookup'))
        return edge['estimate']['rows-per-binding']
    assert next(p for p in draws[-1]['profiles'] if p['arm']=='default')['steps'][0]['estimate']['rows']==128
    macros.update(EdgeEstimateBefore=f'{edge_estimate(draws[0]):.2f}', EdgeEstimateAfter=f'{edge_estimate(draws[-1]):.2f}')

    operators = []
    for cap in lines(study/'fixed-choice'/'actual.jsonl'):
        for region in cap['result']['regions']:
            for op in region['operators']:
                actual = op['actual']
                operators.append(dict(arm=cap['arm'], operator=op['operator-id'], kind=op['kind'],
                                      source=op.get('source', ''), access=op.get('alternative-id', ''),
                                      inputs=actual['input-rows'], outputs=actual['output-rows'],
                                      inclusive_s=actual['elapsed-ns']/1e9))
    save('fixed-intermediates.csv', operators)
    category = fixed['category / target / edge']
    separate = fixed['edge / target / category']
    joined = fixed['edge / target+category']
    for name, before, after in [('FirstLookupCI', category, separate), ('SourceJoinCI', separate, joined)]:
        d1, d2 = (before[field] - after[field] for field in ('jvm1_s', 'jvm2_s'))
        # With two paired JVMs, the standard error is half their absolute difference (df=1).
        center = (d1 + d2) / 2
        half_width = 12.706204736 * abs(d1 - d2) / 2
        macros[name] = f'{center:.2f}\\,s [{center-half_width:.2f}, {center+half_width:.2f}]'
    def access_steps(row):
        return [op for op in operators if op['arm']==row['arm'] and op['kind']=='access']
    assert [(o['inputs'], o['outputs']) for o in access_steps(category)] == [(256,16384),(16384,262144),(262144,8192)]
    assert [(o['inputs'], o['outputs']) for o in access_steps(joined)] == [(256,32768),(32768,8192)]
    assert [o['outputs'] for o in access_steps(separate)] == [32768,32768,32768]
    macros.update(EdgeStepTime=f"{access_steps(category)[-1]['inclusive_s']:.2f}",
                  CategoryFirstTime=f"{category['median_s']:.2f}", EdgeSeparateTime=f"{separate['median_s']:.2f}",
                  EdgeJoinedTime=f"{joined['median_s']:.2f}")
