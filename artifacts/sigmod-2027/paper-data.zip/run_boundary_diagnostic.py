"""Run an untimed spill diagnostic or a full JOB pass with a 1 GiB client heap."""
from pathlib import Path
from hashlib import sha256
import argparse
import json
import subprocess
import os
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('panel', choices=['boundaries-plans','small-client'])
p.add_argument('checkout', type=Path)
p.add_argument('output', type=Path)
args = p.parse_args()
study = Path(__file__).resolve().parent
checkout, output = args.checkout.resolve(), args.output.resolve()
manifest = study/'production-manifest.json'
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
for name, fingerprint in json.loads(manifest.read_text()).items():
    assert digest(checkout.parent/name) == fingerprint, name
output.mkdir()
form = 'job-spills' if args.panel=='boundaries-plans' else 'job-small-client'
sources = [Path(__file__), study/'job/block-0.json',
           *(study/f'harness/datalevin/research/{name}.clj' for name in
             (form.replace('-','_'),'job_boundaries','production_job','public_plans'))]
(output/'inputs.json').write_text(json.dumps(dict(campaign=args.panel,production_manifest=digest(manifest),
    harness={str(s.relative_to(study)):digest(s) for s in sources}),indent=2)+'\n')
alias = '{:aliases {:measurement {:extra-paths ['+json.dumps(str(study/'harness'))+'] :main-opts ["-m" "datalevin.research.'+form+'"]}}}'
heap = ['-J-Xms128m','-J-Xmx1g','-J-XX:MaxDirectMemorySize=256m'] if args.panel=='small-client' else []
with (output/'diagnostics.log').open('x') as log:
    proc = subprocess.Popen(['clojure',*heap,'-Sdeps',alias,'-M:job-baselines:measurement',str(output),str(sources[1])],
                            cwd=checkout,stdout=log,stderr=subprocess.STDOUT)
    pid,status,usage = os.wait4(proc.pid, 0)
    proc.returncode = os.waitstatus_to_exitcode(status)
    if heap:
        assert sys.platform in ('darwin','linux')
        (output/'process.json').write_text(json.dumps(dict(pid=pid,exit_code=proc.returncode,
            peak_rss_bytes=usage.ru_maxrss*(1 if sys.platform=='darwin' else 1024)))+'\n')
    if proc.returncode:
        raise SystemExit(proc.returncode)
