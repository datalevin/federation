# JOB 31b, 7c, and 17f investigation

All three targets now select complete SQL automatically. The final pass verifies
their original aggregates and complete distinct projected tuple sets, using the
same resource limits as the preceding full-suite pass.

| Query | Before: adapter | Final: adapter | Final: native | Verified tuples |
| --- | ---: | ---: | ---: | ---: |
| 31b | 15.464 s | **0.318 s** | 0.260 s | 12 |
| 7c | Failed after 33.222 s, 8 GiB retained limit | **1.367 s** | 2.449 s | 2,561 |
| 17f | Failed after 80.675 s, 8 GiB retained limit | **7.470 s** | 7.214 s | 56,347 |

These are client times, including connection, snapshot/metadata acquisition,
planning, estimation, execution, decoding, and cleanup. Both the preceding
full-suite baseline and the final pass use one sample without explicit warmups.
They are separate passes with uncontrolled cache, JIT, and GC histories, so these
figures are screens rather than repeated-win claims.

## 31b: a bridge filter was mistaken for a dimension driver

The automatic policy declined complete SQL because it counted two text drivers:
the company-name prefix and the movie-company note containing `Blu-ray`. The
latter belongs to a bridge with outgoing references. Treating it as an independent
selective dimension was too optimistic for this larger join graph.

The [executed dependent plan](postgres-job-31b-auto-before-2026-11-10.edn) reads
61,197 rows through 164 cursors and 732 cursor requests. The first dependent join,
over cast and movie-info records, returns 39,568 rows for one binding despite an
estimate of 0.233 rows per binding. It alone spends 10.80 s in cursor work; the
later title filter leaves only a small result. The generic cardinality estimate
does not capture this skew. The change fixes the automatic preference rather
than claiming to repair all underlying estimates.

The larger-graph preference now counts strong text drivers only on dimensions
without outgoing reference reads. This removes the false second driver in 31b
while retaining the two leaf drivers used by 20b. The small-graph projected text
driver and membership rule remains available. No query IDs, cached answers, or
new estimation I/O are used.

An [isolated forced-SQL comparison](postgres-job-31b-forced-sql-2026-11-10.edn)
takes 0.296–0.303 s across three timed samples, verifying all four minima and
all 12 tuples. The final automatic pass takes 0.318 s. In the larger repeated
diagnostic, automatic SQL varies from 0.465–3.394 s (median 0.763 s), and native
varies from 0.312–1.469 s. All samples are retained; the isolated result is not
treated as a fixed cost across execution histories.

## 7c: two eligibility blockers kept a scalar filter in core

The first blocker was the nested scalar condition on gender and name. The
existing whole-query path admitted simple LIKE unions, but not general bounded
AND/OR over values already bound by outer fact patterns. That kept the joins,
intermediates, and aggregation in the core engine, where retained memory exceeded
8 GiB.

Adding Boolean request construction alone was insufficient: the
[initial diagnostic](postgres-job-7c-boolean-after-2026-11-10.edn) still fails
because the string `BETWEEN 'A' AND 'F'` becomes a chained comparison, and only
integer chains were normalized. Whole-query planning now splits scalar chains
into adjacent comparisons. The provider still proves every leaf's types,
constants, ordering, and collation; this query's ASCII string bounds use the
existing exact binary comparison implementation.

The optional descriptor capability
`:datalevin.query.source/boolean-filters-relational?` admits owned logical
clauses containing scalar predicates. Core bounds the logical forest to 128
nodes and depth 16, with at most 32 branches per OR. Each branch can use only
values imported into that scope. Branch facts, functions, rules, negation,
unsupported leaves, and comparisons over optional nullable projections retain
core execution. Overlapping branches filter one witness once rather than
duplicating aggregate inputs.

There is no new execution operator or cache. PostgreSQL evaluates the complete
filter, joins, and MIN together under the existing acquired snapshot, schema,
authorization, ownership, cancellation, decoding, and resource checks. The
final pass takes 1.367 s and verifies all 2,561 tuples. The earlier three-sample
diagnostic takes 1.281–1.294 s against native's 1.789–1.798 s.

## 17f: existence probes need a selective driver

The identity-only company and title probes triggered dependent preference even
though the only name condition was the broad substring `%B%`. That shape reached
the 8 GiB retained limit after 80.675 s in the full pass.

The existence-probe exception now requires an anchored prefix or at least four
literal pattern characters. It still accepts the `X%` and `%Bert%` drivers used
by 17c and 17d, while 17f prefers complete SQL. Its final execution takes 7.470 s
against native's 7.214 s, with the original minimum and all 56,347 tuples verified.
No memory or result limits were raised.

## Regression cohort and evidence

The final ten queries are 6d, 7a, 7c, 10c, 12b, 17c, 17d, 17f, 20b, and 31b.
All ten verify their original aggregates and complete projected tuple sets, with
zero live source sessions after execution. Their total client time is
**16.130 s versus native's 42.096 s**. This selected cohort includes established
dependent wins and is not representative evidence of full-suite parity.

Plan checks retain dependent execution for 6d, 10c, 17c, 17d, and 20b. Their final
times are 0.434/1.471/1.044/1.856/0.374 s, versus native's
6.980/7.898/6.107/6.175/1.863 s. The Boolean extension also admits 7a and 12b:
7a falls from 6.455 s to 1.744 s, while 12b falls from 1.381 s to 0.051 s.

The final pass uses the exact delivered implementation; all 28 source
fingerprints match the workspace. An earlier repeated diagnostic uses three
samples and one warmup, before the final branch-import validation guard. Its
source fingerprints and every sample are retained separately. Full-suite totals
and the six earlier tuple-oracle result-limit failures have not been remeasured
after these changes. JOB data, indexes, and statistics were not changed.

Final validation passes **313 tests and 8,286 assertions**, with zero failures
or errors, covering the PostgreSQL/JOB suites and affected core relational,
aggregation, planning, execution, session, region, and scope behavior. Changed
source and tests pass clj-kondo without warnings or errors. Tests include
overlapping Boolean branches, branch import boundaries, unsupported-operation
fallback, optional NULL comparisons, chained string comparisons, and logical
node/depth limits.

- [Final run](postgres-job-31b-7c-17f-final-2026-11-10.edn).
- [Summary and source verification](postgres-job-31b-7c-17f-summary-2026-11-10.edn).
- [Per-query before/after CSV](postgres-job-31b-7c-17f-comparison-2026-11-10.csv).
- [Selected plans](postgres-job-31b-7c-17f-final-plans-2026-11-10.edn).
- [Repeated diagnostic](postgres-job-31b-7c-17f-repeated-diagnostic-2026-11-10.edn).
- [Final regression log](postgres-job-31b-7c-17f-tests-2026-11-10.txt).

Run the final cohort with `POSTGRES_JOB_URL` pointing to the existing read-only
JOB connection:

```sh
clojure -M:postgres-job:postgres-job-suite \
  '{:queries [:6d :7a :7c :10c :12b :17c :17d :17f :20b :31b] :samples 1 :warmups 0}' \
  /tmp/postgres-job-targets.edn
```
