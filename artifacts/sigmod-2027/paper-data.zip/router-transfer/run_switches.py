"""Time every newly split JOB query, in opposing query and arm orders."""
import json
from pathlib import Path
import subprocess
import sys

here = Path(__file__).resolve().parent
work = Path(sys.argv[1]).resolve()  # output of run_thresholds.py
alias = '{:aliases {:switches {:extra-paths ['+json.dumps(str(here.parent/'harness'))+'] :main-opts ['+json.dumps(str(here/'time_switches.clj'))+']}}}'
for b in range(2):
    out = work/f'switch-{b}.jsonl'
    if out.exists():
        raise FileExistsError(out)
    subprocess.run(['clojure', '-Sdeps', alias, '-M:job-baselines:switches', str(work/'plans.jsonl'),
                    str(b), str(out)], cwd=work/'federation', check=True)
