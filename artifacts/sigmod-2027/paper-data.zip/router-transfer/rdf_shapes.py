"""Parse the 40 released query heads without changing their projections (RDFLib 7.6.0)."""
from hashlib import sha256
import gzip
import json
from pathlib import Path

from rdflib import Variable
from rdflib.plugins.sparql.algebra import translateQuery
from rdflib.plugins.sparql.parser import parseQuery
from rdflib.plugins.sparql.parserutils import CompValue

here = Path(__file__).resolve().parent


def operators(node):
    if isinstance(node, CompValue):
        yield node.name
        for value in node.values():
            yield from operators(value)
    elif isinstance(node, (list, tuple)):
        for value in node:
            yield from operators(value)


def head(text):
    algebra = translateQuery(parseQuery(text)).algebra
    assert algebra.name == 'SelectQuery'
    variables = algebra['PV']
    assert variables and all(isinstance(v, Variable) for v in variables)
    return dict(sha256=sha256(text.encode()).hexdigest(), projected=len(variables),
                aggregates=sorted(n for n in operators(algebra) if n.startswith('Aggregate_')))


if __name__ == '__main__':
    inputs = json.loads(gzip.decompress((here/'rdf-inputs.json.gz').read_bytes()))
    records = {k: head(v) for k, v in inputs['sparql'].items()}
    for spec in inputs['specs']:
        records[spec['id']]['adaptation_input'] = head(spec['sparql'])
    (here/'rdf-shapes.json').write_text(json.dumps(records, indent=2)+'\n')
