;; C/CH algebra lowering from the archived adapter benchmark.
(require '[clojure.set :as set] '[clojure.walk :as walk])

(defn v [name] (symbol (str "?" name)))
(defn attribute [table field] (keyword (str "lrdf." table) field))
(defn term [t] (if-let [name (:var t)] (v name) (:term t)))

(defn outputs [tree]
  (case (:op tree)
    "bgp" (into #{}
            (mapcat (fn [p]
                      (concat (keep :var [(:subject p) (:predicate p) (:object p)])
                        (map :variable (:derived p))
                        (when (< 1 (count (:candidates p))) [(:witness p)])))) (:patterns tree))
    ("join" "leftjoin") (set/union (outputs (:left tree)) (outputs (:right tree)))
    "filter" (outputs (:child tree))))

(defn scalar [expr]
  (case (:op expr)
    "column" (v (:variable expr))
    "plain" (:value expr)
    "number" (bigdec (:value expr))
    (list (symbol (:op expr)) (scalar (:left expr)) (scalar (:right expr)))))

(defn- combine-bodies [left right]
  (when (and left right)
    (let [bodies (vec (take 129 (for [a left b right] (into a b))))]
      (when (<= (count bodies) 128) bodies))))

(defn- negative-bodies
  "Expand complete endpoint branches, retaining every scalar qualification."
  [symbols tree]
  (case (:op tree)
    "bgp"
    (reduce (fn [bodies {:keys [index subject predicate object candidates derived]}]
              (combine-bodies bodies
                (mapv (fn [branch {:keys [table]}]
                        (let [source (symbols table) row (v (str "__negative" index "_" branch))]
                          (into [[source row (attribute table "subject") (term subject)]
                                 [source row (attribute table "object") (term object)]]
                            (concat
                              (when (:var predicate)
                                [[source row (attribute table "predicate") (term predicate)]])
                              (map (fn [{:keys [column variable]}]
                                     [source row (attribute table column) (v variable)]) derived)))))
                  (range) candidates))) [[]] (:patterns tree))
    "join" (combine-bodies (negative-bodies symbols (:left tree)) (negative-bodies symbols (:right tree)))
    "filter"
    (let [expr (:lowered tree) left (get-in expr [:left :variable]) right (get-in expr [:right :variable])]
      (when-let [bodies (negative-bodies symbols (:child tree))]
        (if (and (= "=" (:op expr)) left right
                 (.startsWith ^String left "__expr_") (.startsWith ^String right "__expr_"))
          (walk/postwalk-replace {(v right) (v left)} bodies)
          (mapv #(conj % [(scalar expr)]) bodies))))
    nil))

(defn clauses [symbols tree]
  (case (:op tree)
    "bgp"
    (vec
      (mapcat
        (fn [{:keys [index subject predicate object candidates derived witness] :as pattern}]
          (if (empty? candidates)
            [(into ['$empty (v (str "__empty" index))] (map v (sort (outputs {:op "bgp" :patterns [pattern]}))))]
            (let [branches
                  (mapv (fn [branch {:keys [table]}]
                          (let [source (symbols table) row (v (str "__triple" index "_" branch))]
                            (into [[source row (attribute table "subject") (term subject)]
                                   [source row (attribute table "object") (term object)]]
                              (concat (when (:var predicate)
                                        [[source row (attribute table "predicate") (term predicate)]])
                                (map (fn [{:keys [column variable]}]
                                             [source row (attribute table column) (v variable)]) derived)
                                (when (< 1 (count candidates)) [[(list 'ground branch) (v witness)]])))))
                    (range) candidates)]
              (if (= 1 (count branches)) (first branches)
                [(apply list 'or-join (mapv v (sort (outputs {:op "bgp" :patterns [pattern]})))
                   (map #(apply list 'and %) branches))])))) (:patterns tree)))
    "join" (into (clauses symbols (:left tree)) (clauses symbols (:right tree)))
    "filter"
    (let [expr (:lowered tree) a (get-in expr [:left :variable]) b (get-in expr [:right :variable])
          body (clauses symbols (:child tree))]
      (if (and (= "=" (:op expr)) a b (.startsWith ^String a "__expr_") (.startsWith ^String b "__expr_"))
        ;; Expose equality of represented scalar values as an ordinary join key.
        ;; Keep both internal output names for the surrounding typed interface.
        (conj (walk/postwalk-replace {(v b) (v a)} body) [(list 'identity (v a)) (v b)])
        (conj body [(scalar expr)])))
    "leftjoin"
    (let [left (:left tree) right (:right tree)
          shared (vec (sort (set/intersection (outputs left) (outputs right))))
          added (vec (sort (set/difference (outputs right) (set shared))))
          _ (assert (seq shared) "C/CH optional must have a supplied shared key")
          body (clauses symbols right)
          negatives (negative-bodies symbols right)
          _ (when (nil? negatives)
              (throw (ex-info "OPTIONAL absence requires an unsupported external negative filter or exceeds the bounded fact expansion"
                       {:error :benchmark/unsupported-optional-absence})))
          absent (cond-> (mapv #(apply list 'not-join (mapv v shared) %) negatives)
                   (seq added) (conj [(list 'ground (vec (repeat (count added) nil))) (mapv v added)]))
          join-vars (into [(mapv v shared)] (map v added))]
      (conj (clauses symbols left)
        (list 'or-join join-vars (apply list 'and body) (apply list 'and absent))))))
