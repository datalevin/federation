"""Plan each JOB query at each setting. Only the four numeric literals vary."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
STUDY = HERE.parent
PLAN = Path('postgres/src/datalevin/federation/postgres/plan.clj')
DEFAULT = [3, 8, 12, 4]
GRID = [[1, 2, 4, 7], [6, 7, 9, 10], [10, 11, 13, 14], [1, 3, 5, 8]]
LITERALS = ['(<= 3 (count groups))', '(<= (count groups) 8)',
            '(<= (count groups) 12)', '(<= 4 (count (remove']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkout', type=Path, help='frozen federation tree, with datalevin beside it')
    parser.add_argument('work', type=Path, help='new scratch directory')
    args = parser.parse_args()
    source, work = args.checkout.resolve(), args.work.resolve()
    manifest = json.loads((STUDY/'production-manifest.json').read_text())
    for name, digest in manifest.items():
        assert sha256((source.parent/name).read_bytes()).hexdigest() == digest, name
    work.mkdir()
    fed = work/'federation'
    shutil.copytree(source, fed, ignore=shutil.ignore_patterns('.cpcache'))
    (work/'datalevin').symlink_to(source.parent/'datalevin', target_is_directory=True)
    plan = fed/PLAN
    content = plan.read_text()
    for i, expr in enumerate(LITERALS):
        assert content.count(expr) == 1
        content = content.replace(expr, expr.replace(str(DEFAULT[i]), f'(nth *route-cutoffs* {i})'))
    marker = '(defn dependent-preference'
    assert content.count(marker) == 1
    timing_source = content.replace(marker, '(def ^:dynamic *route-cutoffs* [3 8 12 4])\n\n'+marker)
    content = timing_source.replace(marker, '(defn classify')
    # Observe the branch returned by the real classifier without changing its result.
    insert = '(defn columns'
    assert content.count(insert) == 1
    observer = """(def ^:dynamic *route-reasons* nil)
(defn dependent-preference [views request]
  (let [reason (classify views request)]
    (when (and reason *route-reasons*) (swap! *route-reasons* conj reason))
    reason))

"""
    plan.write_text(content.replace(insert, observer+insert))
    grid = [DEFAULT] + [DEFAULT[:i] + [v] + DEFAULT[i+1:]
                        for i, values in enumerate(GRID) for v in values]
    (work/'settings.json').write_text(json.dumps(grid))
    script = HERE/'thresholds.clj'
    alias = '{:aliases {:sensitivity {:extra-paths ['+json.dumps(str(STUDY/'harness'))+'] :main-opts ['+json.dumps(str(script))+']}}}'
    try:
        subprocess.run(['clojure', '-Sdeps', alias, '-M:job-baselines:sensitivity',
                        str(work/'settings.json'), str(work/'plans.jsonl')], cwd=fed, check=True)
    finally:
        # Time the same policy with branch observation removed.
        plan.write_text(timing_source)


if __name__ == '__main__':
    main()
