(require '[clojure.java.io :as io]
         '[datalevin.core :as d]
         '[datalevin.federation.postgres :as pg]
         '[datalevin.federation.postgres-job :as job]
         '[jsonista.core :as json])
(import '[java.util UUID] '[java.util.zip GZIPInputStream])

(def profile {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/postgres"
              :properties {"user" (System/getProperty "user.name") "ApplicationName" "datalevin-rdf-transfer"}
              :compute-context-id :lrdf/single :statement-timeout-ms 300000 :max-row-bytes 262144})
(def instance (UUID/nameUUIDFromBytes (.getBytes "lrdf-fixture/postgres" "UTF-8")))

;; The published adaptation keeps source witnesses and RDF term multiplicity.
(load-file (str (first *command-line-args*) "/rdf_clauses.clj"))
(defn prepare [spec mappings mode]
  (let [physical (sort (set (map :table (mapcat :candidates (:patterns spec)))))
        sources (mapv #(symbol (str "$r" %)) (range (count physical)))
        where (clauses (zipmap physical sources) (:tree spec))
        unknown (sort (set/difference (set (:projected spec)) (outputs (:tree spec))))
        where (cond-> where (seq unknown) (conj [(list 'ground (vec (repeat (count unknown) nil))) (mapv v unknown)]))
        empty-input? (some #{'$empty} (tree-seq coll? seq where))
        providers (mapv #(pg/source (mappings %) (assoc profile :whole-query-mode mode)) physical)
        query (cond-> {:find (mapv v (:find spec))
                       :where where :in (if empty-input? (into ['$empty] sources) sources)
                       :timeout 300000 :query-source {:limits (:limits job/defaults)}}
                (and (:slice spec) (empty? (:ordering spec)))
                (assoc :limit (get-in spec [:slice :limit]) :offset (get-in spec [:slice :offset])))]
    {:query query :providers providers :args (if empty-input? (into [[]] providers) providers)}))

(defn observe [spec mappings mode row-dir]
  (let [{:keys [query args providers]} (prepare spec mappings mode)
        plan (apply d/explain {:run? false} query args)
        record {:whole (true? (get-in plan [:operators :relational?]))
                :fragment (true? (get-in plan [:operators :relational-fragment?]))
                :regions (mapv (fn [r] {:policy (:policy r)
                                        :steps (mapv #(select-keys % [:source-symbol :alternative-id :requires])
                                                     (:steps r))}) (:regions plan))}
        indices (mapv #(.indexOf ^java.util.List (:find spec) %) (:projected spec))
        _ (assert (every? #(<= 0 %) indices))
        start (System/nanoTime)
        rows (mapv (fn [row] (mapv #(nth row %) indices)) (apply d/q query args))
        elapsed (- (System/nanoTime) start)]
    (assert (every? #(zero? (:live-sessions (pg/statistics %))) providers))
    (with-open [out (java.util.zip.GZIPOutputStream.
                      (io/output-stream (io/file row-dir (str (:id spec) "-" (name mode) ".json.gz"))))]
      (json/write-value out rows))
    (assoc record :core-rows (count rows) :core-ns elapsed)))

(let [[root out] *command-line-args*
      inputs (with-open [in (GZIPInputStream. (io/input-stream (io/file root "rdf-inputs.json.gz")))]
               (json/read-value in json/keyword-keys-object-mapper))
      specs (:specs inputs)
      tables (into {} (map (juxt :table identity)) (mapcat :candidates (mapcat :patterns specs)))
      mappings (into {} (for [[table {:keys [schema derived_columns complete_triples]}] tables]
                          [table (pg/accept-mapping (pg/discover profile [schema table])
                                   {:source-instance-id instance :relation-id (keyword "lrdf" table)
                                    :identity-attribute (attribute table "identity")
                                    :attributes (into (cond-> {(attribute table "subject") "s"
                                                               (attribute table "object") "o"}
                                                        complete_triples (assoc (attribute table "predicate") "p"))
                                                      (map #(vector (attribute table %) %) derived_columns))})]))]
  (assert (.mkdir (io/file (str out ".rows"))))
  (with-open [w (io/writer out)]
    (doseq [spec specs]
      (let [modes (if (even? (.indexOf ^java.util.List specs spec)) [:auto :sql] [:sql :auto])
            runs (into {} (for [m modes] [m (observe spec mappings m (str out ".rows"))]))]
        (.write w (str (json/write-value-as-string (assoc runs :id (:id spec))) "\n"))
        (.flush w)))))
(shutdown-agents)
