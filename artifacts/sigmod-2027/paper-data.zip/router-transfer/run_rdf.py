"""Replay the paired RDF plans with the unmodified, hash-verified submission runtime."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

here = Path(__file__).resolve().parent
fed, output = (Path(arg).resolve() for arg in sys.argv[1:])
manifest = json.loads((here.parent/'production-manifest.json').read_text())
assert all(sha256((fed.parent/path).read_bytes()).hexdigest() == digest for path, digest in manifest.items())
if output.exists():
    raise FileExistsError(output)
alias = '{:aliases {:rdf {:main-opts ['+json.dumps(str(here/'rdf_routes.clj'))+']}}}'
subprocess.run(['clojure', '-Sdeps', alias, '-M:job-baselines:rdf', str(here), str(output)], cwd=fed, check=True)
