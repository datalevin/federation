(require '[clojure.java.io :as io]
         '[datalevin.federation.postgres :as pg]
         '[datalevin.federation.postgres.plan :as plan]
         '[datalevin.federation.postgres-job-sql :as sql]
         '[datalevin.federation.postgres-job-suite :as suite]
         '[datalevin.research.job-routes :as routes]
         '[jsonista.core :as json])

(let [[grid-file out] *command-line-args*
      grid (json/read-value (slurp grid-file))
      opts (suite/options! {:verify-tuples? false :timeout-ms 300000})
      profile {:jdbc-url "jdbc:postgresql://127.0.0.1:5432/postgres"
               :properties {"user" (System/getProperty "user.name")
                            "ApplicationName" "datalevin-routing-sensitivity"}
               :compute-context-id :benchmark/production-summary
               :statement-timeout-ms 300000 :max-row-bytes (:max-row-bytes opts)}
      entries (suite/corpus! opts)
      tables (set (mapcat #(map second (:from (sql/parse (:sql %)))) entries))
      catalogs (into {} (for [t tables] [t (pg/discover profile ["public" t])]))]
  (with-open [writer (io/writer out)]
    (doseq [entry entries]
      (let [plans (for [setting grid]
                    (let [reasons (atom #{})]
                      (binding [plan/*route-cutoffs* setting plan/*route-reasons* reasons]
                        (let [p (routes/describe profile opts catalogs entry)]
                          {:setting setting :route (:route p) :reasons (sort @reasons)}))))]
        (.write writer (str (json/write-value-as-string
                              {:id (:id entry) :sha256 (:sha256 entry) :plans plans}) "\n"))
        (.flush writer)))))
(shutdown-agents)
