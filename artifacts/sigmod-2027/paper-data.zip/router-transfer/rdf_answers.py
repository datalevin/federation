"""Finish projected RDF bags and check each result against independently validated answers."""
from collections import Counter
from hashlib import sha256
import gzip
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def digest(value):
    return sha256(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def signature(rows, spec):
    columns = [spec['projected'].index(k['variable']) for k in spec['ordering']]
    bag = sorted(([list(row), n] for row, n in Counter(tuple(row) for row in rows).items()),
                 key=lambda pair: json.dumps(pair[0]))
    return {'n': len(rows), 'bag': digest(bag),
            'order': digest([[r[k] for k in columns] for r in rows]) if columns else None}


def finish(rows, spec):
    # Compare typed terms using SPARQL's own ordering. Keep whole rows through ties.
    if spec['ordering'] and rows:
        import pyoxigraph as ox
        cols = [spec['projected'].index(o['variable']) for o in spec['ordering']]
        keys = ['?key'+str(k) for k in range(len(cols))]
        values = ['('+str(i)+' '+' '.join(row[c] or 'UNDEF' for c in cols)+')' for i,row in enumerate(rows)]
        order = ['DESC('+v+')' if o['descending'] else v for v,o in zip(keys,spec['ordering'])]
        q = ('SELECT ?row WHERE { VALUES (?row '+' '.join(keys)+') { '+' '.join(values)
             +' } } ORDER BY '+' '.join(order))
        indices = [int(r['row'].value) for r in ox.Store().query(q)]
        assert sorted(indices) == list(range(len(rows)))
        rows = [rows[i] for i in indices]
    if spec['slice']:
        assert spec['slice']['offset'] == 0
        rows = rows[:spec['slice']['limit']]
    return rows


def reference_signatures(measurements, specs):
    prior = measurements/'federation-cross-workload-2026-11-17'
    layout = measurements/'federation-rdf-domain-pruning-2026-11-17'
    accepted = {k: [] for k in specs}

    def add(id, rows):
        sig = signature(rows, specs[id])
        if sig not in accepted[id]:
            accepted[id].append(sig)
        return sig

    for b in range(4):
        for call in json.loads((prior/f'cch-{b}.json').read_bytes())['calls']:
            if call.get('matches') is True:
                q, arm = call['query'], call['arm']
                rows = json.loads((prior/f'cch-{b}-{q}-{arm}-answer.json').read_bytes())['rows']
                assert add(q, rows)['bag'] == call['answer_sha256']
    archive = json.loads(gzip.decompress((layout/'answers.json.gz').read_bytes()))
    for phase in ('mapping-a','mapping-b','mapping-2','mapping-3'):
        checks = json.loads((layout/(phase+'-checks.json')).read_bytes())
        for i, obs in enumerate(checks, 1):
            if obs.get('matches') is True:
                rows = archive['rows'][archive['calls'][f'{phase}:{i}']]
                add(obs['id'], rows)
    assert all(accepted.values())
    return accepted


if __name__ == '__main__':
    inputs = json.loads(gzip.decompress((HERE/'rdf-inputs.json.gz').read_bytes()))
    specs = {q['id']:q for q in inputs['specs']}
    reference = HERE/'rdf-reference.json'
    if sys.argv[1] == 'reference':
        reference.write_text(json.dumps(reference_signatures(Path(sys.argv[2]),specs),indent=2)+'\n')
    else:
        rows_dir = Path(sys.argv[1])
        archive = json.loads(gzip.decompress(rows_dir.read_bytes())) if rows_dir.is_file() else None
        reference = json.loads(reference.read_bytes())
        checks = {}
        for q,spec in specs.items():
            for mode in ('auto','sql'):
                key = f'{q}-{mode}'
                rows = (archive['rows'][archive['calls'][key]] if archive else
                        json.loads(gzip.decompress((rows_dir/(key+'.json.gz')).read_bytes())))
                sig = signature(finish(rows,spec),spec)
                checks[key] = {**sig, 'matches':sig in reference[q], 'core_rows_sha256':digest(rows)}
        Path(sys.argv[2]).write_text(json.dumps(checks,indent=2)+'\n')
        assert all(d['matches'] for d in checks.values())
        print('Matched',len(checks),'of',len(checks))
