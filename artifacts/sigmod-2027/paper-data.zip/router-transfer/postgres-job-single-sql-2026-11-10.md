# Expanded PostgreSQL single-SQL execution

The same 40-query JOB cohort takes **17.85 seconds**, down from **34.85 seconds**
with the preceding implementation. Native PostgreSQL takes **37.70 seconds** in
the new pass and 35.18 seconds in the baseline pass. This is a single-pass screen
with no explicit warmups, not a repeated full-suite result. Raw per-query values,
including regressions, are retained in the
[comparison CSV](postgres-job-single-sql-comparison-2026-11-10.csv) and
[summary](postgres-job-single-sql-summary-2026-11-10.edn).

All **43 executed queries** verify every original aggregate and the complete
distinct projected tuple set: the matched 40 plus 20c, 29a, and 29c. This does not
claim execution coverage of all 113 queries. The final plan-only inventory selects
one SQL plan for **101 of 113**, compared with 20 before this change. Nine eligible
queries retain dependent execution; 7a, 7c, and 12b retain core handling of nested
OR programs. SQL preference can compile 110 of the 113 queries. All 113 plan.

| Preserved dependent plan | Adapter median | Native median | Faster pairs |
| --- | ---: | ---: | ---: |
| 6d | 339 ms | 5.07 s | 5/5 |
| 17c | 579 ms | 6.28 s | 5/5 |

These repeats use two warmups and five alternating native/adapter pairs in a
fresh JVM. Both aggregates and all 68/146 projected tuples verify. See the
[repeated samples](postgres-job-single-sql-preserved-wins-2026-11-10.edn).

The automatic policy attempts complete SQL across the supported graph size,
independently of whether native text extrema were requested. It retains bounded
text/membership drivers and identity-only existence probe shapes using typed
graph roles. Membership drivers must come from a dimension without outgoing
reference reads; multiple LIKE predicates on one table count as one driver.
This is a structural heuristic, not a complete cost comparison between SQL and
dependent execution. Some queries remain slower; the runtime mode override lets
users compare both approaches on their own data.

The SQL compiler omits DISTINCT for all-MIN/MAX projections because duplicates
cannot change their results or validation flags. Other reducers preserve the
distinct find/with witness relation. SQL tables follow source declaration order,
including existence witnesses whose facts occur later in the query. A flat FROM
list leaves PostgreSQL's join search unconstrained by an explicit CROSS JOIN
tree. Key-dependent LATERAL fragments keep their intentional fences.

Scalar aggregates without grouping or result windows have a compiler-proven
maximum of one output row. They execute as direct SELECTs with JDBC fetch size
zero and a strict one-row decoder limit, allowing PostgreSQL parallel plans.
Grouped and potentially larger results still use owned cursor pages. Output
limits apply to returned values: a large backend-only input can produce a small
valid MIN, while oversized returned aggregates and tuples still fail.

The adapter [documentation](../../postgres/README.md) covers the runtime modes,
semantic boundaries, and the relationship to PostgreSQL FDW. Primary references:

- [postgres_fdw remote query optimization](https://www.postgresql.org/docs/18/postgres-fdw.html#POSTGRES-FDW-REMOTE-QUERY-OPTIMIZATION).
- [Foreign upper paths and aggregation](https://www.postgresql.org/docs/18/fdw-callbacks.html#FDW-CALLBACKS-UPPER-PATHS).
- [Explicit join order](https://www.postgresql.org/docs/18/explicit-joins.html).
- [Parallel-query restrictions](https://www.postgresql.org/docs/18/when-can-parallel-query-be-used.html).

The data is the existing IMDb JOB database. No tables, indexes, statistics, or
answers were installed or changed. Every timed call includes connection,
snapshot/metadata acquisition, planning, estimation, execution, decoding, and
cleanup. JVM startup, initial discovery/mapping, warmups, and correctness oracles
are excluded. Query order is the corpus order and native/adapter order alternates
by query. The expanded pass includes three additional targets; timings and
cache state can vary between passes. The native aggregate fetch size is zero.

Raw evidence:

- [Before](postgres-job-single-sql-before-2026-11-10.edn) and
  [final execution](postgres-job-single-sql-after-2026-11-10.edn).
- [Before planning](postgres-job-single-sql-planning-before-2026-11-10.edn) and
  [final planning](postgres-job-single-sql-planning-after-2026-11-10.edn).
- [Initial forced-SQL diagnostic](postgres-job-single-sql-sql-initial-screen-2026-11-10.edn),
  which explains why blanket delegation is unsuitable.
- [Native-plus-binary predicate experiment](postgres-job-single-sql-coalesce-screen-2026-11-10.edn)
  and [binary-only experiment](postgres-job-single-sql-binary-screen-2026-11-10.edn).
  Redundant native predicates were excluded from the final implementation.

The baseline is an isolated classpath overlay containing the four captured
pre-change PostgreSQL source files. Reports fingerprint the loaded implementation,
record the effective whole-query mode and limits, and check that sessions close
after every call. The [baseline patch](postgres-job-single-sql-baseline-2026-11-10.patch)
reconstructs those resources from the final source in a separate directory.

Final validation passes **259 tests and 7,736 assertions**, with zero failures
or errors, covering the PostgreSQL/JOB suites and affected core relational,
aggregation, planning, execution, and lifecycle behavior. Changed source and
tests pass clj-kondo without warnings or errors. All 28 recorded source
fingerprints match the delivered workspace in the final execution, planning,
and repeated-win reports. The four-resource baseline patch was applied to a
temporary copy and verified byte for byte. See the
[test log](postgres-job-single-sql-tests-2026-11-10.txt).
