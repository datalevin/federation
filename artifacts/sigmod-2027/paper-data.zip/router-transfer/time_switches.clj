(require '[clojure.java.io :as io]
         '[datalevin.core :as d]
         '[datalevin.federation.postgres :as pg]
         '[datalevin.federation.postgres.plan :as plan]
         '[datalevin.federation.postgres-job-sql :as sql]
         '[datalevin.federation.postgres-job-suite :as suite]
         '[datalevin.research.placement-controls :as controls]
         '[jsonista.core :as json])

(defn call [query providers expected setting]
  (binding [plan/*route-cutoffs* setting]
    (let [selected (controls/inspect query providers)
          start (System/nanoTime)
          result (try
                   (let [rows (set (apply d/q query providers))
                         rows (if (seq rows) rows #{(vec (repeat (count (:find query)) nil))})]
                     (assert (= rows expected))
                     {:status :ok :answer rows})
                   (catch Exception e
                     {:status :failed :error (select-keys (ex-data e) [:error :phase :category :maximum])
                      :message (.getMessage e)}))]
      (assert (every? #(zero? (:live-sessions (pg/statistics %))) providers))
      (assoc result :setting setting :plan selected :elapsed-ns (- (System/nanoTime) start)))))

(let [[plans-file block out] *command-line-args*
      b (parse-long block)
      inventory (mapv #(json/read-value % json/keyword-keys-object-mapper)
                      (clojure.string/split-lines (slurp plans-file)))
      switches (into {} (for [{:keys [id plans]} inventory
                              :when (= "whole" (:route (first plans)))
                              :let [alt (first (remove #(= "whole" (:route %)) plans))]
                              :when alt]
                          [(keyword id) [(:setting (first plans)) (:setting alt)]]))
      entries (suite/corpus! (assoc controls/opts :queries (vec (keys switches))))
      profile (assoc controls/profile :statement-timeout-ms 20000)
      tables (set (mapcat #(map second (:from (sql/parse (:sql %)))) entries))
      catalogs (into {} (for [t tables] [t (pg/discover profile ["public" t])]))
      cases (vec (map-indexed vector entries))]
  (with-open [w (io/writer out)]
    (doseq [[i {:keys [id] :as entry}] (if (zero? b) cases (reverse cases))]
      (let [parsed (sql/parse (:sql entry))
            spec (sql/compile-query parsed catalogs)
            q (assoc (:query spec) :timeout 20000 :query-source
                     (cond-> {:limits (:limits controls/opts) :native-extrema (:native-extrema spec)}
                       (seq (:ignore-nil-extrema spec)) (assoc :ignore-nil-extrema (:ignore-nil-extrema spec))))
            ps (sql/sources! profile catalogs spec)
            expected (suite/native! controls/profile (sql/sql-query parsed "public" true))
            settings (switches id)]
        (doseq [setting (if (even? (+ i b)) settings (reverse settings))]
          (let [obs (call q ps expected setting)]
            (assert (= (get-in obs [:plan :whole]) (= setting (first settings))))
            (.write w (str (json/write-value-as-string
                             (assoc obs :id id :sha256 (:sha256 entry) :block b :oracle expected)) "\n"))
            (.flush w)))))))
(shutdown-agents)
