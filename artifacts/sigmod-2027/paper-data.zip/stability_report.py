"""Compare four executed JOB replays with the records retained by the timing JVMs."""
from collections import defaultdict
import json


def compact(value):
    return json.dumps(value, separators=(',', ':'))


def summarize_access(study, save):
    def load(name):
        return json.loads((study / name).read_text())

    baseline = load('routes/routes.json')
    queries = {p['id']: p for p in baseline['plans']}
    profiles = defaultdict(set)
    schedules = defaultdict(set)
    opens = defaultdict(set)
    warm_savings = defaultdict(list)
    replays, timings, states = [], [], []
    baseline_matches = counter_matches = 0
    for b in range(4):
        timed = load(f'job/block-{b}.json')
        state = load(f'job-access/state-{b}.json')
        assert state['block'] == b and state['planner'] == baseline['planner']
        assert state['before'] == state['after'] and all(state['before']['statistics'])
        assert state['before']['inventory'] == timed['source-before'] == timed['source-after']
        states.append(state)
        lines = (study / 'job-access' / f'block-{b}.jsonl').read_text().splitlines()
        records = [json.loads(line) for line in lines]
        order = list(queries) if b % 2 == 0 else list(reversed(queries))
        assert [(r['phase'], r['id']) for r in records] == [
            (phase, query) for phase in ('cold', 'warm') for query in order]
        original = [q for phase in ('cold', 'warm') for q in timed['phases'][phase]]
        assert len(original) == len(records)
        for r, q in zip(records, original):
            query, phase = r['id'], r['phase']
            plan = queries[query]
            assert r['block'] == b and query == q['id'] and r['sql-sha256'] == q['sha256'] == plan['sha256']
            assert r['result-rows'] == (0 if all(v is None for v in q['expected'][0]) else len(q['expected']))
            reference = [[[s.get('source', s.get('source-symbol')), s['alternative-id']]
                          for s in region if 'alternative-id' in s] for region in plan['steps']]
            baseline_matches += r['selected'] == reference and r['whole'] == (plan['route'] == 'whole')
            selected, cursors = compact(r['selected']), compact(r['cursor-runs'])
            schedules[query].add((r['whole'], selected))
            opens[query].add(cursors)
            replays.append(dict(query=query, replay_jvm=b+1, phase=phase, whole=r['whole'],
                                selected_by_region=selected, cursor_runs=cursors, result_rows=r['result-rows'],
                                acquisition_requests=compact(r['provider-requests'])))
            counts = [s['external-requests'] for s in q['source-statistics']]
            profiles[query].add(tuple(counts))
            counter_matches += counts == r['provider-requests']
            sample, = q['samples']
            sql_ns, adapter_ns = (sample[k]['elapsed-ns'] for k in ('native', 'adapter'))
            timings.append(dict(query=query, timing_jvm=b+1, phase=phase, first_arm=sample['order'][0],
                                original_sql_ns=sql_ns, adapter_ns=adapter_ns, acquisition_requests=compact(counts)))
            if phase == 'warm':
                warm_savings[query].append(sql_ns - adapter_ns)

    assert len({state['pid'] for state in states}) == 4
    assert all(a['end'] < b['start'] for a, b in zip(states, states[1:]))
    assert all(state['before'] == states[0]['before'] for state in states)
    save('job-access-by-jvm.csv', replays)
    save('job-timing-by-jvm.csv', timings)
    always_faster = sum(min(v) > 0 for v in warm_savings.values())
    always_slower = sum(max(v) < 0 for v in warm_savings.values())
    save('job-stability-summary.csv', [dict(
        queries=len(queries), replay_calls=len(replays), replay_matches_original_inventory=baseline_matches,
        queries_one_selected_schedule=sum(len(v) == 1 for v in schedules.values()),
        queries_one_cursor_sequence=sum(len(v) == 1 for v in opens.values()),
        replay_matches_original_acquisition_counts=counter_matches,
        original_queries_one_acquisition_profile=sum(len(v) == 1 for v in profiles.values()),
        warm_adapter_faster_all_four=always_faster, warm_original_faster_all_four=always_slower,
        warm_changes_direction=sum(min(v) < 0 < max(v) for v in warm_savings.values()))])


def summarize_statistics(study, save):
    # Match the forced estimates to the access sequences observed after natural ANALYZE samples.
    natural = {}
    for line in (study / 'fixed-choice/draws.jsonl').read_text().splitlines():
        profile = next(p for p in json.loads(line)['profiles'] if p['arm'] == 'default')
        edge = next(s for s in profile['steps'] if s['alternative-id'] == 'value-lookup-0-0-1')
        natural[edge['estimate']['rows-per-binding']] = profile['ids']
    rows = []
    pids = set()
    for b, sequence in enumerate(((8197, 8188, 8197), (8188, 8197, 8188))):
        lines = (study / 'mixed-statistics' / f'block-{b}.jsonl').read_text().splitlines()
        records = [json.loads(line) for line in lines]
        assert [r['distinct-override'] for r in records] == list(sequence)
        assert len({(r['pid'], r['schema']) for r in records}) == 1
        pids.add(records[0]['pid'])
        for i, r in enumerate(records):
            count = r['distinct-override']
            assert r['block'] == b and r['catalog'] == [1048576, count, 0]
            steps = r['steps']
            estimate = next(s['estimate']['rows-per-binding'] for s in steps if s['alternative-id'] == 'value-lookup-0-0-1')
            assert estimate == 1048576 / count
            ids = [s['alternative-id'] for s in steps]
            assert ids == natural[estimate]
            rows.append(dict(jvm=b+1, step=i+1, distinct_owners_estimate=count,
                             edges_per_owner_estimate=estimate, first_source=steps[0]['source'],
                             selected_ids=compact(ids)))
    assert len(pids) == 2
    save('mixed-statistics.csv', rows)


if __name__ == '__main__':
    from report import STUDY, save_csv
    summarize_statistics(STUDY, save_csv)
    summarize_access(STUDY, save_csv)
