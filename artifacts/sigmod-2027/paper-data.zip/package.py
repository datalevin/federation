"""Pack the exact source, harness and observations cited in the submission."""
import argparse
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('output', type=Path)
args = parser.parse_args()
# Include raw records, human-readable tables and reproducible inputs. EDN files
# duplicate the JSON fixture observations and add untimed plan explanations.
paths = sorted(p for p in here.rglob('*') if p.is_file() and
               not any(x.startswith('.') or x=='__pycache__' for x in p.relative_to(here).parts)
               and p.suffix not in ('.pyc','.edn','.tmp'))
with ZipFile(args.output,'w',compression=ZIP_DEFLATED) as z:
    names = {}
    for p in paths:
        name=str(p.relative_to(here))
        z.write(p,name)
        names[name]=sha256(p.read_bytes()).hexdigest()
    paper_data = here.parents[1]/'conference-submissions/sigmod2027-industry/data'
    for table in ('production-results.tex','production-job-deltas.csv'):
        path=paper_data/table
        name='tables/'+table
        z.write(path,name)
        names[name]=sha256(path.read_bytes()).hexdigest()
    z.writestr('SHA256SUMS.json',json.dumps(names,indent=2)+'\n')
