"""Run the paired extension on the archived production checkout."""
import argparse
from contextlib import ExitStack
from hashlib import sha256
from itertools import permutations
import json
from pathlib import Path
from statistics import mean
import subprocess
import sys
import threading
import time

STUDY = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY))
from relay import Relay


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def panel_ids():
    routes = json.loads((STUDY/'routes/routes.json').read_text())['plans']
    required = {r['id'] for r in routes if r['route'] != 'whole' or r['id'][:-1] == '17'}
    times = {}
    for b in range(4):
        for row in json.loads((STUDY/'job'/f'block-{b}.json').read_text())['phases']['warm']:
            times.setdefault(row['id'], []).append(row['samples'][0]['native']['elapsed-ns'])
    other = sorted((q for q in times if q not in required), key=lambda q: mean(times[q]))
    assert len(other) == 103
    ids = sorted(required)
    for i in range(3):
        group = other[i*103//3:(i+1)*103//3]
        sample = sorted(group, key=lambda q: sha256(('placement-rtt-v1/' + q).encode()).digest())[:3]
        ids.extend(sample)
    assert len(set(ids)) == len(ids) == 19
    return ids


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('panel', choices=['job', 'prefix', 'rtt'])
    p.add_argument('checkout', type=Path)
    p.add_argument('output', type=Path)
    p.add_argument('--block', type=int, help='collect one scheduled block in the unused output directory')
    args = p.parse_args()
    panel, checkout, output = args.panel, args.checkout.resolve(), args.output.resolve()
    manifest = STUDY / 'production-manifest.json'
    for name, expected in json.loads(manifest.read_text()).items():
        assert digest(checkout.parent / name) == expected, name
    output.mkdir()
    harness = STUDY / 'harness/datalevin/research'
    files = [Path(__file__).resolve(), Path(__file__).with_name('DESIGN.md'), harness/'production_job.clj']
    if panel == 'job':
        files.append(harness/'job_repeatability.clj')
    else:
        files += [STUDY/'statistics'/f'{panel}.clj', harness/'placement_controls.clj']
        if panel == 'prefix':
            files += [harness/'mixed_public.clj', harness/'public_plans.clj', STUDY/'routes/routes.json']
        else:
            files += [STUDY/'relay.py', STUDY/'routes/routes.json', *(STUDY/'job'/f'block-{b}.json' for b in range(4))]
    receipt = dict(panel=panel, production_manifest=digest(manifest),
                   files={str(f.relative_to(STUDY)): digest(f) for f in files})
    if panel == 'rtt':
        receipt['ids'] = panel_ids()
    (output/'inputs.json').write_text(json.dumps(receipt, indent=2) + '\n')
    entry = ['-m', 'datalevin.research.job-repeatability'] if panel == 'job' else [str(STUDY/'statistics'/f'{panel}.clj')]
    alias = ('{:aliases {:precision {:extra-paths [' + json.dumps(str(STUDY/'harness')) +
             '] :main-opts ' + json.dumps(entry) + '}}}')
    blocks = {'job': range(4, 6), 'prefix': range(2, 8), 'rtt': range(6)}[panel]
    if args.block is not None:
        if args.block not in blocks:
            p.error('block is outside the range for this panel')
        blocks = [args.block]
    for b in blocks:
        cmd = ['clojure', '-Sdeps', alias, '-M:job-baselines:precision']
        with ExitStack() as stack:
            if panel == 'job':
                cmd += [str(b), str(output/f'block-{b}.json'), 'full']
            else:
                cmd += [str(b), str(output/f'block-{b}.jsonl')]
                if panel == 'prefix':
                    cmd += [str(STUDY/'routes/routes.json')]
                else:
                    delays = list(permutations([0, 5, 20]))[b]
                    ports = []
                    lock = threading.Lock()
                    for delay in delays:
                        relay = Relay(delay, output/f'wire-{b}.jsonl', lock)
                        stack.callback(relay.close)
                        ports.append(f'[{delay} {relay.port}]')
                    cmd += ['[' + ' '.join(ports) + ']', json.dumps(receipt['ids'])]
            print(panel, b, flush=True)
            start = time.time_ns()
            with (output/f'block-{b}.log').open('x') as log:
                subprocess.run(cmd, cwd=checkout, stdout=log, stderr=subprocess.STDOUT, check=True)
        (output/f'launch-{b}.json').write_text(json.dumps(dict(start_ns=start, end_ns=time.time_ns())) + '\n')


if __name__ == '__main__':
    main()
