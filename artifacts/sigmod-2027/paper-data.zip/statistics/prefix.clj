(ns prefix
  (:require [clojure.java.io :as io]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.federation.postgres.jdbc :as jdbc]
            [datalevin.research.mixed-public :as mixed]
            [datalevin.research.placement-controls :as controls]
            [jsonista.core :as json])
  (:import [java.io Writer]
           [java.util UUID]))

(defn record! [^Writer writer value]
  (.write writer (str (json/write-value-as-string value) "\n"))
  (.flush writer))

(defn measure-job! [block routes writer control]
  (let [ids (for [plan (get (json/read-value (slurp routes)) "plans")
                  :when (not= "whole" (plan "route"))]
              (keyword (plan "id")))
        entries (suite/corpus! (assoc controls/opts :queries (vec ids)))
        tables (set (mapcat #(map second (:from (sql/parse (:sql %)))) entries))
        catalogs (into {} (for [t (sort tables)] [t (pg/discover controls/profile ["public" t])]))
        modes [[:auto {}] (if (= control :prefix)
                           [:prefix {:bound-join-mode :protected-prefix}]
                           [:sql {:whole-query-mode :sql}])]]
    (assert (= 7 (count entries)))
    (doseq [[i entry] (map-indexed vector (if (even? block) entries (reverse entries)))]
      (let [result (controls/run-case controls/profile catalogs entry modes block i nil)]
        (record! writer (assoc result :block block :comparison control :added-rtt-ms 0))))))

(defn measure-dense! [block writer]
  (let [fixture (assoc (first (filter #(= :dense (:id %)) mixed/fixtures))
                       :local-floor? true :id :dense-floor)
        expected (mixed/expected fixture)
        schema (str "dtlv_stat_" (.replace (str (UUID/randomUUID)) "-" ""))
        owned? (atom false)]
    (with-open [db (mixed/connection controls/profile)]
      (try
        (mixed/setup-schema! db schema owned? fixture)
        (doseq [sample [-1 0 1]
                mode (if (even? (+ block sample)) [:auto :prefix] [:prefix :auto])]
          (let [result (mixed/run-mode controls/profile schema fixture expected mode nil nil)]
            (assert (= (count expected) (:rows result)))
            (record! writer (assoc result :id :dense-floor :block block :sample sample))))
        (finally
          (when @owned?
            (mixed/execute! db (str "DROP SCHEMA " (jdbc/identifier schema) " CASCADE"))))))))

(let [[n output routes] *command-line-args*
      block (parse-long n)]
  (with-open [writer (io/writer output)]
    (when (odd? block) (measure-dense! block writer))
    (doseq [control (if (even? block) [:prefix :router] [:router :prefix])]
      (measure-job! block routes writer control))
    (when (even? block) (measure-dense! block writer)))
  (shutdown-agents))
