(ns rtt
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]
            [datalevin.federation.postgres :as pg]
            [datalevin.federation.postgres-job-sql :as sql]
            [datalevin.federation.postgres-job-suite :as suite]
            [datalevin.research.placement-controls :as controls]
            [datalevin.research.production-job :as production]
            [jsonista.core :as json])
  (:import [java.io Writer]))

(defn record! [^Writer writer value]
  (.write writer (str (json/write-value-as-string value) "\n"))
  (.flush writer))

(defn relay-profile [port]
  (assoc controls/profile :jdbc-url
         (str "jdbc:postgresql://127.0.0.1:" port
              "/postgres?sslmode=disable&gssEncMode=disable&assumeMinServerVersion=12")))

(let [[n output ports ids] *command-line-args*
      block (parse-long n)
      ports (edn/read-string ports)
      opts (suite/options! {:queries (mapv keyword (json/read-value ids))
                            :verify-tuples? false :samples 1 :warmups 0 :timeout-ms 180000})
      entries (suite/corpus! opts)
      positions (zipmap (map :id entries) (range))
      tables (sort (set (mapcat #(map second (:from (sql/parse (:sql %)))) entries)))
      catalogs (into {} (for [t tables] [t (pg/discover controls/profile ["public" t])]))
      before (production/source-state controls/profile tables)]
  (with-open [writer (io/writer output)]
    (record! writer {:stage :inventory-before :source before})
    (doseq [[stage level port] (cons [:warmup 0 (get (into {} ports) 0)]
                                     (for [[delay p] ports] [:measure delay p]))]
      (let [profile (relay-profile port)]
        (record! writer {:stage stage :level level :calibration-before (controls/calibrate profile)})
        (doseq [entry (if (even? block) entries (reverse entries))]
          (let [i (+ block (positions (:id entry)) (.indexOf [0 5 20] level))
                tag (str "paired-" block "-" (name stage) "-" level "-" (name (:id entry)))
                p (assoc-in profile [:properties "ApplicationName"] tag)
                start (System/currentTimeMillis)
                result (suite/run-query! p opts catalogs i entry)]
            (assert (= :ok (:status result)) (str stage " " level " " (:id entry) " " (:samples result)))
            (record! writer (assoc (select-keys result [:id :sha256 :samples :aggregate-checks
                                                         :expected :source-statistics])
                                   :block block :stage stage :level level
                                   :start-ms start :end-ms (System/currentTimeMillis)))))
        (record! writer {:stage stage :level level :calibration-after (controls/calibrate profile)})))
    (let [after (production/source-state controls/profile tables)]
      (assert (= before after) "Source inventory changed during the RTT panel")
      (record! writer {:stage :inventory-after :source after})))
  (shutdown-agents))
